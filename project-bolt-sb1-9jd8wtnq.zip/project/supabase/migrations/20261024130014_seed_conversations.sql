/*
# Seed: 10 conversation scenarios with dialog and quiz
Each conversation: title, category, level, summary, dialog (jsonb array of {kannada, transliteration, hindi, english}), quiz (jsonb array of {question, options, correct_index, explanation}).
*/

INSERT INTO conversations (title, category, level, summary, dialog, quiz, order_idx) VALUES
('Introducing Yourself','introductions','beginner',
'How to introduce yourself in Kannada.',
'[{"kannada":"ನಮಸ್ಕಾರ","transliteration":"Namaskara","hindi":"नमस्ते","english":"Hello"},{"kannada":"ನನ್ನ ಹೆಸರು ರವಿ","transliteration":"Nanna hesaru Ravi","hindi":"मेरा नाम रवि है","english":"My name is Ravi"},{"kannada":"ನಾನು ವಿದ್ಯಾರ್ಥಿ","transliteration":"Naanu vidyaarthi","hindi":"मैं विद्यार्थी हूँ","english":"I am a student"},{"kannada":"ನಿಮ್ಮ ಹೆಸರು ಏನು?","transliteration":"Nimma hesaru enu?","hindi":"आपका नाम क्या है?","english":"What is your name?"}]',
'[{"question":"What does ''Namaskara'' mean?","options":["Goodbye","Hello","Sorry","Thanks"],"correct_index":1,"explanation":"Namaskara means Hello, a common greeting."},{"question":"How do you say ''My name is Ravi'' in Kannada?","options":["ನಿಮ್ಮ ಹೆಸರು ರವಿ","ನನ್ನ ಹೆಸರು ರವಿ","ಅವನ ಹೆಸರು ರವಿ","ನಾನು ರವಿ"],"correct_index":1,"explanation":"ನನ್ನ (my) + ಹೆಸರು (name) + ರವಿ."}]',1)
ON CONFLICT (title, category) DO NOTHING;

INSERT INTO conversations (title, category, level, summary, dialog, quiz, order_idx) VALUES
('Talking to a Teacher','classroom','beginner',
'Basic conversation with a teacher in college.',
'[{"kannada":"ಗುರುಗಳೇ, ನಮಸ್ಕಾರ","transliteration":"Gurugale, namaskara","hindi":"गुरुजी, नमस्ते","english":"Teacher, hello"},{"kannada":"ಈ ಪಾಠ ಕಷ್ಟವಾಗಿದೆ","transliteration":"Ee paaTha kaSHTavaagide","hindi":"यह पाठ कठिन है","english":"This lesson is difficult"},{"kannada":"ದಯವಿಟ್ಟು ವಿವರಿಸಿ","transliteration":"DayaviTTu vivarisi","hindi":"कृपया समझाइए","english":"Please explain"},{"kannada":"ಖಂಡಿತ, ನಾನು ವಿವರಿಸುತ್ತೇನೆ","transliteration":"KhaNDita, naanu vivarisuttene","hindi":"ज़रूर, मैं समझाता हूँ","english":"Sure, I will explain"}]',
'[{"question":"What is ''please explain'' in Kannada?","options":["ದಯವಿಟ್ಟು ವಿವರಿಸಿ","ನಮಸ್ಕಾರ","ಧನ್ಯವಾದ","ಕ್ಷಮಿಸಿ"],"correct_index":0,"explanation":"ದಯವಿಟ್ಟು (please) + ವಿವರಿಸಿ (explain)."}]',2)
ON CONFLICT (title, category) DO NOTHING;

INSERT INTO conversations (title, category, level, summary, dialog, quiz, order_idx) VALUES
('Asking Questions in Class','classroom','beginner',
'Asking a doubt in class.',
'[{"kannada":"ಸರ್, ಒಂದು ಪ್ರಶ್ನೆ ಇದೆ","transliteration":"Sar, ondu prashne ide","hindi":"सर, एक सवाल है","english":"Sir, I have a question"},{"kannada":"ಈ ಉದಾಹರಣೆ ಹೇಗೆ?","transliteration":"Ee udaahaaraNe hege?","hindi":"यह उदाहरण कैसे?","english":"How is this example?"},{"kannada":"ಇದನ್ನು ಮತ್ತೆ ಹೇಳಿ","transliteration":"Idannu matte heLi","hindi":"इसे फिर बताइए","english":"Please say it again"}]',
'[{"question":"''ಒಂದು ಪ್ರಶ್ನೆ ಇದೆ'' means?","options":["I have a question","I am late","I am tired","I am hungry"],"correct_index":0,"explanation":"ಒಂದು (one) + ಪ್ರಶ್ನೆ (question) + ಇದೆ (is)."}]',3)
ON CONFLICT (title, category) DO NOTHING;

INSERT INTO conversations (title, category, level, summary, dialog, quiz, order_idx) VALUES
('Talking to Classmates','classroom','beginner',
'Casual talk with classmates.',
'[{"kannada":"ನಾಳೆ ಪರೀಕ್ಷೆ ಇದೆಯೇ?","transliteration":"Naale parikshe ideye?","hindi":"कल परीक्षा है?","english":"Is there an exam tomorrow?"},{"kannada":"ಹೌದು, ಕಣತ್ತಾ?","transliteration":"Haudu, kaNattaa?","hindi":"हाँ, तैयार?","english":"Yes, ready?"},{"kannada":"ನಾನು ತಯಾರಾಗುತ್ತೇನೆ","transliteration":"Naanu tayaraaguttene","hindi":"मैं तैयार हो जाऊँगा","english":"I will get ready"}]',
'[{"question":"What does ''ನಾಳೆ'' mean?","options":["Today","Tomorrow","Yesterday","Now"],"correct_index":1,"explanation":"ನಾಳೆ = tomorrow."}]',4)
ON CONFLICT (title, category) DO NOTHING;

INSERT INTO conversations (title, category, level, summary, dialog, quiz, order_idx) VALUES
('Asking for Directions','travel','beginner',
'Asking someone for directions.',
'[{"kannada":"ದಯವಿಟ್ಟು, ಸ್ಟೇಷನ್ ಎಲ್ಲಿ?","transliteration":"DayaviTTu, station elli?","hindi":"कृपया, स्टेशन कहाँ?","english":"Please, where is the station?"},{"kannada":"ನೇರ ಹೋಗಿ, ಎಡ ತಿರುಗಿ","transliteration":"Nera hogi, eda tirugi","hindi":"सीधे जाइए, बाएँ मुड़िए","english":"Go straight, turn left"},{"kannada":"ಧನ್ಯವಾದಗಳು","transliteration":"Dhanyavaadagalu","hindi":"धन्यवाद","english":"Thank you"}]',
'[{"question":"How to say ''turn left'' in Kannada?","options":["ಬಲ ತಿರುಗಿ","ನೇರ ಹೋಗಿ","ಎಡ ತಿರುಗಿ","ದಾರಿ ತೋರಿಸಿ"],"correct_index":2,"explanation":"ಎಡ (left) + ತಿರುಗಿ (turn)."}]',5)
ON CONFLICT (title, category) DO NOTHING;

INSERT INTO conversations (title, category, level, summary, dialog, quiz, order_idx) VALUES
('Using Public Transport','transportation','intermediate',
'On a bus asking about stops.',
'[{"kannada":"ಈಗ ಯಾವ ಸ್ಟಾಪ್?","transliteration":"Eega yaava stop?","hindi":"अब कौन सा स्टॉप?","english":"Which stop now?"},{"kannada":"ಮುಂದಿನ ಸ್ಟಾಪ್ ಎಲ್ಲಿ?","transliteration":"Mundina stop elli?","hindi":"अगला स्टॉप कहाँ?","english":"Where is the next stop?"},{"kannada":"ಟಿಕೆಟ್ ಬೇಕು","transliteration":"Tiket beku","hindi":"टिकट चाहिए","english":"I need a ticket"}]',
'[{"question":"What does ''ಟಿಕೆಟ್ ಬೇಕು'' mean?","options":["I need a ticket","Where is the bus","Stop here","Go now"],"correct_index":0,"explanation":"ಟಿಕೆಟ್ (ticket) + ಬೇಕು (need)."}]',6)
ON CONFLICT (title, category) DO NOTHING;

INSERT INTO conversations (title, category, level, summary, dialog, quiz, order_idx) VALUES
('Shopping at a Store','shopping','beginner',
'Buying items at a local shop.',
'[{"kannada":"ಈ ಬೆಲೆ ಎಷ್ಟು?","transliteration":"Ee bele eshTu?","hindi":"इसका दाम कितना?","english":"What is the price of this?"},{"kannada":"ವಜಾ ಕೊಡಿ","transliteration":"Vajaa koDi","hindi":"छूट दीजिए","english":"Give a discount"},{"kannada":"ಎರಡು ಕೊಡಿ","transliteration":"Eradu koDi","hindi":"दो दीजिए","english":"Give two"}]',
'[{"question":"How to ask the price?","options":["ಬೆಲೆ ಎಷ್ಟು?","ಎಲ್ಲಿ?","ಏನು?","ಹೇಗೆ?"],"correct_index":0,"explanation":"ಬೆಲೆ (price) + ಎಷ್ಟು (how much)."}]',7)
ON CONFLICT (title, category) DO NOTHING;

INSERT INTO conversations (title, category, level, summary, dialog, quiz, order_idx) VALUES
('Ordering Food','food','beginner',
'Ordering food at a restaurant.',
'[{"kannada":"ಒಂದು ದೋಸೆ ಬೇಕು","transliteration":"Ondu dose beku","hindi":"एक दोसा चाहिए","english":"I want one dosa"},{"kannada":"ಚಹಾ ಕೂಡ ಬೇಕು","transliteration":"Chaha kooDa beku","hindi":"चाय भी चाहिए","english":"I also want tea"},{"kannada":"ನೀರು ತಗೊಂಡು ಬನ್ನಿ","transliteration":"Neeru tagoNDu banni","hindi":"पानी लाइए","english":"Please bring water"}]',
'[{"question":"What does ''ಒಂದು ದೋಸೆ ಬೇಕು'' mean?","options":["I want two dosas","I want one dosa","I want tea","I want water"],"correct_index":1,"explanation":"ಒಂದು (one) + ದೋಸೆ (dosa) + ಬೇಕು (want)."}]',8)
ON CONFLICT (title, category) DO NOTHING;

INSERT INTO conversations (title, category, level, summary, dialog, quiz, order_idx) VALUES
('Visiting a Hospital','healthcare','intermediate',
'Talking to hospital staff.',
'[{"kannada":"ನನಗೆ ತಲೆ ನೋವು ಇದೆ","transliteration":"Nanage tale novu ide","hindi":"मुझे सिरदर्द है","english":"I have a headache"},{"kannada":"ವೈದ್ಯ ಎಲ್ಲಿ?","transliteration":"Vaidya elli?","hindi":"डॉक्टर कहाँ?","english":"Where is the doctor?"},{"kannada":"ಒಪ್ಪಂದ ಬೇಕು","transliteration":"Oppanda beku","hindi":"अपॉइंटमेंट चाहिए","english":"I need an appointment"}]',
'[{"question":"What does ''ತಲೆ ನೋವು'' mean?","options":["Stomach pain","Headache","Leg pain","Fever"],"correct_index":1,"explanation":"ತಲೆ (head) + ನೋವು (pain) = headache."}]',9)
ON CONFLICT (title, category) DO NOTHING;

INSERT INTO conversations (title, category, level, summary, dialog, quiz, order_idx) VALUES
('Asking for Help at Work','workplace','intermediate',
'Asking a colleague for clarification.',
'[{"kannada":"ಸಹೋದ್ಯೋಗಿ, ಸ್ವಲ್ಪ ಸಹಾಯ","transliteration":"Sahodyogi, swalpa sahaaya","hindi":"सहकर्मी, थोड़ी मदद","english":"Colleague, a little help"},{"kannada":"ಈ ವರದಿ ಹೇಗೆ?","transliteration":"Ee varadi hege?","hindi":"यह रिपोर्ट कैसे?","english":"How is this report?"},{"kannada":"ಮತ್ತೆ ವಿವರಿಸಿ","transliteration":"Matte vivarisi","hindi":"फिर समझाइए","english":"Please explain again"}]',
'[{"question":"What does ''ಸಹಾಯ'' mean?","options":["Help","Report","Work","Meeting"],"correct_index":0,"explanation":"ಸಹಾಯ = help."}]',10)
ON CONFLICT (title, category) DO NOTHING;
