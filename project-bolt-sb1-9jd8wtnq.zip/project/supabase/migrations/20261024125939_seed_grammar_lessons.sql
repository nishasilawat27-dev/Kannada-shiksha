/*
# Seed: 15 grammar lessons
Each lesson has summary, content (jsonb with explanation_en, explanation_hi, sections), and examples (jsonb array of {kannada, transliteration, hindi, english}).
*/

INSERT INTO lessons (title, slug, category, level, summary, content, examples, order_idx) VALUES
('Basic Sentence Structure','grammar-sentence-structure','grammar','beginner',
'Learn how simple Kannada sentences are formed: Subject-Object-Verb order.',
'{"explanation_en":"In Kannada, the typical sentence order is Subject–Object–Verb (SOV). The verb almost always comes last. For example, ''I eat rice'' becomes ''ನಾನು ಅನ್ನ ತಿನ್ನುತ್ತೇನೆ'' (Naanu anna tinnuttene) = I + rice + eat.","explanation_hi":"ಕನ್ನಡದಲ್ಲಿ ವಾಕ್ಯ ಕ್ರಮ: ಕರ್ತೃ–ಕರ್ಮ–ಕ್ರಿಯಾಪದ. ಕ್ರಿಯಾಪದ ಕೊನೆಯಲ್ಲಿ ಬರುತ್ತದೆ. हिंदी की तरह क्रिया अंत में आती है।","sections":[{"heading_en":"Word Order","text_en":"Subject first, object next, verb last.","text_hi":"कर्ता पहले, कर्म बाद में, क्रिया अंत में।"}]}',
'[{"kannada":"ನಾನು ಅನ್ನ ತಿನ್ನುತ್ತೇನೆ","transliteration":"Naanu anna tinnuttene","hindi":"मैं भात खाता हूँ","english":"I eat rice"},{"kannada":"ಅವನು ಪುಸ್ತಕ ಓದುತ್ತಾನೆ","transliteration":"Avanu pustaka ooduttaaane","hindi":"वह किताब पढ़ता है","english":"He reads a book"}]',1)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO lessons (title, slug, category, level, summary, content, examples, order_idx) VALUES
('Pronouns','grammar-pronouns','grammar','beginner',
'Learn the pronouns for I, you, he, she, we, they in Kannada.',
'{"explanation_en":"Kannada pronouns: ನಾನು (naanu) = I, ನೀನು (neenu) = you (informal), ನೀವು (neevu) = you (formal), ಅವನು (avanu) = he, ಅವಳು (avaLu) = she, ಅವರು (avaru) = they (respectful), ನಾವು (naavu) = we (inclusive).","explanation_hi":"कन्नड़ सर्वनाम: ನಾನು = मैं, ನೀನು = तू, ನೀವು = आप, ಅವನು = वह (पुरुष), ಅವಳು = वह (स्त्री), ನಾವು = हम।"}',
'[{"kannada":"ನಾನು","transliteration":"Naanu","hindi":"मैं","english":"I"},{"kannada":"ನೀವು","transliteration":"Neevu","hindi":"आप","english":"You (formal)"},{"kannada":"ಅವರು","transliteration":"Avaru","hindi":"वे","english":"They (respectful)"}]',2)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO lessons (title, slug, category, level, summary, content, examples, order_idx) VALUES
('Nouns','grammar-nouns','grammar','beginner',
'Common Kannada nouns for people, places and things.',
'{"explanation_en":"Nouns name people, places, animals, and things. Kannada nouns have gender (masculine, feminine, neuter) and number. Examples: ಮನುಷ್ಯ (manushya) = person, ಮನೆ (mane) = house, ಹುಡುಗ (huDuga) = boy, ಹುಡುಗಿ (huDugi) = girl.","explanation_hi":"संज्ञा लोग, स्थान, वस्तु के नाम हैं। ಮನುಷ್ಯ = व्यक्ति, ಮನೆ = घर, ಹುಡುಗ = लड़का, ಹುಡುಗಿ = लड़की।"}',
'[{"kannada":"ಮನೆ","transliteration":"Mane","hindi":"घर","english":"House"},{"kannada":"ಮನುಷ್ಯ","transliteration":"Manushya","hindi":"व्यक्ति","english":"Person"}]',3)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO lessons (title, slug, category, level, summary, content, examples, order_idx) VALUES
('Common Verbs','grammar-verbs','grammar','beginner',
'Frequently used Kannada verbs with present tense forms.',
'{"explanation_en":"Key verbs: ಮಾಡು (maadu) = to do, ಹೋಗು (hogu) = to go, ಬರು (baru) = to come, ತಿನ್ನು (tinnu) = to eat, ಕುಡಿ (kudi) = to drink, ನೋಡು (nooDu) = to see. Present tense adds tense suffixes to the verb stem.","explanation_hi":"मुख्य क्रियाएँ: ಮಾಡು = करना, ಹೋಗು = जाना, ಬರು = आना, ತಿನ್ನು = खाना, ಕುಡಿ = पीना, ನೋಡು = देखना।"}',
'[{"kannada":"ನಾನು ಹೋಗುತ್ತೇನೆ","transliteration":"Naanu hoguttene","hindi":"मैं जाता हूँ","english":"I go"},{"kannada":"ಅವನು ಬರುತ್ತಾನೆ","transliteration":"Avanu baruttaaane","hindi":"वह आता है","english":"He comes"}]',4)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO lessons (title, slug, category, level, summary, content, examples, order_idx) VALUES
('Present Tense','grammar-present-tense','grammar','beginner',
'How to express present actions in Kannada.',
'{"explanation_en":"Present tense is formed by adding -ttene/-ttene/-ttare to the verb stem according to person. e.g. ಓದು (oodu) → ನಾನು ಓದುತ್ತೇನೆ (I read), ಅವನು ಓದುತ್ತಾನೆ (he reads), ಅವರು ಓದುತ್ತಾರೆ (they read).","explanation_hi":"वर्तमान काल: ಓದು → ನಾನು ಓದುತ್ತೇನೆ (मैं पढ़ता हूँ), ಅವನು ಓದುತ್ತಾನೆ (वह पढ़ता है)।"}',
'[{"kannada":"ನಾನು ಓದುತ್ತೇನೆ","transliteration":"Naanu ooduttene","hindi":"मैं पढ़ता हूँ","english":"I read"},{"kannada":"ಅವಳು ಹಾಡುತ್ತಾಳೆ","transliteration":"AvaLu haaduttaaLe","hindi":"वह गाती है","english":"She sings"}]',5)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO lessons (title, slug, category, level, summary, content, examples, order_idx) VALUES
('Past Tense','grammar-past-tense','grammar','intermediate',
'How to express completed actions in Kannada.',
'{"explanation_en":"Past tense is formed by adding -tt(idd)e/-d(du) forms. e.g. ಹೋಗು → ನಾನು ಹೋದೆನು (I went), ಅವನು ಹೋದನು (he went), ಅವರು ಹೋದರು (they went).","explanation_hi":"भूत काल: ಹೋಗು → ನಾನು ಹೋದೆನು (मैं गया), ಅವನು ಹೋದನು (वह गया), ಅವರು ಹೋದರು (वे गए)।"}',
'[{"kannada":"ನಾನು ಹೋದೆನು","transliteration":"Naanu hodenu","hindi":"मैं गया","english":"I went"},{"kannada":"ಅವಳು ಬಂದಳು","transliteration":"AvaLu bandaLu","hindi":"वह आई","english":"She came"}]',6)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO lessons (title, slug, category, level, summary, content, examples, order_idx) VALUES
('Future Tense','grammar-future-tense','grammar','intermediate',
'How to express future actions in Kannada.',
'{"explanation_en":"Future tense uses -ttene/-ttini forms. e.g. ನಾನು ಹೋಗುತ್ತೇನೆ (I will go), ಅವನು ಬರುವನು (he will come), ಅವರು ಮಾಡುವರು (they will do).","explanation_hi":"भविष्य काल: ನಾನು ಹೋಗುತ್ತೇನೆ (मैं जाऊँगा), ಅವನು ಬರುವನು (वह आएगा)।"}',
'[{"kannada":"ನಾನು ಬರುತ್ತೇನೆ","transliteration":"Naanu baruttene","hindi":"मैं आऊँगा","english":"I will come"},{"kannada":"ಅವನು ಮಾಡುವನು","transliteration":"Avanu maaduvanu","hindi":"वह करेगा","english":"He will do"}]',7)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO lessons (title, slug, category, level, summary, content, examples, order_idx) VALUES
('Question Words','grammar-question-words','grammar','beginner',
'Words to ask questions: what, why, when, where, who, how.',
'{"explanation_en":"Question words: ಏನು (enu) = what, ಯಾಕೆ (yaake) = why, ಯಾವಾಗ (yaavaga) = when, ಎಲ್ಲಿ (elli) = where, ಯಾರು (yaaru) = who, ಹೇಗೆ (hege) = how. Questions often place the question word at the start or end.","explanation_hi":"प्रश्न शब्द: ಏನು = क्या, ಯಾಕೆ = क्यों, ಯಾವಾಗ = कब, ಎಲ್ಲಿ = कहाँ, ಯಾರು = कौन, ಹೇಗೆ = कैसे।"}',
'[{"kannada":"ನೀವು ಎಲ್ಲಿದ್ದೀರಿ?","transliteration":"Neevu elliddiiri?","hindi":"आप कहाँ हैं?","english":"Where are you?"},{"kannada":"ಏನು ಮಾಡ್ತೀರಿ?","transliteration":"Enu maadtiri?","hindi":"क्या करते हैं?","english":"What are you doing?"}]',8)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO lessons (title, slug, category, level, summary, content, examples, order_idx) VALUES
('Singular and Plural','grammar-plural','grammar','intermediate',
'How to form plurals of Kannada nouns.',
'{"explanation_en":"Plurals are commonly formed with -ಗಳು (gaLu) for neuter nouns, -ರು (ru) for people. e.g. ಮರ → ಮರಗಳು (tree → trees), ಹುಡುಗ → ಹುಡುಗರು (boy → boys).","explanation_hi":"बहुवचन: ಮರ → ಮರಗಳು (पेड़ → पेड़), ಹುಡುಗ → ಹುಡುಗರು (लड़का → लड़के)।"}',
'[{"kannada":"ಮರಗಳು","transliteration":"MaragaLu","hindi":"पेड़","english":"Trees"},{"kannada":"ಹುಡುಗರು","transliteration":"HuDugaru","hindi":"लड़के","english":"Boys"}]',9)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO lessons (title, slug, category, level, summary, content, examples, order_idx) VALUES
('Negation','grammar-negation','grammar','intermediate',
'How to say no or make negative sentences.',
'{"explanation_en":"Negation uses ಇಲ್ಲ (illa) for ''no/not'' and verb + -ಲ (negative suffix). e.g. ನಾನು ಬರುವುದಿಲ್ಲ (I won''t come), ಅವನು ಬಂದಿಲ್ಲ (he didn''t come).","explanation_hi":"नकार: ಇಲ್ಲ = नहीं, ನಾನು ಬರುವುದಿಲ್ಲ = मैं नहीं आऊँगा।"}',
'[{"kannada":"ನಾನು ಬರುವುದಿಲ್ಲ","transliteration":"Naanu baruvudilla","hindi":"मैं नहीं आऊँगा","english":"I will not come"},{"kannada":"ಅವನು ಬಂದಿಲ್ಲ","transliteration":"Avanu bandilla","hindi":"वह नहीं आया","english":"He did not come"}]',10)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO lessons (title, slug, category, level, summary, content, examples, order_idx) VALUES
('Polite Expressions','grammar-polite','grammar','beginner',
'Polite words for respectful conversation.',
'{"explanation_en":"Use ದಯವಿಟ್ಟು (dayaviTTu) for please, ಧನ್ಯವಾದ (dhanyavaada) for thank you, ಕ್ಷಮಿಸಿ (kshamisi) for sorry. Use ನೀವು (neevu) instead of ನೀನು to show respect.","explanation_hi":"विनम्र शब्द: ದಯವಿಟ್ಟು = कृपया, ಧನ್ಯವಾದ = धन्यवाद, ಕ್ಷಮಿಸಿ = माफ़ कीजिए। आदर दिखाने के लिए ನೀವु का प्रयोग करें।"}',
'[{"kannada":"ದಯವಿಟ್ಟು ಬನ್ನಿ","transliteration":"DayaviTTu banni","hindi":"कृपया आइए","english":"Please come"},{"kannada":"ಕ್ಷಮಿಸಿ","transliteration":"Kshamisi","hindi":"माफ़ कीजिए","english":"Sorry"}]',11)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO lessons (title, slug, category, level, summary, content, examples, order_idx) VALUES
('Basic Sentence Formation','grammar-sentence-formation','grammar','beginner',
'Putting words together to form simple Kannada sentences.',
'{"explanation_en":"A simple Kannada sentence = Subject + Object + Verb. e.g. ನಾನು + ಪುಸ್ತಕ + ಓದುತ್ತೇನೆ = I read a book. Add adjectives before nouns: ಒಳ್ಳೆಯ ಪುಸ್ತಕ (good book).","explanation_hi":"ನಾನು + ಪುಸ್ತಕ + ಓದುತ್ತೇನೆ = मैं किताब पढ़ता हूँ।"}',
'[{"kannada":"ನಾನು ಪುಸ್ತಕ ಓದುತ್ತೇನೆ","transliteration":"Naanu pustaka ooduttene","hindi":"मैं किताब पढ़ता हूँ","english":"I read a book"},{"kannada":"ಅವಳು ಒಳ್ಳೆಯ ಹಾಡು ಹಾಡುತ್ತಾಳೆ","transliteration":"AvaLu oLLeya haadu haaduttaaLe","hindi":"वह अच्छा गाना गाती है","english":"She sings a good song"}]',12)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO lessons (title, slug, category, level, summary, content, examples, order_idx) VALUES
('Postpositions','grammar-postpositions','grammar','intermediate',
'Kannada uses case markers (postpositions) attached to nouns.',
'{"explanation_en":"Kannada has postpositions (case suffixes) rather than prepositions. -ಅಲ್ಲಿ (-aLLi) = in/at, -ಗೆ (-ge) = to/for, -ಇಂದ (-inda) = from, -ನ (-na) = of. e.g. ಮನೆಯಲ್ಲಿ (maneyaLLi) = in the house, ಶಾಲೆಗೆ (shaalege) = to school.","explanation_hi":"ಮನೆಯಲ್ಲಿ = घर में, ಶಾಲೆಗೆ = विद्यालय को, -ಇಂದ = से।"}',
'[{"kannada":"ಮನೆಯಲ್ಲಿ","transliteration":"ManeyaLLi","hindi":"घर में","english":"In the house"},{"kannada":"ಶಾಲೆಗೆ","transliteration":"Shaalege","hindi":"विद्यालय को","english":"To school"}]',13)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO lessons (title, slug, category, level, summary, content, examples, order_idx) VALUES
('Adjectives','grammar-adjectives','grammar','intermediate',
'Words that describe nouns.',
'{"explanation_en":"Adjectives come before the noun. Common ones: ಒಳ್ಳೆಯ (oLLeya) = good, ಕೆಟ್ಟ (keTTa) = bad, ದೊಡ್ಡ (doDDa) = big, ಸಣ್ಣ (saNNa) = small, ಹೊಸ (hosa) = new, ಹಳೆಯ (haLeya) = old.","explanation_hi":"ಒಳ್ಳೆಯ = अच्छा, ಕೆಟ್ಟ = बुरा, ದೊಡ್ಡ = बड़ा, ಸಣ್ಣ = छोटा, ಹೊಸ = नया, ಹಳೆಯ = पुराना।"}',
'[{"kannada":"ಒಳ್ಳೆಯ ಮನೆ","transliteration":"OLLeya mane","hindi":"अच्छा घर","english":"Good house"},{"kannada":"ದೊಡ್ಡ ಮರ","transliteration":"DoDDa mara","hindi":"बड़ा पेड़","english":"Big tree"}]',14)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO lessons (title, slug, category, level, summary, content, examples, order_idx) VALUES
('Possessive Forms','grammar-possessive','grammar','advanced',
'How to express possession in Kannada.',
'{"explanation_en":"Possession is shown with -ನ (na) / -ಅ (a) suffix or -ದ (da). e.g. ನನ್ನ (nanna) = my, ನಿನ್ನ (ninna) = your, ಅವನ (avana) = his, ಅವಳ (avaLa) = her, ನಮ್ಮ (namma) = our.","explanation_hi":"ನನ್ನ = मेरा, ನಿನ್ನ = तुम्हारा, ಅವನ = उसका, ಅವಳ = उसका (स्त्री), ನಮ್ಮ = हमारा।"}',
'[{"kannada":"ನನ್ನ ಪುಸ್ತಕ","transliteration":"Nanna pustaka","hindi":"मेरी किताब","english":"My book"},{"kannada":"ಅವನ ಮನೆ","transliteration":"Avana mane","hindi":"उसका घर","english":"His house"}]',15)
ON CONFLICT (slug) DO NOTHING;
