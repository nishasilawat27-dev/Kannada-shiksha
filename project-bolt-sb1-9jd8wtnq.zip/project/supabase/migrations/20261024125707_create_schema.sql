/*
# Kannada Shiksha — core schema

1. Purpose
- Backend for a Kannada learning platform (Kannada Shiksha).
- Multi-user: every registered student owns private progress records.
- Auth uses Supabase email/password. Profiles extend auth.users.

2. New Tables
- `profiles` — extends auth.users: full name, preferred learning language (hi/en), level (beginner/intermediate/advanced), daily_goal (default 3), created_at, updated_at.
- `alphabet` — Kannada letters (vowels + consonants): letter, transliteration, hindi, english, type (vowel/consonant), example_word, example_meaning, order_idx. Public read (shared content).
- `vocabulary` — public Kannada words: kannada, transliteration, hindi, english, example, category, level. Public read.
- `lessons` — public grammar/lesson content: title, slug, category, level, content (jsonb: explanation, examples), order_idx. Public read.
- `conversations` — public conversation scenarios: title, category, level, dialog (jsonb array of {kannada, transliteration, hindi, english}), quiz (jsonb array). Public read.
- `realworld_modules` — public real-world modules (education, travel, shopping, healthcare, transportation, workplace): module_key, title, icon, order_idx. Public read.
- `realworld_phrases` — phrases within a module: module_key, kannada, transliteration, hindi, english, context, quiz (jsonb). Public read.
- `listening_items` — public items for pronunciation practice: kannada, transliteration, hindi, english, level, category. Public read.
- `quiz_questions` — public quiz bank: quiz_key, question, options (jsonb array), correct_index, explanation, level, type. Public read.
- `lesson_completions` — per-user completion of lessons/comversations/etc. user_id (owner), kind, item_id, completed_at. Owner-scoped.
- `quiz_attempts` — per-user quiz results: user_id, quiz_key, score, total, percentage, answers (jsonb), created_at. Owner-scoped.
- `favorite_vocabulary` — per-user saved words: user_id, vocabulary_id, created_at. Owner-scoped.
- `learning_activity` — per-user daily activity log: user_id, activity_date (date), lessons_completed, quizzes_taken, words_learned, unique per (user, date). Owner-scoped.
- `achievements` — catalog of achievements (public read): key, title, description, icon.
- `user_achievements` — per-user earned achievements: user_id, achievement_key, earned_at. Owner-scoped.

3. Security
- Enable RLS on every table.
- Public content tables (alphabet, vocabulary, lessons, conversations, realworld_*, listening_items, quiz_questions, achievements) → SELECT to anon, authenticated.
- Owner-scoped tables (lesson_completions, quiz_attempts, favorite_vocabulary, learning_activity, user_achievements, profiles) → SELECT/INSERT/UPDATE/DELETE to authenticated, scoped by auth.uid() = user_id.
- profiles uses auth.uid() = id (id is the auth user id).
- All owner columns default to auth.uid() so inserts work without passing user_id.
- Unique constraints prevent duplicate activity rows and duplicate favorites and duplicate completions and duplicate achievements.

4. Notes
- No DELETE of columns or tables ever in future migrations; preserve user data.
- Demo data seeding is a separate migration.
*/

-- profiles
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  preferred_lang text NOT NULL DEFAULT 'en' CHECK (preferred_lang IN ('hi','en')),
  level text NOT NULL DEFAULT 'beginner' CHECK (level IN ('beginner','intermediate','advanced')),
  daily_goal int NOT NULL DEFAULT 3,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE ON profiles TO authenticated;
DROP POLICY IF EXISTS "profiles_select_own" ON profiles;
CREATE POLICY "profiles_select_own" ON profiles FOR SELECT TO authenticated USING (auth.uid() = id);
DROP POLICY IF EXISTS "profiles_insert_own" ON profiles;
CREATE POLICY "profiles_insert_own" ON profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- public content tables helper
CREATE TABLE IF NOT EXISTS alphabet (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  letter text NOT NULL,
  transliteration text NOT NULL,
  hindi text NOT NULL DEFAULT '',
  english text NOT NULL DEFAULT '',
  type text NOT NULL CHECK (type IN ('vowel','consonant')),
  example_word text NOT NULL DEFAULT '',
  example_transliteration text NOT NULL DEFAULT '',
  example_meaning text NOT NULL DEFAULT '',
  order_idx int NOT NULL DEFAULT 0
);
ALTER TABLE alphabet ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON alphabet TO anon, authenticated;
DROP POLICY IF EXISTS "alphabet_read" ON alphabet;
CREATE POLICY "alphabet_read" ON alphabet FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS vocabulary (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kannada text NOT NULL,
  transliteration text NOT NULL,
  hindi text NOT NULL DEFAULT '',
  english text NOT NULL DEFAULT '',
  example_kannada text NOT NULL DEFAULT '',
  example_transliteration text NOT NULL DEFAULT '',
  example_meaning text NOT NULL DEFAULT '',
  category text NOT NULL DEFAULT 'general',
  level text NOT NULL DEFAULT 'beginner' CHECK (level IN ('beginner','intermediate','advanced')),
  is_word_of_day boolean NOT NULL DEFAULT false,
  order_idx int NOT NULL DEFAULT 0
);
ALTER TABLE vocabulary ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON vocabulary TO anon, authenticated;
DROP POLICY IF EXISTS "vocab_read" ON vocabulary;
CREATE POLICY "vocab_read" ON vocabulary FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text NOT NULL UNIQUE,
  category text NOT NULL DEFAULT 'grammar',
  level text NOT NULL DEFAULT 'beginner' CHECK (level IN ('beginner','intermediate','advanced')),
  summary text NOT NULL DEFAULT '',
  content jsonb NOT NULL DEFAULT '{}'::jsonb,
  examples jsonb NOT NULL DEFAULT '[]'::jsonb,
  order_idx int NOT NULL DEFAULT 0
);
ALTER TABLE lessons ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON lessons TO anon, authenticated;
DROP POLICY IF EXISTS "lessons_read" ON lessons;
CREATE POLICY "lessons_read" ON lessons FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  category text NOT NULL DEFAULT 'general',
  level text NOT NULL DEFAULT 'beginner' CHECK (level IN ('beginner','intermediate','advanced')),
  summary text NOT NULL DEFAULT '',
  dialog jsonb NOT NULL DEFAULT '[]'::jsonb,
  quiz jsonb NOT NULL DEFAULT '[]'::jsonb,
  order_idx int NOT NULL DEFAULT 0
);
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON conversations TO anon, authenticated;
DROP POLICY IF EXISTS "conv_read" ON conversations;
CREATE POLICY "conv_read" ON conversations FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS realworld_modules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_key text NOT NULL UNIQUE,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  icon text NOT NULL DEFAULT 'GraduationCap',
  order_idx int NOT NULL DEFAULT 0
);
ALTER TABLE realworld_modules ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON realworld_modules TO anon, authenticated;
DROP POLICY IF EXISTS "rw_modules_read" ON realworld_modules;
CREATE POLICY "rw_modules_read" ON realworld_modules FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS realworld_phrases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_key text NOT NULL REFERENCES realworld_modules(module_key) ON DELETE CASCADE,
  kannada text NOT NULL,
  transliteration text NOT NULL,
  hindi text NOT NULL DEFAULT '',
  english text NOT NULL DEFAULT '',
  context text NOT NULL DEFAULT '',
  quiz jsonb NOT NULL DEFAULT '[]'::jsonb,
  order_idx int NOT NULL DEFAULT 0
);
ALTER TABLE realworld_phrases ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON realworld_phrases TO anon, authenticated;
DROP POLICY IF EXISTS "rw_phrases_read" ON realworld_phrases;
CREATE POLICY "rw_phrases_read" ON realworld_phrases FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS listening_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kannada text NOT NULL,
  transliteration text NOT NULL,
  hindi text NOT NULL DEFAULT '',
  english text NOT NULL DEFAULT '',
  level text NOT NULL DEFAULT 'beginner' CHECK (level IN ('beginner','intermediate','advanced')),
  category text NOT NULL DEFAULT 'general',
  order_idx int NOT NULL DEFAULT 0
);
ALTER TABLE listening_items ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON listening_items TO anon, authenticated;
DROP POLICY IF EXISTS "listen_read" ON listening_items;
CREATE POLICY "listen_read" ON listening_items FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS quiz_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quiz_key text NOT NULL,
  question text NOT NULL,
  options jsonb NOT NULL DEFAULT '[]'::jsonb,
  correct_index int NOT NULL DEFAULT 0,
  explanation text NOT NULL DEFAULT '',
  level text NOT NULL DEFAULT 'beginner' CHECK (level IN ('beginner','intermediate','advanced')),
  type text NOT NULL DEFAULT 'mcq',
  order_idx int NOT NULL DEFAULT 0
);
ALTER TABLE quiz_questions ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON quiz_questions TO anon, authenticated;
DROP POLICY IF EXISTS "quiz_read" ON quiz_questions;
CREATE POLICY "quiz_read" ON quiz_questions FOR SELECT TO anon, authenticated USING (true);

-- Owner-scoped tables
CREATE TABLE IF NOT EXISTS lesson_completions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  kind text NOT NULL,
  item_id text NOT NULL,
  item_label text NOT NULL DEFAULT '',
  completed_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, kind, item_id)
);
ALTER TABLE lesson_completions ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, DELETE ON lesson_completions TO authenticated;
DROP POLICY IF EXISTS "lc_select_own" ON lesson_completions;
CREATE POLICY "lc_select_own" ON lesson_completions FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "lc_insert_own" ON lesson_completions;
CREATE POLICY "lc_insert_own" ON lesson_completions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "lc_delete_own" ON lesson_completions;
CREATE POLICY "lc_delete_own" ON lesson_completions FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS quiz_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  quiz_key text NOT NULL,
  quiz_title text NOT NULL DEFAULT '',
  score int NOT NULL DEFAULT 0,
  total int NOT NULL DEFAULT 0,
  percentage numeric NOT NULL DEFAULT 0,
  answers jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE quiz_attempts ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT ON quiz_attempts TO authenticated;
DROP POLICY IF EXISTS "qa_select_own" ON quiz_attempts;
CREATE POLICY "qa_select_own" ON quiz_attempts FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "qa_insert_own" ON quiz_attempts;
CREATE POLICY "qa_insert_own" ON quiz_attempts FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS favorite_vocabulary (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  vocabulary_id uuid NOT NULL REFERENCES vocabulary(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, vocabulary_id)
);
ALTER TABLE favorite_vocabulary ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, DELETE ON favorite_vocabulary TO authenticated;
DROP POLICY IF EXISTS "fv_select_own" ON favorite_vocabulary;
CREATE POLICY "fv_select_own" ON favorite_vocabulary FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "fv_insert_own" ON favorite_vocabulary;
CREATE POLICY "fv_insert_own" ON favorite_vocabulary FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "fv_delete_own" ON favorite_vocabulary;
CREATE POLICY "fv_delete_own" ON favorite_vocabulary FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS learning_activity (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  activity_date date NOT NULL DEFAULT CURRENT_DATE,
  lessons_completed int NOT NULL DEFAULT 0,
  quizzes_taken int NOT NULL DEFAULT 0,
  words_learned int NOT NULL DEFAULT 0,
  UNIQUE (user_id, activity_date)
);
ALTER TABLE learning_activity ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE ON learning_activity TO authenticated;
DROP POLICY IF EXISTS "la_select_own" ON learning_activity;
CREATE POLICY "la_select_own" ON learning_activity FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "la_insert_own" ON learning_activity;
CREATE POLICY "la_insert_own" ON learning_activity FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "la_update_own" ON learning_activity;
CREATE POLICY "la_update_own" ON learning_activity FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  achievement_key text NOT NULL UNIQUE,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  icon text NOT NULL DEFAULT 'Award',
  threshold int NOT NULL DEFAULT 1
);
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON achievements TO anon, authenticated;
DROP POLICY IF EXISTS "ach_read" ON achievements;
CREATE POLICY "ach_read" ON achievements FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS user_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  achievement_key text NOT NULL,
  earned_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, achievement_key)
);
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT ON user_achievements TO authenticated;
DROP POLICY IF EXISTS "ua_select_own" ON user_achievements;
CREATE POLICY "ua_select_own" ON user_achievements FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "ua_insert_own" ON user_achievements;
CREATE POLICY "ua_insert_own" ON user_achievements FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- updated_at trigger for profiles
CREATE OR REPLACE FUNCTION trigger_set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS set_updated_at ON profiles;
CREATE TRIGGER set_updated_at BEFORE UPDATE ON profiles
FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

-- Indexes
CREATE INDEX IF NOT EXISTS idx_vocab_category ON vocabulary(category);
CREATE INDEX IF NOT EXISTS idx_vocab_level ON vocabulary(level);
CREATE INDEX IF NOT EXISTS idx_quiz_key ON quiz_questions(quiz_key);
CREATE INDEX IF NOT EXISTS idx_rw_module ON realworld_phrases(module_key);
CREATE INDEX IF NOT EXISTS idx_lc_user ON lesson_completions(user_id);
CREATE INDEX IF NOT EXISTS idx_qa_user ON quiz_attempts(user_id);
CREATE INDEX IF NOT EXISTS idx_la_user ON learning_activity(user_id, activity_date);
