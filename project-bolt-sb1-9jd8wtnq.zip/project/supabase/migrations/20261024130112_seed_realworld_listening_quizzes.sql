/*
# Seed: real-world phrases for 6 modules + listening items + quiz questions
- realworld_phrases: phrases with kannada, transliteration, hindi, english, context, quiz
- listening_items: pronunciation practice items
- quiz_questions: 10+ questions per quiz_key (beginner, vocabulary, grammar, conversations)
*/

INSERT INTO realworld_phrases (module_key, kannada, transliteration, hindi, english, context, quiz, order_idx) VALUES
-- education
('education','ಗುರುಗಳೇ, ಈ ಪಾಠ ವಿವರಿಸಿ','Gurugale, ee paaTha vivarisi','गुरुजी, यह पाठ समझाइए','Teacher, please explain this lesson','Asking a teacher to explain','[{"question":"What is being asked?","options":["Explain the lesson","Give homework","Bring a book","Open the window"],"correct_index":0,"explanation":"ವಿವರಿಸಿ = explain."}]',1),
('education','ಕ್ಲಾಸ್ ಎಲ್ಲಿ?','Klaas elli?','क्लास कहाँ?','Where is the class?','Finding a classroom','[{"question":"What does the student want to know?","options":["Time of class","Location of class","Teacher name","Subject"],"correct_index":1,"explanation":"ಎಲ್ಲಿ = where."}]',2),
('education','ಪುಸ್ತಕ ತೆಗೆದುಕೊಳ್ಳಿ','Pustaka tegedukoLLi','किताब निकालिए','Take out the book','Classroom instruction','[{"question":"What instruction?","options":["Open the door","Take out the book","Write answers","Stand up"],"correct_index":1,"explanation":"ಪುಸ್ತಕ = book."}]',3),
('education','ಹೋಂವರ್ಕ್ ಮಾಡಿ','Homvark maadi','होमवर्क कीजिए','Do the homework','Teacher instruction','[{"question":"What to do?","options":["Homework","Classwork","Read","Sleep"],"correct_index":0,"explanation":"ಹೋಂವರ್ಕ್ = homework."}]',4),
('education','ಸಹಪಾಠಿ, ಸಹಾಯ ಮಾಡು','SahapaaThi, sahaaya maadu','सहपाठी, मदद करो','Classmate, please help','Asking a classmate','[{"question":"Who is being asked?","options":["Teacher","Classmate","Parent","Friend outside"],"correct_index":1,"explanation":"ಸಹಪಾಠಿ = classmate."}]',5),
-- travel
('travel','ರೈಲು ನಿಲ್ದಾಣ ಎಲ್ಲಿ?','Railu nildaana elli?','रेलवे स्टेशन कहाँ?','Where is the railway station?','Asking directions','[{"question":"What is the person looking for?","options":["Railway station","Bus stop","Airport","Hotel"],"correct_index":0,"explanation":"ರೈಲು ನಿಲ್ದಾಣ = railway station."}]',1),
('travel','ಮೈಸೂರು ಎಷ್ಟು ದೂರ?','Mysuru eshTu doora?','मैसूर कितनी दूर?','How far is Mysuru?','Asking distance','[{"question":"What is being asked?","options":["Time","Distance","Price","Direction"],"correct_index":1,"explanation":"ದೂರ = distance."}]',2),
('travel','ಬೆಂಗಳೂರಿಗೆ ಹೇಗೆ ಹೋಗಬೇಕು?','BengaLuurige hege hogabeku?','बेंगलुरु कैसे जाएँ?','How to go to Bengaluru?','Asking route','[{"question":"What does the person want to know?","options":["How to go","Where to stay","What to eat","When to leave"],"correct_index":0,"explanation":"ಹೇಗೆ = how."}]',3),
('travel','ನೇರ ಹೋಗಿ','Nera hogi','सीधे जाइए','Go straight','Direction','[{"question":"Which direction?","options":["Left","Right","Straight","Back"],"correct_index":2,"explanation":"ನೇರ = straight."}]',4),
-- shopping
('shopping','ಇದರ ಬೆಲೆ ಎಷ್ಟು?','Idara bele eshTu?','इसका दाम कितना?','What is the price of this?','Asking price','[{"question":"What is being asked?","options":["Price","Name","Address","Time"],"correct_index":0,"explanation":"ಬೆಲೆ = price."}]',1),
('shopping','ಒಂದು ಕೆ.ಜಿ ಕೊಡಿ','Ondu kJi koDi','एक किलो दीजिए','Give one kilo','Quantity','[{"question":"How much quantity?","options":["Half kilo","One kilo","Two kilos","One dozen"],"correct_index":1,"explanation":"ಒಂದು ಕೆ.ಜಿ = one kilo."}]',2),
('shopping','ಹತ್ತು ರೂಪಾಯಿ','Hattu roopaayi','दस रुपये','Ten rupees','Price value','[{"question":"What amount?","options":["Five","Ten","Hundred","Thousand"],"correct_index":1,"explanation":"ಹತ್ತು = ten."}]',3),
('shopping','ಚೀಟಿ ಕೊಡಿ','Chiiti koDi','बिल दीजिए','Give the bill','Asking for bill','[{"question":"What is requested?","options":["Discount","Bill","Bag","Money"],"correct_index":1,"explanation":"ಚೀಟಿ = bill."}]',4),
-- healthcare
('healthcare','ನನಗೆ ಜ್ವರ ಇದೆ','Nanage jvara ide','मुझे बुख़ार है','I have a fever','Describing symptom','[{"question":"What symptom?","options":["Fever","Cold","Cough","Pain"],"correct_index":0,"explanation":"ಜ್ವರ = fever."}]',1),
('healthcare','ಔಷಧ ಎಲ್ಲಿ ಸಿಗುತ್ತೆ?','Aushadha elli sigutte?','दवाई कहाँ मिलेगी?','Where can I get medicine?','Finding pharmacy','[{"question":"What is the person looking for?","options":["Doctor","Medicine","Hospital","Ward"],"correct_index":1,"explanation":"ಔಷಧ = medicine."}]',2),
('healthcare','ಈ ವಿಭಾಗ ಎಲ್ಲಿ?','Ee vibhaaga elli?','यह विभाग कहाँ?','Where is this department?','Locating department','[{"question":"What is being asked?","options":["Doctor name","Department location","Ward number","Visiting hours"],"correct_index":1,"explanation":"ವಿಭಾಗ = department."}]',3),
('healthcare','ಒಪ್ಪಂದ ಬೇಕು','Oppanda beku','अपॉइंटमेंट चाहिए','I need an appointment','Booking','[{"question":"What is needed?","options":["Appointment","Medicine","Bill","Report"],"correct_index":0,"explanation":"ಒಪ್ಪಂದ = appointment."}]',4),
-- transportation
('transportation','ಈ ಬಸ್ ಎಲ್ಲಿಗೆ ಹೋಗುತ್ತೆ?','Ee baselligu hogutte?','यह बस कहाँ जाती है?','Where does this bus go?','Asking destination','[{"question":"What is being asked?","options":["Bus time","Bus destination","Bus fare","Bus number"],"correct_index":1,"explanation":"ಎಲ್ಲಿಗೆ = to where."}]',1),
('transportation','ಎಲ್ಲಿ ಇಳಿಯಬೇಕು?','Elli iliyabeku?','कहाँ उतरना है?','Where should I get off?','Asking stop','[{"question":"What is the question about?","options":["Where to get off","Where to board","Bus fare","Bus time"],"correct_index":0,"explanation":"ಇಳಿಯಬೇಕು = to get off."}]',2),
('transportation','ಮುಂದಿನ ಸ್ಟಾಪ್ ಯಾವುದು?','Mundina stop yaavudu?','अगला स्टॉप कौन सा?','Which is the next stop?','Asking stop','[{"question":"What is being asked?","options":["Next stop","Last stop","First stop","Bus number"],"correct_index":0,"explanation":"ಮುಂದಿನ = next."}]',3),
('transportation','ಟಿಕೆಟ್ ಎಷ್ಟು?','Tiket eshTu?','टिकट कितना?','How much is the ticket?','Asking fare','[{"question":"What is being asked?","options":["Fare","Time","Destination","Stop"],"correct_index":0,"explanation":"ಎಷ್ಟು = how much."}]',4),
-- workplace
('workplace','ನಮ್ಮ ಪರಿಚಯ ಮಾಡಿಕೊಳ್ಳೋಣ','Namma parichaya maadikoLLoNa','आइए परिचय कराएँ','Let''s introduce ourselves','Introducing','[{"question":"What is happening?","options":["Introduction","Meeting","Report","Farewell"],"correct_index":0,"explanation":"ಪರಿಚಯ = introduction."}]',1),
('workplace','ಮತ್ತೆ ಒಮ್ಮೆ ಹೇಳಿ','Matte omme heLi','फिर एक बार बताइए','Please say once more','Asking clarification','[{"question":"What is requested?","options":["Repeat","Stop","Start","Leave"],"correct_index":0,"explanation":"ಮತ್ತೆ = again."}]',2),
('workplace','ಸಭೆ ಯಾವಾಗ?','Sabhe yaavaga?','मीटिंग कब?','When is the meeting?','Asking schedule','[{"question":"What is being asked?","options":["Meeting time","Meeting place","Meeting topic","Attendees"],"correct_index":0,"explanation":"ಯಾವಾಗ = when."}]',3),
('workplace','ದಯವಿಟ್ಟು ಸಹಾಯ ಮಾಡಿ','DayaviTTu sahaaya maadi','कृपया मदद कीजिए','Please help','Polite request','[{"question":"What is the tone?","options":["Order","Polite request","Apology","Greeting"],"correct_index":1,"explanation":"ದಯವಿಟ್ಟು = please."}]',4)
ON CONFLICT (module_key, kannada) DO NOTHING;

-- listening items
INSERT INTO listening_items (kannada, transliteration, hindi, english, level, category, order_idx) VALUES
('ನಮಸ್ಕಾರ','Namaskara','नमस्ते','Hello','beginner','greetings',1),
('ಧನ್ಯವಾದಗಳು','Dhanyavaadagalu','धन्यवाद','Thank you','beginner','greetings',2),
('ನಾನು ವಿದ್ಯಾರ್ಥಿ','Naanu vidyaarthi','मैं विद्यಾर्थी हूँ','I am a student','beginner','education',3),
('ಶಾಲೆಗೆ ಹೋಗುತ್ತೇನೆ','Shaalege hoguttene','विद्यालय जाता हूँ','I go to school','beginner','education',4),
('ನೀರು ಕುಡಿಯಿರಿ','Neeru kudiyiri','पानी पीजिए','Please drink water','beginner','food',5),
('ಬೆಲೆ ಎಷ್ಟು?','Bele eshTu?','दाम कितना?','What is the price?','beginner','shopping',6),
('ದಾರಿ ತೋರಿಸಿ','Daari toorisi','रास्ता बताइए','Show the way','beginner','travel',7),
('ಆಸ್ಪತ್ರೆ ಎಲ್ಲಿ?','Aaspatre elli?','अस्पताल कहाँ?','Where is the hospital?','intermediate','healthcare',8),
('ಮುಂದಿನ ಸ್ಟಾಪ್ ಎಲ್ಲಿ?','Mundina stop elli?','अगला स्टॉप कहाँ?','Where is the next stop?','intermediate','transportation',9),
('ಸಭೆ ಯಾವಾಗ?','Sabhe yaavaga?','मीटिंग कब?','When is the meeting?','intermediate','workplace',10)
ON CONFLICT (kannada, category) DO NOTHING;

-- quiz questions: beginner vocabulary quiz (10)
INSERT INTO quiz_questions (quiz_key, question, options, correct_index, explanation, level, type, order_idx) VALUES
('beginner-vocab','What does ನಮಸ್ಕಾರ mean?','["Goodbye","Hello","Sorry","Thanks"]',1,'ನಮಸ್ಕಾರ = Hello','beginner','mcq',1),
('beginner-vocab','What does ಧನ್ಯವಾದಗಳು mean?','["Please","Thanks","Sorry","Welcome"]',1,'ಧನ್ಯವಾದಗಳು = Thank you','beginner','mcq',2),
('beginner-vocab','Choose the Kannada for "Mother".','["ಅಪ್ಪ","ಅಮ್ಮ","ಅಕ್ಕ","ಅಜ್ಜ"]',1,'ಅಮ್ಮ = Mother','beginner','mcq',3),
('beginner-vocab','What is the Kannada for "One"?','["ಎರಡು","ಮೂರು","ಒಂದು","ನಾಲ್ಕು"]',2,'ಒಂದು = One','beginner','mcq',4),
('beginner-vocab','What does ಕೆಂಪು mean?','["Red","Green","Blue","Yellow"]',0,'ಕೆಂಪು = Red','beginner','mcq',5),
('beginner-vocab','What does ನೀರು mean?','["Milk","Water","Juice","Tea"]',1,'ನೀರು = Water','beginner','mcq',6),
('beginner-vocab','Choose the Kannada for "School".','["ಕಾಲೇಜು","ಶಾಲೆ","ಮನೆ","ಕಚೇರಿ"]',1,'ಶಾಲೆ = School','beginner','mcq',7),
('beginner-vocab','What does ಬೆಲೆ mean?','["Price","Name","Place","Time"]',0,'ಬೆಲೆ = Price','beginner','mcq',8),
('beginner-vocab','What does ಆಸ್ಪತ್ರೆ mean?','["School","Hospital","Office","Station"]',1,'ಆಸ್ಪತ್ರೆ = Hospital','beginner','mcq',9),
('beginner-vocab','What does ಬಸ್ mean?','["Train","Bus","Car","Bike"]',1,'ಬಸ್ = Bus','beginner','mcq',10)
ON CONFLICT (quiz_key, question) DO NOTHING;

-- quiz questions: alphabet quiz (10)
INSERT INTO quiz_questions (quiz_key, question, options, correct_index, explanation, level, type, order_idx) VALUES
('alphabet','What sound does ಅ represent?','["a","aa","i","ee"]',0,'ಅ = a','beginner','mcq',1),
('alphabet','What sound does ಆ represent?','["a","aa","i","u"]',1,'ಆ = aa','beginner','mcq',2),
('alphabet','What sound does ಇ represent?','["i","ee","u","oo"]',0,'ಇ = i','beginner','mcq',3),
('alphabet','What sound does ಈ represent?','["i","ee","u","a"]',1,'ಈ = ee','beginner','mcq',4),
('alphabet','What is ಕ?','["ka","kha","ga","gha"]',0,'ಕ = ka','beginner','mcq',5),
('alphabet','What is ಗ?','["ka","kha","ga","nga"]',2,'ಗ = ga','beginner','mcq',6),
('alphabet','What is ಚ?','["cha","chha","ja","jha"]',0,'ಚ = cha','beginner','mcq',7),
('alphabet','What is ತ?','["ta","tha","da","dha"]',0,'ತ = ta','beginner','mcq',8),
('alphabet','What is ಪ?','["pa","pha","ba","bha"]',0,'ಪ = pa','beginner','mcq',9),
('alphabet','What is ಮ?','["ma","ya","ra","la"]',0,'ಮ = ma','beginner','mcq',10)
ON CONFLICT (quiz_key, question) DO NOTHING;

-- quiz questions: grammar quiz (10)
INSERT INTO quiz_questions (quiz_key, question, options, correct_index, explanation, level, type, order_idx) VALUES
('grammar','What is the word order in Kannada?','["S-V-O","S-O-V","V-S-O","O-V-S"]',1,'Kannada uses Subject-Object-Verb order.','beginner','mcq',1),
('grammar','Which pronoun means "I"?','["ನೀನು","ನಾನು","ಅವನು","ನಾವು"]',1,'ನಾನು = I','beginner','mcq',2),
('grammar','Which pronoun is formal "you"?','["ನೀನು","ನೀವು","ಅವನು","ಅವರು"]',1,'ನೀವು = you (formal)','beginner','mcq',3),
('grammar','What does ಮಾಡು mean?','["Go","Come","Do","Eat"]',2,'ಮಾಡು = to do','beginner','mcq',4),
('grammar','How to say "I read" in present tense?','["ನಾನು ಓದುತ್ತೇನೆ","ನಾನು ಓದುತ್ತಿದ್ದೆ","ನಾನು ಓದಿದೆನು","ನಾನು ಓದ್ವೆ"]',0,'ಓದುತ್ತೇನೆ = present tense','beginner','mcq',5),
('grammar','What does ಎಲ್ಲಿ mean?','["What","Where","When","Why"]',1,'ಎಲ್ಲಿ = where','beginner','mcq',6),
('grammar','How to form plural of ಮರ (tree)?','["ಮರರು","ಮರಗಳು","ಮರಿ","ಮರಕ"]',1,'ಮರಗಳು = trees','intermediate','mcq',7),
('grammar','What is the negative form of ಬರು (to come)?','["ಬಂದು","ಬರುವುದಿಲ್ಲ","ಬರುತ್ತೇನೆ","ಬರು"]',1,'ಬರುವುದಿಲ್ಲ = won''t come','intermediate','mcq',8),
('grammar','What does ದಯವಿಟ್ಟು mean?','["Sorry","Thanks","Please","Welcome"]',2,'ದಯವಿಟ್ಟು = please','beginner','mcq',9),
('grammar','What does ನನ್ನ mean?','["Your","My","His","Our"]',1,'ನನ್ನ = my','intermediate','mcq',10)
ON CONFLICT (quiz_key, question) DO NOTHING;

-- quiz questions: conversations quiz (10)
INSERT INTO quiz_questions (quiz_key, question, options, correct_index, explanation, level, type, order_idx) VALUES
('conversations','How do you say "Hello" in Kannada?','["ವಿದಾಯ","ನಮಸ್ಕಾರ","ಧನ್ಯವಾದ","ಕ್ಷಮಿಸಿ"]',1,'ನಮಸ್ಕಾರ = Hello','beginner','mcq',1),
('conversations','How to ask "What is your name?"','["ನಿಮ್ಮ ಹೆಸರು ಏನು?","ನೀವು ಎಲ್ಲಿ?","ಏನು ಮಾಡ್ತೀರಿ?","ಹೇಗೆ ಇದ್ದೀರಿ?"]',0,'ನಿಮ್ಮ ಹೆಸರು ಏನು?','beginner','mcq',2),
('conversations','What does "ದಾರಿ ತೋರಿಸಿ" mean?','["Show the way","Give money","Bring water","Open the door"]',0,'ದಾರಿ = way','beginner','mcq',3),
('conversations','How to say "Please explain"?','["ದಯವಿಟ್ಟು ವಿವರಿಸಿ","ದಯವಿಟ್ಟು ಬನ್ನಿ","ಕ್ಷಮಿಸಿ","ಧನ್ಯವಾದ"]',0,'ದಯವಿಟ್ಟು ವಿವರಿಸಿ','beginner','mcq',4),
('conversations','What does "ಬೆಲೆ ಎಷ್ಟು?" mean?','["What is the time?","What is the price?","Where is it?","How are you?"]',1,'ಬೆಲೆ = price','beginner','mcq',5),
('conversations','How to say "I have a headache"?','["ನನಗೆ ತಲೆ ನೋವು ಇದೆ","ನನಗೆ ಜ್ವರ ಇದೆ","ನನಗೆ ಹಸಿವು ಇದೆ","ನನಗೆ ನಿದ್ರೆ ಇಲ್ಲ"]',0,'ತಲೆ ನೋವು = headache','intermediate','mcq',6),
('conversations','What does "ಮುಂದಿನ ಸ್ಟಾಪ್" mean?','["Last stop","Next stop","First stop","Bus stand"]',1,'ಮುಂದಿನ = next','intermediate','mcq',7),
('conversations','How to ask "Where is the doctor?"','["ವೈದ್ಯ ಎಲ್ಲಿ?","ವೈದ್ಯ ಎಷ್ಟು?","ವೈದ್ಯ ಯಾರು?","ವೈದ್ಯ ಏನು?"]',0,'ಎಲ್ಲಿ = where','intermediate','mcq',8),
('conversations','What does "ಒಂದು ದೋಸೆ ಬೇಕು" mean?','["I want one idli","I want one dosa","I want one tea","I want one roti"]',1,'ದೋಸೆ = dosa','beginner','mcq',9),
('conversations','How to say "Please help"?','["ದಯವಿಟ್ಟು ಸಹಾಯ ಮಾಡಿ","ದಯವಿಟ್ಟು ಬನ್ನಿ","ದಯವಿಟ್ಟು ನಿಲ್ಲಿ","ದಯವಿಟ್ಟು ಹೋಗಿ"]',0,'ಸಹಾಯ ಮಾಡಿ = help me','beginner','mcq',10)
ON CONFLICT (quiz_key, question) DO NOTHING;

-- quiz questions: realworld quiz (10)
INSERT INTO quiz_questions (quiz_key, question, options, correct_index, explanation, level, type, order_idx) VALUES
('realworld','What does "ಗುರುಗಳೇ, ಈ ಪಾಠ ವಿವರಿಸಿ" mean?','["Teacher, give homework","Teacher, explain this lesson","Teacher, open the book","Teacher, come here"]',1,'ವಿವರಿಸಿ = explain','beginner','mcq',1),
('realworld','How to ask "Where is the railway station?"','["ರೈಲು ನಿಲ್ದಾಣ ಎಲ್ಲಿ?","ರೈಲು ಎಷ್ಟು?","ರೈಲು ಯಾವಾಗ?","ರೈಲು ಯಾರು?"]',0,'ಎಲ್ಲಿ = where','intermediate','mcq',2),
('realworld','What does "ಒಂದು ಕೆ.ಜಿ ಕೊಡಿ" mean?','["Give half kilo","Give one kilo","Give two kilos","Give one dozen"]',1,'ಒಂದು ಕೆ.ಜಿ = one kilo','beginner','mcq',3),
('realworld','How to say "I have a fever"?','["ನನಗೆ ಜ್ವರ ಇದೆ","ನನಗೆ ನೋವು ಇದೆ","ನನಗೆ ಹಸಿವು ಇದೆ","ನನಗೆ ನಿದ್ರೆ ಇಲ್ಲ"]',0,'ಜ್ವರ = fever','intermediate','mcq',4),
('realworld','What does "ಈ ಬಸ್ ಎಲ್ಲಿಗೆ ಹೋಗುತ್ತೆ?" mean?','["Where is the bus?","Where does this bus go?","When is the bus?","What is the bus fare?"]',1,'ಎಲ್ಲಿಗೆ = to where','intermediate','mcq',5),
('realworld','How to say "Let''s introduce ourselves"?','["ನಮ್ಮ ಪರಿಚಯ ಮಾಡಿಕೊಳ್ಳೋಣ","ಸಭೆ ಯಾವಾಗ?","ಮತ್ತೆ ಹೇಳಿ","ಸಹಾಯ ಮಾಡಿ"]',0,'ಪರಿಚಯ = introduction','advanced','mcq',6),
('realworld','What does "ಚೀಟಿ ಕೊಡಿ" mean?','["Give a discount","Give the bill","Give a bag","Give money"]',1,'ಚೀಟಿ = bill','beginner','mcq',7),
('realworld','How to ask "Where is this department?"','["ಈ ವಿಭಾಗ ಎಲ್ಲಿ?","ಈ ವಿಭಾಗ ಏನು?","ಈ ವಿಭಾಗ ಯಾರು?","ಈ ವಿಭಾಗ ಎಷ್ಟು?"]',0,'ಎಲ್ಲಿ = where','intermediate','mcq',8),
('realworld','What does "ಎಲ್ಲಿ ಇಳಿಯಬೇಕು?" mean?','["Where to board?","Where to get off?","Where to sit?","Where to stand?"]',1,'ಇಳಿಯಬೇಕು = to get off','intermediate','mcq',9),
('realworld','How to say "Please help"?','["ದಯವಿಟ್ಟು ಸಹಾಯ ಮಾಡಿ","ದಯವಿಟ್ಟು ಬನ್ನಿ","ದಯವಿಟ್ಟು ಹೋಗಿ","ದಯವಿಟ್ಟು ನಿಲ್ಲಿ"]',0,'ಸಹಾಯ = help','beginner','mcq',10)
ON CONFLICT (quiz_key, question) DO NOTHING;
