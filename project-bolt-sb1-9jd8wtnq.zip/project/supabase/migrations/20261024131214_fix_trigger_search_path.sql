/*
# Fix: set immutable search_path on trigger_set_updated_at
Removes the security warning about a mutable search_path on the profiles updated_at trigger function.
*/

CREATE OR REPLACE FUNCTION public.trigger_set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;
