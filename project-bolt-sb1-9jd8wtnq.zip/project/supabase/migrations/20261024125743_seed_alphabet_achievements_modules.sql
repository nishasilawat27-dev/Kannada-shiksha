/*
# Seed: alphabet, achievements, real-world modules, constraints
Adds idempotency unique constraints on public content tables and seeds:
- Kannada vowels and consonants with transliteration, Hindi/English, example words.
- Achievement catalog (6 achievements).
- Real-world module catalog (education, travel, shopping, healthcare, transportation, workplace).
*/

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='alphabet_letter_type_key') THEN
    ALTER TABLE alphabet ADD CONSTRAINT alphabet_letter_type_key UNIQUE (letter, type);
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='vocab_kannada_category_key') THEN
    ALTER TABLE vocabulary ADD CONSTRAINT vocab_kannada_category_key UNIQUE (kannada, category);
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='conv_title_category_key') THEN
    ALTER TABLE conversations ADD CONSTRAINT conv_title_category_key UNIQUE (title, category);
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='rw_phrase_key') THEN
    ALTER TABLE realworld_phrases ADD CONSTRAINT rw_phrase_key UNIQUE (module_key, kannada);
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='listen_key') THEN
    ALTER TABLE listening_items ADD CONSTRAINT listen_key UNIQUE (kannada, category);
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='quiz_key_question_key') THEN
    ALTER TABLE quiz_questions ADD CONSTRAINT quiz_key_question_key UNIQUE (quiz_key, question);
  END IF;
END $$;

-- Alphabet: vowels
INSERT INTO alphabet (letter, transliteration, hindi, english, type, example_word, example_transliteration, example_meaning, order_idx) VALUES
('ಅ','a','अ','a','vowel','ಅಮ್ಮ','Amma','Mother',1),
('ಆ','aa','आ','aa','vowel','ಆನೆ','Aane','Elephant',2),
('ಇ','i','इ','i','vowel','ಇಲಿ','Ili','Mouse',3),
('ಈ','ee','ई','ee','vowel','ಈಗ','Eega','Now',4),
('ಉ','u','उ','u','vowel','ಉಪ್ಪು','Uppu','Salt',5),
('ಊ','oo','ऊ','oo','vowel','ಊಟ','Oota','Food / Meal',6),
('ಋ','ru','ऋ','ru','vowel','ಋಷಿ','Rushi','Sage',7),
('ಎ','e','ए','e','vowel','ಎಲ್ಲಾ','Ellaa','All',8),
('ಏ','ee','ए','ee','vowel','ಏನು','Enu','What',9),
('ಐ','ai','ऐ','ai','vowel','ಐದು','Aidu','Five',10),
('ಒ','o','ओ','o','vowel','ಒಗಲು','Ogalu','Desire',11),
('ಓ','oo','ओ','oo','vowel','ಓದು','Odu','Read',12),
('ಔ','au','औ','au','vowel','ಔಷಧ','Aushadha','Medicine',13)
ON CONFLICT (letter, type) DO NOTHING;

-- Alphabet: consonants
INSERT INTO alphabet (letter, transliteration, hindi, english, type, example_word, example_transliteration, example_meaning, order_idx) VALUES
('ಕ','ka','क','ka','consonant','ಕನ್ನಡ','Kannada','Kannada',14),
('ಖ','kha','ख','kha','consonant','ಖಗ','Khaga','Bird',15),
('ಗ','ga','ग','ga','consonant','ಗಡಿ','Gadi','Border',16),
('ಘ','gha','घ','gha','consonant','ಘಮ','Ghama','Smell',17),
('ಙ','nga','ङ','nga','consonant','ಙಾನ','Ngana','Knowledge',18),
('ಚ','cha','च','cha','consonant','ಚಂದ್ರ','Chandra','Moon',19),
('ಛ','chha','छ','chha','consonant','ಛತ್ರ','Chatra','Umbrella',20),
('ಜ','ja','ज','ja','consonant','ಜನ','Jana','Person',21),
('ಝ','jha','झ','jha','consonant','ಝರಿ','Jhari','Waterfall',22),
('ಞ','nya','ञ','nya','consonant','ಞಮ','Nyama','Night',23),
('ಟ','ta','ट','ta','consonant','ಟಗ','Taga','Stick',24),
('ಠ','tha','ठ','tha','consonant','ಠಣ್ಣ','Thanna','Stingy',25),
('ಡ','da','ड','da','consonant','ಡೊಲ','Dola','Drum',26),
('ಢ','dha','ढ','dha','consonant','ಢಕ','Dhaka','Cover',27),
('ಣ','na','ण','na','consonant','ಣಿ','Ni','To lead',28),
('ತ','ta','त','ta','consonant','ತಾಳು','Taalu','Bear / Tolerate',29),
('ಥ','tha','थ','tha','consonant','ಥಳ','Thala','Place',30),
('ದ','da','द','da','consonant','ದಾರ','Daara','Way',31),
('ಧ','dha','ध','dha','consonant','ಧನ','Dhana','Wealth',32),
('ನ','na','न','na','consonant','ನದಿ','Nadi','River',33),
('ಪ','pa','प','pa','consonant','ಪಡ','Pada','Group',34),
('ಫ','pha','फ','pha','consonant','ಫಲ','Phala','Fruit',35),
('ಬ','ba','ब','ba','consonant','ಬೆಳೆ','Bele','Crop',36),
('ಭ','bha','भ','bha','consonant','ಭಾಷೆ','Bhashe','Language',37),
('ಮ','ma','म','ma','consonant','ಮನ','Mana','Tree',38),
('ಯ','ya','य','ya','consonant','ಯಜ','Yaja','Sacrifice',39),
('ರ','ra','र','ra','consonant','ರಥ','Ratha','Chariot',40),
('ಲ','la','ल','la','consonant','ಲತಾ','Lataa','Creeper',41),
('ವ','va','व','va','consonant','ವನ','Vana','Forest',42),
('ಶ','sha','श','sha','consonant','ಶಬ್ದ','Shabda','Sound',43),
('ಷ','sha','ष','sha','consonant','ಷಟ್','Shat','Six',44),
('ಸ','sa','स','sa','consonant','ಸಮ','Sama','Equal',45),
('ಹ','ha','ह','ha','consonant','ಹಣ','Hana','Money',46),
('ಳ','la','ळ','la','consonant','ಳ','La','A letter',47)
ON CONFLICT (letter, type) DO NOTHING;

-- Achievements
INSERT INTO achievements (achievement_key, title, description, icon, threshold) VALUES
('first_lesson','First Step','Complete your first lesson','BookOpen',1),
('words_25','Word Collector','Learn 25 vocabulary words','Languages',25),
('alphabet_explorer','Alphabet Explorer','Study all Kannada letters','Type',1),
('quiz_champion','Quiz Champion','Score 80% or above in a quiz','Trophy',1),
('conversation_beginner','Conversation Beginner','Complete a conversation scenario','MessageCircle',1),
('streak_7','Week Warrior','Maintain a 7-day learning streak','Flame',7)
ON CONFLICT (achievement_key) DO NOTHING;

-- Real-world modules
INSERT INTO realworld_modules (module_key, title, description, icon, order_idx) VALUES
('education','Education','Classroom communication with teachers and classmates','GraduationCap',1),
('travel','Travel','Asking directions and travel phrases','Map',2),
('shopping','Shopping','Prices, quantities, and items','ShoppingCart',3),
('healthcare','Healthcare','Hospital communication','Stethoscope',4),
('transportation','Transportation','Buses, stops, and getting around','Bus',5),
('workplace','Workplace','Colleague communication','Briefcase',6)
ON CONFLICT (module_key) DO NOTHING;
