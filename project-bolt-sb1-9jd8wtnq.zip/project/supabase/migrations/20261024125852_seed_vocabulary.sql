/*
# Seed: 100+ vocabulary words across 14 categories
Verified Kannada words with transliteration, Hindi + English meanings, example sentences.
Categories: greetings, family, numbers, colors, food, education, classroom, travel, shopping, healthcare, transportation, workplace, questions, common.
Each row: (kannada, transliteration, hindi, english, example_kannada, example_transliteration, example_meaning, category, level, order_idx)
*/

INSERT INTO vocabulary (kannada, transliteration, hindi, english, example_kannada, example_transliteration, example_meaning, category, level, order_idx) VALUES
-- greetings
('ನಮಸ್ಕಾರ','Namaskara','नमस्ते','Hello','ನಮಸ್ಕಾರ, ಹೇಗಿದ್ದೀರಿ?','Namaskara, heggiddiiri?','Hello, how are you?','greetings','beginner',1),
('ಧನ್ಯವಾದಗಳು','Dhanyavaadagalu','धन्यवाद','Thank you','ಧನ್ಯವಾದಗಳು ಗುರುಗಳೇ','Dhanyavaadagalu gurugale','Thank you, teacher','greetings','beginner',2),
('ಕ್ಷಮಿಸಿ','Kshamisi','माफ़ कीजिए','Sorry','ಕ್ಷಮಿಸಿ, ತಡವಾಯಿತು','Kshamisi, tadavaayitu','Sorry, I am late','greetings','beginner',3),
('ಒಳಗೆ ಬನ್ನಿ','Olge banni','अंदर आइए','Please come in','ಒಳಗೆ ಬನ್ನಿ, ಕೂತುಕೊಳ್ಳಿ','Olge banni, kootukoLi','Please come in and sit','greetings','beginner',4),
('ಶುಭೋದಯ','Shubhodaya','सुप्रभात','Good morning','ಶುಭೋದಯ, ಎಲ್ಲರಿಗೂ','Shubhodaya, ellarigoo','Good morning, to all','greetings','beginner',5),
('ಶುಭ ರಾತ್ರಿ','Shubha raatri','शुभ रात्रि','Good night','ಶುಭ ರಾತ್ರಿ, ನಿದ್ರಿಸಿ','Shubha raatri, nidrisi','Good night, sleep well','greetings','beginner',6),
('ವಿದಾಯ','Vidaaya','विदाई','Goodbye','ವಿದಾಯ, ಮತ್ತೆ ಸಿಗೋಣ','Vidaaya, matte sigona','Goodbye, see you again','greetings','beginner',7),
('ಸ್ವಾಗತ','Swaagata','स्वागत है','Welcome','ನಮ್ಮ ಮನೆಗೆ ಸ್ವಾಾಗತ','Namma manige swaagata','Welcome to our home','greetings','beginner',8),
-- family
('ಅಮ್ಮ','Amma','माँ','Mother','ನನ್ನ ಅಮ್ಮ ಬಹಳ ಒಳ್ಳೆಯವರು','Nanna amma bahaLa oLLeyavaru','My mother is very kind','family','beginner',9),
('ಅಪ್ಪ','Appa','पिता','Father','ಅಪ್ಪ ಅಫೀಸಿಗೆ ಹೋದರು','Appa officege hodaru','Father went to office','family','beginner',10),
('ಅಣ್ಣ','Anna','बड़ा भाई','Elder brother','ಅಣ್ಣ ಓದುತ್ತಾರೆ','Anna oodut taare','Elder brother is studying','family','beginner',11),
('ಅಕ್ಕ','Akka','बड़ी बहन','Elder sister','ಅಕ್ಕ ಊಟ ಮಾಡಿದರು','Akka oota maadidaru','Elder sister ate food','family','beginner',12),
('ತಮ್ಮ','Thamma','छोटा भाई','Younger brother','ತಮ್ಮ ಆಟವಾಡುತ್ತಾನೆ','Thamma aaTavaadut taane','Younger brother is playing','family','beginner',13),
('ತಂಗಿ','Thangi','छोटी बहन','Younger sister','ತಂಗಿ ಶಾಲೆಗೆ ಹೋದಳು','Thangi shaalege hodalu','Younger sister went to school','family','beginner',14),
('ಅಜ್ಜ','Ajja','दादा','Grandfather','ಅಜ್ಜ ಕಥೆ ಹೇಳುತ್ತಾರೆ','Ajja kathe heLut taare','Grandfather tells stories','family','beginner',15),
('ಅಜ್ಜಿ','Ajji','दादी','Grandmother','ಅಜ್ಜಿ ಒಗ್ಗರಣೆ ಮಾಡ್ತಾರೆ','Ajji oggaraNe maadtaare','Grandmother is cooking','family','beginner',16),
('ಮಗ','Maga','बेटा','Son','ಮಗ ಚೆನ್ನಾಗಿ ಓದುತ್ತಾನೆ','Maga chennaagi oodut taane','Son studies well','family','intermediate',17),
('ಮಗಳು','Magalu','बेटी','Daughter','ಮಗಳು ನೃತ್ಯ ಮಾಡುತ್ತಾಳೆ','Magalu nruTya maadut taale','Daughter dances','family','intermediate',18),
-- numbers
('ಒಂದು','Ondu','एक','One','ಒಂದು ಸೇಬು','Ondu sebu','One apple','numbers','beginner',19),
('ಎರಡು','Eradu','दो','Two','ಎರಡು ಕೂಡಿಲು','Eradu kudiL u','Two rooms','numbers','beginner',20),
('ಮೂರು','Mooru','तीन','Three','ಮೂರು ಹಕ್ಕಿಗಳು','Mooru hakki gaLu','Three birds','numbers','beginner',21),
('ನಾಲ್ಕು','Naalku','चार','Four','ನಾಲ್ಕು ಚಕ್ರ','Naalku chakra','Four wheels','numbers','beginner',22),
('ಐದು','Aidu','पाँच','Five','ಐದು ಬೆರಳು','Aidu beraLu','Five fingers','numbers','beginner',23),
('ಆರು','Aaru','छह','Six','ಆರು ವರುಷ','Aaru varsha','Six years','numbers','beginner',24),
('ಏಳು','Eelu','सात','Seven','ಏಳು ದಿನ','Eelu dina','Seven days','numbers','beginner',25),
('ಎಂಟು','Entu','आठ','Eight','ಎಂಟು ಮಣು','Entu manu','Eight people','numbers','beginner',26),
('ಒಂಬತ್ತು','Ombattu','नौ','Nine','ಒಂಬತ್ತು ಗಡಿಯಾರ','Ombattu gadiyaara','Nine clocks','numbers','beginner',27),
('ಹತ್ತು','Hattu','दस','Ten','ಹತ್ತು ಹೂವು','Hattu hoovu','Ten flowers','numbers','beginner',28),
-- colors
('ಕೆಂಪು','Kempu','लाल','Red','ಕೆಂಪು ಹೂವು','Kempu hoovu','Red flower','colors','beginner',29),
('ಹಸಿರು','Hasiru','हरा','Green','ಹಸಿರು ಮರ','Hasiru mara','Green tree','colors','beginner',30),
('ನೀಲಿ','Neeli','नीला','Blue','ನೀಲಿ ಆಕಾಶ','Neeli aakasha','Blue sky','colors','beginner',31),
('ಹಳದಿ','HaLadi','पीला','Yellow','ಹಳದಿ ಬಣ್ಣ','HaLadi baNNa','Yellow color','colors','beginner',32),
('ಬಿಳಿ','BiLi','सफ़ेद','White','ಬಿಳಿ ಬಟ್ಟೆ','BiLi baTTe','White cloth','colors','beginner',33),
('ಕಪ್ಪು','Kappu','काला','Black','ಕಪ್ಪು ಕೆಲಾಸ','Kappu kelaasa','Black dress','colors','beginner',34),
('ಕಿತ್ತಳೆ','KittaLe','नारंगी','Orange','ಕಿತ್ತಳೆ ಹಣ್ಣು','KittaLe haNNu','Orange fruit','colors','intermediate',35),
('ಕಂದು','Kandu','भूरा','Brown','ಕಂದು ನೆಲ','Kandu nela','Brown floor','colors','intermediate',36),
-- food
('ಅನ್ನ','Anna','भात/चावल','Rice','ಅನ್ನ ತಿನ್ನಿ','Anna tinni','Eat rice','food','beginner',37),
('ನೀರು','Neeru','पानी','Water','ನೀರು ಕುಡಿಯಿರಿ','Neeru kudiyiri','Drink water','food','beginner',38),
('ಹಾಲು','Haalu','दूध','Milk','ಹಾಲು ಕುಡಿಯುತ್ತೇನೆ','Haalu kudiyuttene','I drink milk','food','beginner',39),
('ರೊಟ್ಟಿ','RoTTi','रोटी','Bread/roti','ರೊಟ್ಟಿ ತಿನ್ನಿ','RoTTi tinni','Eat roti','food','beginner',40),
('ತರಕಾರಿ','Tarakaari','सब्ज़ी','Vegetables','ತರಕಾರಿ ಖರೀದಿಸಿ','Tarakaari khareedisi','Buy vegetables','food','beginner',41),
('ಹಣ್ಣು','HaNNu','फल','Fruit','ಹಣ್ಣು ತಿನ್ನಿ','HaNNu tinni','Eat fruit','food','beginner',42),
('ಊಟ','Oota','भोजन','Meal','ಊಟ ಮಾಡಿ','Oota maadi','Have a meal','food','beginner',43),
('ಚಹಾ','Chaha','चाय','Tea','ಚಹಾ ಕುಡಿಯಿರಿ','Chaha kudiyiri','Drink tea','food','beginner',44),
('ಕಾಫಿ','Kaafi','कॉफ़ी','Coffee','ಕಾಫಿ ಬೇಕು','Kaafi beku','I want coffee','food','beginner',45),
('ಸಕ್ಕರೆ','Sakkare','चीनी','Sugar','ಸಕ್ಕರೆ ಸ್ವಲ್ಪ','Sakkare swalpa','A little sugar','food','intermediate',46),
('ಉಪ್ಪು','Uppu','नमक','Salt','ಉಪ್ಪು ಹಾಕಿ','Uppu haaki','Add salt','food','intermediate',47),
-- education
('ಶಾಲೆ','Shaale','विद्यालय','School','ಶಾಲೆಗೆ ಹೋಗು','Shaalege hogu','Go to school','education','beginner',48),
('ಕಾಲೇಜು','Kaalazu','कॉलेज','College','ಕಾಲೇಜಿನಲ್ಲಿ ಓದುತ್ತೇನೆ','KaalazinaLLi ooduttene','I study in college','education','beginner',49),
('ಪುಸ್ತಕ','Pustaka','किताब','Book','ಪುಸ್ತಕ ಓದಿ','Pustaka odi','Read a book','education','beginner',50),
('ಪೆನ್ನು','Pennu','कलम','Pen','ಪೆನ್ನು ತಗೊ','Pennu tago','Take the pen','education','beginner',51),
('ಬ್ಯಾಗ್','Byaag','बैग','Bag','ಬ್ಯಾಗ್ ತುಂಬಿದೆ','Byaag tumbide','Bag is full','education','beginner',52),
('ಟೇಬಲ್','Teabal','मेज़','Table','ಟೇಬಲ್ ಮೇಲೆ ಇಡಿ','Teabal mele iDi','Put on the table','education','beginner',53),
('ಪಾಠ','PaaTha','पाठ','Lesson','ಪಾಠ ಓದಿ','PaaTha odi','Read the lesson','education','beginner',54),
('ಮಾಸ್ತರು','Maastaru','शिक्षक','Teacher (male)','ಮಾಸ್ತರು ಬಂದರು','Maastaru bandaru','Teacher came','education','beginner',55),
('ಗುರು','Guru','गुरु','Teacher','ಗುರು ಹೇಳಿದರು','Guru heLidaru','Teacher said','education','intermediate',56),
('ವಿದ್ಯಾರ್ಥಿ','Vidyaarthi','विद्यार्थी','Student','ವಿದ್ಯಾರ್ಥಿ ಕಲಿಯುತ್ತಾನೆ','Vidyaarthi kaliyut taane','Student learns','education','intermediate',57),
-- classroom
('ವಿಷಯ','Vishaya','विषय','Subject','ಗಣಿತ ವಿಷಯ','GaNita vishaya','Math subject','classroom','intermediate',58),
('ಪರೀಕ್ಷೆ','Parikshe','परीक्षा','Exam','ಪರೀಕ್ಷೆ ಬರುತ್ತಿದೆ','Parikshe baruttide','Exam is coming','classroom','intermediate',59),
('ಪ್ರಶ್ನೆ','Prashne','सवाल','Question','ಪ್ರಶ್ನೆ ಕೇಳಿ','Prashne keeLi','Ask a question','classroom','beginner',60),
('ಉತ್ತರ','Uttara','जवाब','Answer','ಉತ್ತರ ಬರಿ','Uttara bari','Write the answer','classroom','beginner',61),
('ಹೋಂವರ್ಕ್','Homvark','होमवर्क','Homework','ಹೋಂವರ್ಕ್ ಮಾಡಿ','Homvark maadi','Do the homework','classroom','beginner',62),
('ಕ್ಲಾಸ್','Klaas','क्लास','Class','ಕ್ಲಾಸ್ ಇದೆ','Klaas ide','There is class','classroom','beginner',63),
('ಮಾರ್ಕ್ಸ್','Maarks','अंक','Marks','ಮಾರ್ಕ್ಸ್ ಬಂದಿವೆ','Maarks bandive','Marks have come','classroom','beginner',64),
('ಮರೆಯಬೇಡಿ','MareyabeDi','मत भूलि�ो','Do not forget','ಮರೆಯಬೇಡಿ ತರ','MareyabeDi tara','Don''t forget to bring','classroom','intermediate',65),
('ಮತ್ತೆ ಕೇಳಿ','Matte keeLi','फिर पूछिए','Ask again','ಮತ್ತೆ ಕೇಳಿ ಸ್ವಲ್ಪ','Matte keeLi swalpa','Please ask again','classroom','intermediate',66),
-- travel
('ಎಲ್ಲಿ','Elli','कहाँ','Where','ನೀವು ಎಲ್ಲಿದ್ದೀರಿ?','Neevu elliddiiri?','Where are you?','travel','beginner',67),
('ದಾರಿ','Daari','रास्ता','Way/road','ದಾರಿ ತೋರಿಸಿ','Daari toorisi','Show the way','travel','beginner',68),
('ಎಡ','Eda','बाएँ','Left','ಎಡ ತಿರುಗಿ','Eda tirugi','Turn left','travel','beginner',69),
('ಬಲ','Bala','दाएँ','Right','ಬಲ ತಿರುಗಿ','Bala tirugi','Turn right','travel','beginner',70),
('ನೇರ','Nera','सीधा','Straight','ನೇರ ಹೋಗಿ','Nera hogi','Go straight','travel','beginner',71),
('ಸ್ಟೇಷನ್','Station','स्टेशन','Station','ಸ್ಟೇಷನ್ ಎಲ್ಲಿ?','Station elli?','Where is the station?','travel','beginner',72),
('ಸ್ಟಾಪ್','Stop','स्टॉप','Stop','ಮುಂದಿನ ಸ್ಟಾಪ್','Mundina stop','Next stop','travel','beginner',73),
('ದೂರ','Doora','दूर','Far','ದೂರ ಇಲ್ಲ','Doora illa','Not far','travel','beginner',74),
('ಹತ್ತಿರ','Hattira','पास','Near','ಹತ್ತಿರ ಇದೆ','Hattira ide','It is near','travel','beginner',75),
-- shopping
('ಬೆಲೆ','Bele','दाम','Price','ಬೆಲೆ ಎಷ್ಟು?','Bele eshTu?','What is the price?','shopping','beginner',76),
('ಎಷ್ಟು','EshTu','कितना','How much','ಎಷ್ಟು ಬೇಕು?','EshTu beku?','How much do you want?','shopping','beginner',77),
('ಖರೀದಿಸಿ','Khareedisi','ख़रीदें','Buy','ಖರೀದಿಸಿ ಸ್ವಲ್ಪ','Khareedisi swalpa','Buy a little','shopping','beginner',78),
('ವಜಾ','Vajaa','छूट','Discount','ವಜಾ ಕೊಡಿ','Vajaa koDi','Give a discount','shopping','intermediate',79),
('ಹಣ','Hana','पैसे','Money','ಹಣ ಕೊಡಿ','Hana koDi','Give money','shopping','beginner',80),
('ಚೀಟಿ','Chiiti','बिल/रसीद','Bill/receipt','ಚೀಟಿ ಕೊಡಿ','Chiiti koDi','Give the bill','shopping','intermediate',81),
('ಒಗ್ಗರಣೆ','OggaraNe','किराना','Groceries','ಒಗ್ಗರಣೆ ಖರೀದಿಸಿ','OggaraNe khareedisi','Buy groceries','shopping','intermediate',82),
('ಖರ್ಚು','Kharchu','खर्च','Expense','ಖರ್ಚು ಜಾಸ್ತಿ','Kharchu jaasti','Expenses are high','shopping','intermediate',83),
-- healthcare
('ಆಸ್ಪತ್ರೆ','Aaspatre','अस्पताल','Hospital','ಆಸ್ಪತ್ರೆ ಎಲ್ಲಿ?','Aaspatre elli?','Where is the hospital?','healthcare','beginner',84),
('ವೈದ್ಯ','Vaidya','डॉक्टर','Doctor','ವೈದ್ಯ ಬಂದರು','Vaidya bandaru','Doctor came','healthcare','beginner',85),
('ಔಷಧ','Aushadha','दवाई','Medicine','ಔಷಧ ತಗೊ','Aushadha tago','Take medicine','healthcare','beginner',86),
('ಜ್ವರ','Jvara','बुख़ार','Fever','ಜ್ವರ ಇದೆ','Jvara ide','I have fever','healthcare','beginner',87),
('ನೋವು','Novu','दर्द','Pain','ತಲೆ ನೋವು','Tale novu','Headache','healthcare','beginner',88),
('ಅಪಾಯಂತಮ','Apaayantama','आपातकाल','Emergency','ಅಪಾಯಂತಮ ಇದೆ','Apaayantama ide','It is an emergency','healthcare','intermediate',89),
('ಒಪ್ಪಂದ','Oppanda','अपॉइंटमेंट','Appointment','ಒಪ್ಪಂದ ಬೇಕು','Oppanda beku','Need an appointment','healthcare','intermediate',90),
('ರೋಗಿ','Rogi','मरीज़','Patient','ರೋಗಿ ಇದ್ದಾರೆ','Rogi iddaare','There is a patient','healthcare','intermediate',91),
-- transportation
('ಬಸ್','Bas','बस','Bus','ಬಸ್ ಬಂತು','Bas banthu','Bus came','transportation','beginner',92),
('ಟಿಕೆಟ್','Tiket','टिकट','Ticket','ಟಿಕೆಟ್ ಬೇಕು','Tiket beku','Need a ticket','transportation','beginner',93),
('ಇಳಿಯಿರಿ','Iliyiri','उतरिए','Get down','ಮುಂದೆ ಇಳಿಯಿರಿ','Munde iliyiri','Get down at the next stop','transportation','beginner',94),
('ಏರಿ','Eri','चढ़िए','Board/get on','ಬಸ್ ಏರಿ','Bas eri','Board the bus','transportation','beginner',95),
('ಎಲ್ಲಿ ಇಳಿಯಬೇಕು','Elli iliyabeku','कहाँ उतरना है','Where to get off','ಎಲ್ಲಿ ಇಳಿಯಬೇಕು?','Elli iliyabeku?','Where should I get off?','transportation','intermediate',96),
('ಮುಂದಿನ ಸ್ಟಾಪ್','Mundina stop','अगला स्टॉप','Next stop','ಮುಂದಿನ ಸ್ಟಾಪ್ ಎಲ್ಲಿ?','Mundina stop elli?','Where is the next stop?','transportation','intermediate',97),
('ಕಾಲ','Kaala','समय','Time','ಕಾಲ ಎಷ್ಟು?','Kaala eshTu?','What time is it?','transportation','beginner',98),
-- workplace
('ಕಚೇರಿ','Kacheri','दफ़्तर','Office','ಕಚೇರಿಗೆ ಹೋಗುತ್ತೇನೆ','Kacherige hoguttene','I am going to office','workplace','beginner',99),
('ಸಹೋದ್ಯೋಗಿ','Sahodyogi','सहकर्मी','Colleague','ಸಹೋದ್ಯೋಗಿ ಒಳ್ಳೆಯವರು','Sahodyogi oLLeyavaru','Colleague is good','workplace','intermediate',100),
('ಸಭೆ','Sabhe','मीटिंग','Meeting','ಸಭೆ ಇದೆ','Sabhe ide','There is a meeting','workplace','intermediate',101),
('ಕೆಲಸ','Kelasa','काम','Work','ಕೆಲಸ ಮಾಡಿ','Kelasa maadi','Do the work','workplace','beginner',102),
('ವಿಳಂಬ','ViLamba','देरी','Delay','ವಿಳಂಬವಾಯಿತು','ViLambavaayitu','It got delayed','workplace','advanced',103),
('ಅನುಮತಿ','Anumati','अनुमति','Permission','ಅನುಮತಿ ಬೇಕು','Anumati beku','Need permission','workplace','advanced',104),
('ವರದಿ','Varadi','रिपोर्ट','Report','ವರದಿ ಸಿದ್ಧ','Varadi siddha','Report is ready','workplace','advanced',105),
-- questions
('ಏನು','Enu','क्या','What','ಇದು ಏನು?','Idu enu?','What is this?','questions','beginner',106),
('ಯಾಕೆ','Yaake','क्यों','Why','ಯಾಕೆ ಬಂದಿಲ್ಲ?','Yaake bandilla?','Why didn''t you come?','questions','beginner',107),
('ಯಾವಾಗ','Yaavaga','कब','When','ಯಾವಾಗ ಬರುತ್ತೀರಿ?','Yaavaga baruttiiri?','When will you come?','questions','beginner',108),
('ಹೇಗೆ','Hege','कैसे','How','ಹೇಗೆ ಮಾಡ್ವೆ?','Hege maadve?','How to do?','questions','beginner',109),
('ಯಾರು','Yaaru','कौन','Who','ಯಾರು ಬಂದರು?','Yaaru bandaru?','Who came?','questions','beginner',110),
-- common
('ಇದು','Idu','यह','This','ಇದು ಒಳ್ಳೆಯದು','Idu oLLeyadu','This is good','common','beginner',111),
('ಅದು','Adu','वह','That','ಅದು ನನ್ನದು','Adu nannadu','That is mine','common','beginner',112),
('ಒಳ್ಳೆಯದು','OLleyadu','अच्छा','Good','ಒಳ್ಳೆಯದು ಇದು','OLleyadu idu','This is good','common','beginner',113),
('ಕೆಟ್ಟದ್ದು','Kettaddu','बुरा','Bad','ಕೆಟ್ಟದ್ದು ಇಲ್ಲ','Kettaddu illa','It is not bad','common','beginner',114),
('ಬೇಗ','Bega','जल्दी','Quickly','ಬೇಗ ಬನ್ನಿ','Bega banni','Come quickly','common','beginner',115),
('ಮುಂದೆ','Munde','आगे','Ahead/later','ಮುಂದೆ ನೋಡಿ','Munde nooDi','See ahead','common','intermediate',116),
('ಈಗ','Eega','अभी/अब','Now','ಈಗ ಬನ್ನಿ','Eega banni','Come now','common','beginner',117),
('ನಾಳೆ','Naale','कल','Tomorrow','ನಾಳೆ ಬರ್ತೀನಿ','Naale barteeni','I will come tomorrow','common','beginner',118),
('ಇಲ್ಲ','Illa','नहीं','No','ಇಲ್ಲ, ಬೇಡ','Illa, beDa','No, don''t','common','beginner',119),
('ಹೌದು','Haudu','हाँ','Yes','ಹೌದು, ಒಳ್ಳೆಯದು','Haudu, oLLeyadu','Yes, it is good','common','beginner',120),
('ಬೇಕು','Beku','चाहिए','Want/need','ನನಗೆ ಬೇಕು','Nanage beku','I want it','common','beginner',121),
('ಬೇಡ','BeDa','मत','Don''t want','ಅದು ಬೇಡ','Adu beDa','Don''t want that','common','beginner',122)
ON CONFLICT (kannada, category) DO NOTHING;

-- word of the day flag
UPDATE vocabulary SET is_word_of_day = true
WHERE id IN (
  SELECT id FROM vocabulary WHERE kannada = 'ನಮಸ್ಕಾರ' LIMIT 1
);
