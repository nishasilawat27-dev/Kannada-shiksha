/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eef6ff',
          100: '#d9ebff',
          200: '#bcdcff',
          300: '#8ec6ff',
          400: '#59a6ff',
          500: '#3585ff',
          600: '#1f66f5',
          700: '#1851dc',
          800: '#1a43b0',
          900: '#1b3a8a',
          950: '#142455',
        },
        leaf: {
          50: '#effaf2',
          100: '#d8f3df',
          200: '#b3e6c3',
          300: '#80d3a0',
          400: '#46b977',
          500: '#22a05c',
          600: '#15804a',
          700: '#12663d',
          800: '#105233',
          900: '#0d442b',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
        kannada: ['"Noto Sans Kannada"', '"Noto Serif Kannada"', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 3px 0 rgba(20,36,85,0.08), 0 1px 2px -1px rgba(20,36,85,0.06)',
        soft: '0 4px 20px -2px rgba(20,36,85,0.10)',
      },
      keyframes: {
        'fade-in': {
          '0%': { opacity: '0', transform: 'translateY(6px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'pop': {
          '0%': { transform: 'scale(0.96)' },
          '60%': { transform: 'scale(1.02)' },
          '100%': { transform: 'scale(1)' },
        },
      },
      animation: {
        'fade-in': 'fade-in 0.25s ease-out',
        'pop': 'pop 0.2s ease-out',
      },
    },
  },
  plugins: [],
};
