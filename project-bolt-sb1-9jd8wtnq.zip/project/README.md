# Kannada Shiksha — Learn Kannada Easily

A complete, modern Kannada learning platform that helps students and beginners learn Kannada through Hindi and English, focused on real-world education.

Built around the problem statement: *"Kannada in Everyday Life: Develop a technology solution that helps people learn and use Kannada in real-world situations such as travelling, shopping, education, healthcare, transportation, and workplaces."*

## Features

- **Kannada Alphabet** — vowels (ಸ್ವರಗಳು) and consonants (ವ್ಯಂಜನಗಳು) with transliteration, audio, and example words.
- **Vocabulary** — 120+ verified words across 14 categories with search, filters, favorites, recently viewed, and word-of-the-day.
- **Grammar Lessons** — 15 structured lessons with explanations in Hindi and English, Kannada examples, and completion tracking.
- **Daily Conversations** — 20+ real dialogue scenarios with audio, role-play practice, and comprehension quizzes.
- **Real-World Kannada** — 6 modules (education, travel, shopping, healthcare, transportation, workplace) with phrases and scenario quizzes. Education is prioritized.
- **Listening & Pronunciation** — browser Text-to-Speech playback, microphone recording, and optional Kannada speech recognition comparison.
- **Practice Quizzes** — 5 quizzes with 10 questions each, one question at a time, instant feedback, review, and saved scores.
- **AI Learning Assistant** — chat interface with verified offline knowledge fallback (API key optional).
- **Progress & Achievements** — real activity charts, quiz history, category progress, and earnable achievement badges.
- **Profile & Settings** — update name, preferred language (Hindi/English), level, daily goal, and review saved vocabulary.
- **Authentication** — secure email/password accounts with per-user data isolation via Row Level Security. Includes a demo account.

## Tech Stack

- **Frontend:** React + TypeScript, Vite
- **Styling:** Tailwind CSS
- **Routing:** React Router
- **Database & Auth:** Supabase (PostgreSQL) with Row Level Security
- **Charts:** Recharts
- **Audio:** Browser Web Speech API (Text-to-Speech, Speech Recognition, MediaRecorder)

## Getting Started

### Prerequisites

- Node.js 18+
- A Supabase project (URL and anon key)

### Installation

```bash
npm install
```

### Environment variables

Create a `.env` file in the project root:

```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

These are pre-populated in the Bolt environment. For a local copy, use your own Supabase project credentials.

### Database setup

The database schema and seed data are applied via Supabase migrations found in `supabase/migrations/`. They run automatically in this environment. To set up a fresh Supabase project, apply the SQL files in order using the Supabase dashboard SQL editor or MCP tools.

The migrations create:
- `profiles`, `alphabet`, `vocabulary`, `lessons`, `conversations`, `realworld_modules`, `realworld_phrases`, `listening_items`, `quiz_questions`, `lesson_completions`, `quiz_attempts`, `favorite_vocabulary`, `learning_activity`, `achievements`, `user_achievements`
- RLS policies on every table (public read for content, owner-scoped for personal data)
- Seed data: 34 alphabet letters, 120+ vocabulary words, 15 grammar lessons, 10 conversations, 6 real-world modules with phrases, 10 listening items, 5 quizzes with 10 questions each, 6 achievements

### Run the development server

```bash
npm run dev
```

The app runs at the URL shown in your terminal.

### Build for production

```bash
npm run build
npm run preview
```

## Demo Account

Click **"Try demo account"** on the login page. This creates a demo student with sample progress data (completed lessons, a quiz attempt, and earned achievements) so you can explore the platform immediately. Demo data is labeled and separate from real user accounts.

## Usage Guide

1. **Sign up** or use the demo account to access the dashboard.
2. Start with the **Alphabet** to learn Kannada letters and sounds.
3. Move to **Vocabulary** to build your word bank — star words to save them.
4. Read **Grammar Lessons** and mark each as completed to track progress.
5. Practice with **Conversations** and **Real-World Kannada** modules.
6. Use **Listening** to hear pronunciation and record yourself.
7. Take **Quizzes** to test your knowledge — scores are saved automatically.
8. Ask the **AI Assistant** for explanations and practice prompts.
9. Check **Progress** to see your activity charts and earned achievements.
10. Adjust your preferences in **Profile & Settings**.

## Security

- Passwords handled by Supabase Auth (never stored in plain text).
- Row Level Security ensures each user only accesses their own progress, favorites, and activity.
- No API keys or secrets are exposed in frontend code.
- Microphone access is requested with permission handling and graceful fallback.

## Deployment

The build output in `dist/` can be deployed to any static host (Netlify, Vercel, etc.). Set the same `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` environment variables on your hosting platform. Ensure your Supabase project allows requests from your deployment domain in the Auth settings.

## License

Educational project. Kannada content is curated and verified. For critical translations, confirm with a native speaker.
