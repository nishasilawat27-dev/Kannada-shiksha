import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import type { Profile, LearningLang, LearningLevel } from '@/types/database';

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signUp: (args: {
    email: string;
    password: string;
    full_name: string;
    preferred_lang: LearningLang;
    level: LearningLevel;
  }) => Promise<{ error: string | null }>;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signInDemo: () => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  updateProfile: (patch: Partial<Profile>) => Promise<{ error: string | null }>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

const DEMO_EMAIL = 'demo@kannadashiksha.in';
const DEMO_PASSWORD = 'demo123456';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const loadProfile = async (uid: string) => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', uid)
      .maybeSingle();
    if (error) {
      console.error('profile load error', error);
      return;
    }
    setProfile(data as Profile | null);
  };

  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      setSession(data.session);
      if (data.session?.user) {
        loadProfile(data.session.user.id).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    const { data: sub } = supabase.auth.onAuthStateChange((_event, sess) => {
      setSession(sess);
      if (sess?.user) {
        (async () => {
          await loadProfile(sess.user.id);
        })();
      } else {
        setProfile(null);
      }
    });

    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const signUp: AuthContextValue['signUp'] = async ({ email, password, full_name, preferred_lang, level }) => {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) return { error: error.message };
    if (!data.user) return { error: 'Sign-up failed. Please try again.' };

    const { error: profileError } = await supabase.from('profiles').insert({
      id: data.user.id,
      full_name,
      preferred_lang,
      level,
      daily_goal: 3,
      is_demo: false,
    });
    if (profileError) return { error: profileError.message };
    await loadProfile(data.user.id);
    return { error: null };
  };

  const signIn: AuthContextValue['signIn'] = async (email, password) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return { error: error.message };
    return { error: null };
  };

  const signInDemo: AuthContextValue['signInDemo'] = async () => {
    const { error } = await supabase.auth.signInWithPassword({
      email: DEMO_EMAIL,
      password: DEMO_PASSWORD,
    });
    if (error) {
      const signUpRes = await supabase.auth.signUp({
        email: DEMO_EMAIL,
        password: DEMO_PASSWORD,
      });
      if (signUpRes.error) return { error: signUpRes.error.message };
      if (!signUpRes.data.user) return { error: 'Could not create demo account.' };
      await supabase.from('profiles').insert({
        id: signUpRes.data.user.id,
        full_name: 'Demo Student',
        preferred_lang: 'en',
        level: 'beginner',
        daily_goal: 3,
        is_demo: true,
      });
      await seedDemoData(signUpRes.data.user.id);
    }
    return { error: null };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setProfile(null);
    setSession(null);
  };

  const refreshProfile = async () => {
    if (session?.user) await loadProfile(session.user.id);
  };

  const updateProfile: AuthContextValue['updateProfile'] = async (patch) => {
    if (!session?.user) return { error: 'Not signed in.' };
    const { error } = await supabase
      .from('profiles')
      .update(patch)
      .eq('id', session.user.id);
    if (error) return { error: error.message };
    await loadProfile(session.user.id);
    return { error: null };
  };

  const value: AuthContextValue = {
    session,
    user: session?.user ?? null,
    profile,
    loading,
    signUp,
    signIn,
    signInDemo,
    signOut,
    refreshProfile,
    updateProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

async function seedDemoData(userId: string) {
  const today = new Date().toISOString().slice(0, 10);
  await supabase.from('learning_activity').upsert({
    user_id: userId,
    activity_date: today,
    lessons_completed: 2,
    quizzes_taken: 1,
    words_learned: 10,
  }, { onConflict: 'user_id,activity_date' });

  await supabase.from('lesson_completions').upsert([
    { user_id: userId, kind: 'lesson', item_id: 'grammar-sentence-structure', item_label: 'Basic Sentence Structure' },
    { user_id: userId, kind: 'conversation', item_id: 'introducing-yourself', item_label: 'Introducing Yourself' },
  ], { onConflict: 'user_id,kind,item_id' });

  await supabase.from('quiz_attempts').insert({
    user_id: userId,
    quiz_key: 'beginner-vocab',
    quiz_title: 'Beginner Vocabulary',
    score: 8,
    total: 10,
    percentage: 80,
    answers: [],
  });

  await supabase.from('user_achievements').upsert([
    { user_id: userId, achievement_key: 'first_lesson' },
    { user_id: userId, achievement_key: 'quiz_champion' },
  ], { onConflict: 'user_id,achievement_key' });
}
