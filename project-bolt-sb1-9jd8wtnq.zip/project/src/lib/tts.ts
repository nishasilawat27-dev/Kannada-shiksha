let kannadaVoice: SpeechSynthesisVoice | null | undefined;

function pickKannadaVoice(): SpeechSynthesisVoice | null {
  if (typeof window === 'undefined' || !window.speechSynthesis) return null;
  if (kannadaVoice !== undefined) return kannadaVoice;
  const voices = window.speechSynthesis.getVoices();
  kannadaVoice = voices.find((v) => v.lang?.toLowerCase().startsWith('kn')) || null;
  return kannadaVoice;
}

export function speakKannada(text: string, onEnd?: () => void) {
  if (typeof window === 'undefined' || !window.speechSynthesis) {
    onEnd?.();
    return;
  }
  try {
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    const voice = pickKannadaVoice();
    if (voice) {
      utter.voice = voice;
      utter.lang = voice.lang;
    } else {
      utter.lang = 'kn-IN';
    }
    utter.rate = 0.85;
    if (onEnd) utter.onend = onEnd;
    window.speechSynthesis.speak(utter);
  } catch {
    onEnd?.();
  }
}

export function speechSynthesisSupported() {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
}

export function speechRecognitionSupported() {
  return typeof window !== 'undefined' &&
    ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window);
}

export function isKannadaVoiceAvailable(): boolean {
  return pickKannadaVoice() !== null;
}
