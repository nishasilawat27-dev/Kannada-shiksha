import {
  Home, LayoutDashboard, Type, BookOpen, Languages, MessagesSquare,
  Globe, Headphones, ClipboardList, Bot, TrendingUp, User, Info, LogOut, Menu, X, GraduationCap,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

export interface NavItem {
  label: string;
  to: string;
  icon: LucideIcon;
}

export const mainNav: NavItem[] = [
  { label: 'Home', to: '/', icon: Home },
  { label: 'Dashboard', to: '/dashboard', icon: LayoutDashboard, },
  { label: 'Alphabet', to: '/alphabet', icon: Type },
  { label: 'Vocabulary', to: '/vocabulary', icon: Languages },
  { label: 'Grammar', to: '/grammar', icon: BookOpen },
  { label: 'Conversations', to: '/conversations', icon: MessagesSquare },
  { label: 'Real-World Kannada', to: '/realworld', icon: Globe },
  { label: 'Listening', to: '/listening', icon: Headphones },
  { label: 'Quizzes', to: '/quizzes', icon: ClipboardList },
  { label: 'AI Assistant', to: '/assistant', icon: Bot },
  { label: 'Progress', to: '/progress', icon: TrendingUp },
  { label: 'Profile', to: '/profile', icon: User },
  { label: 'About', to: '/about', icon: Info },
];

export const Logo = GraduationCap;
