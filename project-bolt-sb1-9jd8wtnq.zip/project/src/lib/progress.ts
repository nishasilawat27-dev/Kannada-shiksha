import { supabase } from '@/lib/supabase';

export async function recordLessonCompletion(userId: string, kind: string, itemId: string, itemLabel: string) {
  const { error } = await supabase.from('lesson_completions').upsert(
    { user_id: userId, kind, item_id: itemId, item_label: itemLabel },
    { onConflict: 'user_id,kind,item_id' },
  );
  if (error) console.error('completion error', error);
  await bumpActivity(userId, 'lessons', 1);
}

export async function recordQuizAttempt(userId: string, quizKey: string, quizTitle: string, score: number, total: number, answers: unknown[]) {
  const percentage = total > 0 ? Math.round((score / total) * 100) : 0;
  const { error } = await supabase.from('quiz_attempts').insert({
    user_id: userId,
    quiz_key: quizKey,
    quiz_title: quizTitle,
    score,
    total,
    percentage,
    answers,
  });
  if (error) console.error('quiz attempt error', error);
  await bumpActivity(userId, 'quizzes', 1);
}

export async function recordWordsLearned(userId: string, count: number) {
  await bumpActivity(userId, 'words', count);
}

async function bumpActivity(userId: string, field: 'lessons' | 'quizzes' | 'words', count: number) {
  const today = new Date().toISOString().slice(0, 10);
  const { data } = await supabase
    .from('learning_activity')
    .select('*')
    .eq('user_id', userId)
    .eq('activity_date', today)
    .maybeSingle();

  if (data) {
    const patch: Record<string, number> = {};
    if (field === 'lessons') patch.lessons_completed = (data.lessons_completed || 0) + count;
    if (field === 'quizzes') patch.quizzes_taken = (data.quizzes_taken || 0) + count;
    if (field === 'words') patch.words_learned = (data.words_learned || 0) + count;
    await supabase.from('learning_activity').update(patch).eq('id', data.id);
  } else {
    const row: Record<string, unknown> = {
      user_id: userId,
      activity_date: today,
      lessons_completed: 0,
      quizzes_taken: 0,
      words_learned: 0,
    };
    if (field === 'lessons') row.lessons_completed = count;
    if (field === 'quizzes') row.quizzes_taken = count;
    if (field === 'words') row.words_learned = count;
    await supabase.from('learning_activity').insert(row);
  }
}

export async function grantAchievement(userId: string, key: string) {
  const { error } = await supabase.from('user_achievements').upsert(
    { user_id: userId, achievement_key: key },
    { onConflict: 'user_id,achievement_key' },
  );
  if (error) console.error('achievement grant error', error);
}

export async function maybeGrantAchievements(userId: string) {
  const { data: completions } = await supabase
    .from('lesson_completions')
    .select('id')
    .eq('user_id', userId);
  if ((completions?.length || 0) >= 1) await grantAchievement(userId, 'first_lesson');

  const { data: favs } = await supabase
    .from('favorite_vocabulary')
    .select('id')
    .eq('user_id', userId);
  if ((favs?.length || 0) >= 25) await grantAchievement(userId, 'words_25');

  const { data: attempts } = await supabase
    .from('quiz_attempts')
    .select('percentage')
    .eq('user_id', userId);
  if (attempts?.some((a) => Number(a.percentage) >= 80)) {
    await grantAchievement(userId, 'quiz_champion');
  }
}
