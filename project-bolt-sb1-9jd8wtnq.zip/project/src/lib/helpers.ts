import type { LearningLang } from '@/types/database';

export function translateMeaning(en: string, hi: string, lang: LearningLang): string {
  return lang === 'hi' ? hi || en : en || hi;
}

export function translateExplanation(en: string, hi: string, lang: LearningLang): string {
  return lang === 'hi' ? hi || en : en || hi;
}

export function firstName(full: string): string {
  return full?.trim().split(/\s+/)[0] || 'Learner';
}

export function levelLabel(level: string): string {
  const map: Record<string, string> = {
    beginner: 'Beginner',
    intermediate: 'Intermediate',
    advanced: 'Advanced',
  };
  return map[level] || level;
}

export function categoryLabel(cat: string): string {
  const map: Record<string, string> = {
    greetings: 'Greetings',
    family: 'Family',
    numbers: 'Numbers',
    colors: 'Colors',
    food: 'Food',
    education: 'Education',
    classroom: 'Classroom',
    travel: 'Travel',
    shopping: 'Shopping',
    healthcare: 'Healthcare',
    transportation: 'Transportation',
    workplace: 'Workplace',
    questions: 'Questions',
    common: 'Common',
    general: 'General',
    grammar: 'Grammar',
    conversations: 'Conversations',
    alphabet: 'Alphabet',
    realworld: 'Real World',
    listening: 'Listening',
    introductions: 'Introductions',
  };
  return map[cat] || cat.charAt(0).toUpperCase() + cat.slice(1);
}

export function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch {
    return iso;
  }
}

export function relativeDay(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const diff = Math.round((now.getTime() - d.getTime()) / (1000 * 60 * 60 * 24));
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Yesterday';
  if (diff < 7) return `${diff} days ago`;
  return formatDate(iso);
}
