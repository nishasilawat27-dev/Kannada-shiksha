import { useState, type ReactNode } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { LogOut, Menu, X, ChevronRight } from 'lucide-react';
import { mainNav, Logo } from '@/lib/nav';
import { useAuth } from '@/context/AuthContext';
import { firstName, levelLabel } from '@/lib/helpers';
import { Spinner } from '@/components/ui';

export default function Layout({ children }: { children: ReactNode }) {
  const { profile, loading, signOut } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const SidebarContent = (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2.5 px-5 py-5 border-b border-slate-100">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-700 text-white shadow-card">
          <Logo size={22} />
        </div>
        <div>
          <p className="font-bold text-slate-900 leading-tight">Kannada Shiksha</p>
          <p className="text-xs text-slate-500">Learn Kannada Easily</p>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {mainNav.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            onClick={() => setMobileOpen(false)}
            className={({ isActive }) =>
              `nav-link ${isActive ? 'nav-link-active' : ''}`
            }
          >
            <item.icon size={18} />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="border-t border-slate-100 p-3">
        {profile && (
          <div className="mb-2 rounded-xl bg-slate-50 px-3 py-2.5">
            <p className="text-sm font-semibold text-slate-800">{firstName(profile.full_name)}</p>
            <p className="text-xs text-slate-500">
              {levelLabel(profile.level)} · {profile.preferred_lang === 'hi' ? 'हिंदी' : 'English'}
              {profile.is_demo && ' · Demo'}
            </p>
          </div>
        )}
        <button onClick={handleSignOut} className="nav-link w-full text-red-600 hover:bg-red-50 hover:text-red-700">
          <LogOut size={18} />
          <span>Sign out</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 border-r border-slate-200 bg-white lg:block">
        {SidebarContent}
      </aside>

      {/* Mobile header */}
      <header className="sticky top-0 z-20 flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3 lg:hidden">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-700 text-white">
            <Logo size={16} />
          </div>
          <span className="font-bold text-slate-900">Kannada Shiksha</span>
        </div>
        <button
          onClick={() => setMobileOpen(true)}
          className="rounded-lg p-2 text-slate-600 hover:bg-slate-100"
          aria-label="Open menu"
        >
          <Menu size={22} />
        </button>
      </header>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-slate-900/40" onClick={() => setMobileOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-72 max-w-[85%] bg-white shadow-soft animate-fade-in">
            <button
              onClick={() => setMobileOpen(false)}
              className="absolute right-3 top-4 rounded-lg p-1.5 text-slate-500 hover:bg-slate-100"
              aria-label="Close menu"
            >
              <X size={20} />
            </button>
            {SidebarContent}
          </div>
        </div>
      )}

      {/* Main content */}
      <div className="lg:pl-64">
        {loading ? (
          <div className="flex h-screen items-center justify-center">
            <Spinner className="text-brand-500" />
          </div>
        ) : (
          <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:px-8 lg:py-8 animate-fade-in">
            {children}
          </main>
        )}
      </div>
    </div>
  );
}
