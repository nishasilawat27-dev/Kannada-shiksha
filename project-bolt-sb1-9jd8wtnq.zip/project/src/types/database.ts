export type LearningLang = 'hi' | 'en';
export type LearningLevel = 'beginner' | 'intermediate' | 'advanced';

export interface Profile {
  id: string;
  full_name: string;
  preferred_lang: LearningLang;
  level: LearningLevel;
  daily_goal: number;
  is_demo: boolean;
  created_at: string;
  updated_at: string;
}

export interface AlphabetLetter {
  id: string;
  letter: string;
  transliteration: string;
  hindi: string;
  english: string;
  type: 'vowel' | 'consonant';
  example_word: string;
  example_transliteration: string;
  example_meaning: string;
  order_idx: number;
}

export interface VocabularyWord {
  id: string;
  kannada: string;
  transliteration: string;
  hindi: string;
  english: string;
  example_kannada: string;
  example_transliteration: string;
  example_meaning: string;
  category: string;
  level: LearningLevel;
  is_word_of_day: boolean;
  order_idx: number;
}

export interface LessonExample {
  kannada: string;
  transliteration: string;
  hindi: string;
  english: string;
}

export interface LessonContent {
  explanation_en?: string;
  explanation_hi?: string;
  sections?: { heading_en?: string; text_en?: string; text_hi?: string }[];
}

export interface Lesson {
  id: string;
  title: string;
  slug: string;
  category: string;
  level: LearningLevel;
  summary: string;
  content: LessonContent;
  examples: LessonExample[];
  order_idx: number;
}

export interface DialogLine {
  kannada: string;
  transliteration: string;
  hindi: string;
  english: string;
}

export interface QuizItem {
  question: string;
  options: string[];
  correct_index: number;
  explanation: string;
}

export interface Conversation {
  id: string;
  title: string;
  category: string;
  level: LearningLevel;
  summary: string;
  dialog: DialogLine[];
  quiz: QuizItem[];
  order_idx: number;
}

export interface RealWorldModule {
  id: string;
  module_key: string;
  title: string;
  description: string;
  icon: string;
  order_idx: number;
}

export interface RealWorldPhrase {
  id: string;
  module_key: string;
  kannada: string;
  transliteration: string;
  hindi: string;
  english: string;
  context: string;
  quiz: QuizItem[];
  order_idx: number;
}

export interface ListeningItem {
  id: string;
  kannada: string;
  transliteration: string;
  hindi: string;
  english: string;
  level: LearningLevel;
  category: string;
  order_idx: number;
}

export interface QuizQuestion {
  id: string;
  quiz_key: string;
  question: string;
  options: string[];
  correct_index: number;
  explanation: string;
  level: LearningLevel;
  type: string;
  order_idx: number;
}

export interface Achievement {
  id: string;
  achievement_key: string;
  title: string;
  description: string;
  icon: string;
  threshold: number;
}

export interface LessonCompletion {
  id: string;
  user_id: string;
  kind: string;
  item_id: string;
  item_label: string;
  completed_at: string;
}

export interface QuizAttempt {
  id: string;
  user_id: string;
  quiz_key: string;
  quiz_title: string;
  score: number;
  total: number;
  percentage: number;
  answers: { question: string; selected: number; correct: number }[];
  created_at: string;
}

export interface FavoriteVocabulary {
  id: string;
  user_id: string;
  vocabulary_id: string;
  created_at: string;
}

export interface LearningActivity {
  id: string;
  user_id: string;
  activity_date: string;
  lessons_completed: number;
  quizzes_taken: number;
  words_learned: number;
}

export interface UserAchievement {
  id: string;
  user_id: string;
  achievement_key: string;
  earned_at: string;
}
