import { useEffect, useState } from 'react';
import { ClipboardList, ArrowRight, RotateCcw, CheckCircle2, XCircle, Eye, Volume2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { speakKannada, speechSynthesisSupported } from '@/lib/tts';
import { recordQuizAttempt, maybeGrantAchievements } from '@/lib/progress';
import { PageHeader, LoadingState, EmptyState } from '@/components/ui';
import type { QuizQuestion } from '@/types/database';

interface QuizMeta {
  key: string;
  title: string;
  description: string;
}

const QUIZZES: QuizMeta[] = [
  { key: 'beginner-vocab', title: 'Beginner Vocabulary', description: 'Test common Kannada words.' },
  { key: 'alphabet', title: 'Alphabet Recognition', description: 'Identify Kannada letters.' },
  { key: 'grammar', title: 'Grammar Basics', description: 'Sentence structure and grammar.' },
  { key: 'conversations', title: 'Conversations', description: 'Everyday dialogues.' },
  { key: 'realworld', title: 'Real-World Kannada', description: 'Practical situations.' },
];

export default function QuizzesPage() {
  const { user, profile } = useAuth();
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeQuiz, setActiveQuiz] = useState<QuizMeta | null>(null);
  const [qIdx, setQIdx] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [feedback, setFeedback] = useState<number | null>(null);
  const [done, setDone] = useState(false);
  const [review, setReview] = useState(false);
  const [score, setScore] = useState(0);
  const [recentAttempts, setRecentAttempts] = useState<{ quiz_title: string; score: number; total: number; percentage: number; created_at: string }[]>([]);
  const ttsOk = speechSynthesisSupported();

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase.from('quiz_attempts').select('quiz_title, score, total, percentage, created_at').eq('user_id', user.id).order('created_at', { ascending: false }).limit(5);
      setRecentAttempts((data ?? []) as { quiz_title: string; score: number; total: number; percentage: number; created_at: string }[]);
    })();
  }, [user, activeQuiz]);

  const startQuiz = async (meta: QuizMeta) => {
    setLoading(true);
    setActiveQuiz(meta);
    const { data } = await supabase.from('quiz_questions').select('*').eq('quiz_key', meta.key).order('order_idx');
    setQuestions((data as QuizQuestion[]) ?? []);
    setQIdx(0);
    setAnswers([]);
    setFeedback(null);
    setDone(false);
    setReview(false);
    setScore(0);
    setLoading(false);
  };

  const choose = (optIdx: number) => {
    if (feedback !== null) return;
    const q = questions[qIdx];
    setAnswers((a) => { const n = [...a]; n[qIdx] = optIdx; return n; });
    setFeedback(optIdx);
    if (optIdx === q.correct_index) setScore((s) => s + 1);
  };

  const next = async () => {
    if (qIdx + 1 < questions.length) {
      setQIdx((i) => i + 1);
      setFeedback(null);
    } else {
      setDone(true);
      if (user && activeQuiz) {
        const answerLog = questions.map((q, i) => ({
          question: q.question,
          selected: answers[i] ?? -1,
          correct: q.correct_index,
        }));
        await recordQuizAttempt(user.id, activeQuiz.key, activeQuiz.title, score, questions.length, answerLog);
        await maybeGrantAchievements(user.id);
        // refresh recent attempts
        const { data } = await supabase.from('quiz_attempts').select('quiz_title, score, total, percentage, created_at').eq('user_id', user.id).order('created_at', { ascending: false }).limit(5);
        setRecentAttempts((data ?? []) as { quiz_title: string; score: number; total: number; percentage: number; created_at: string }[]);
      }
    }
  };

  // ---- Active quiz ----
  if (activeQuiz && questions.length > 0) {
    if (loading) return <LoadingState label="Loading quiz..." />;

    if (done) {
      const pct = questions.length > 0 ? Math.round((score / questions.length) * 100) : 0;
      return (
        <div>
          <button onClick={() => setActiveQuiz(null)} className="btn-ghost mb-4">
            <ArrowRight size={16} className="rotate-180" /> All quizzes
          </button>
          <div className="card p-6 sm:p-8 text-center">
            <div className={`mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-full ${pct >= 80 ? 'bg-leaf-100 text-leaf-700' : 'bg-amber-100 text-amber-700'}`}>
              <CheckCircle2 size={32} />
            </div>
            <p className="text-3xl font-bold text-slate-900">{score} / {questions.length}</p>
            <p className="text-lg text-slate-600">{pct}% correct</p>
            <p className="mt-1 text-sm text-slate-500">{activeQuiz.title}</p>

            <div className="mt-6 flex justify-center gap-2">
              <button onClick={() => startQuiz(activeQuiz)} className="btn-primary">
                <RotateCcw size={14} /> Retry quiz
              </button>
              <button onClick={() => setReview((r) => !r)} className="btn-outline">
                <Eye size={14} /> Review answers
              </button>
            </div>

            {review && (
              <div className="mt-6 space-y-3 text-left">
                {questions.map((q, i) => {
                  const sel = answers[i];
                  const correct = sel === q.correct_index;
                  return (
                    <div key={q.id} className="rounded-xl border border-slate-100 p-4">
                      <p className="text-sm font-semibold text-slate-800">{i + 1}. {q.question}</p>
                      <div className="mt-2 space-y-1 text-sm">
                        {q.options.map((opt, oi) => (
                          <div key={oi} className={`flex items-center gap-2 ${oi === q.correct_index ? 'text-leaf-700' : oi === sel ? 'text-red-600' : 'text-slate-500'}`}>
                            {oi === q.correct_index ? <CheckCircle2 size={14} /> : oi === sel ? <XCircle size={14} /> : <span className="w-3.5" />}
                            <span>{opt}</span>
                          </div>
                        ))}
                      </div>
                      <p className="mt-2 text-xs text-slate-500">{q.explanation}</p>
                      {!correct && sel !== null && <p className="mt-1 text-xs text-red-500">Your answer was incorrect.</p>}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      );
    }

    const q = questions[qIdx];
    return (
      <div>
        <button onClick={() => setActiveQuiz(null)} className="btn-ghost mb-4">
          <ArrowRight size={16} className="rotate-180" /> All quizzes
        </button>
        <div className="card p-6 sm:p-8">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-slate-700">{activeQuiz.title}</p>
              <p className="text-xs text-slate-500">Question {qIdx + 1} of {questions.length}</p>
            </div>
            <span className="text-xs text-leaf-600">Score: {score}</span>
          </div>

          <div className="mb-4 h-2 overflow-hidden rounded-full bg-slate-100">
            <div className="h-full bg-brand-500 transition-all" style={{ width: `${((qIdx) / questions.length) * 100}%` }} />
          </div>

          <p className="text-lg font-semibold text-slate-900">{q.question}</p>

          <div className="mt-4 space-y-2">
            {q.options.map((opt, i) => {
              const isChosen = feedback !== null;
              const isCorrect = i === q.correct_index;
              const isChosenAns = feedback === i;
              let cls = 'border-slate-200 hover:border-brand-300 hover:bg-brand-50';
              if (isChosen && isCorrect) cls = 'border-leaf-500 bg-leaf-50 text-leaf-700';
              else if (isChosen && isChosenAns && !isCorrect) cls = 'border-red-400 bg-red-50 text-red-700';
              else if (isChosen) cls = 'border-slate-200 opacity-60';
              return (
                <button key={i} onClick={() => choose(i)} disabled={isChosen} className={`flex w-full items-center gap-3 rounded-xl border px-4 py-3 text-left text-sm transition ${cls}`}>
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-white border border-slate-200 text-xs font-semibold">{String.fromCharCode(65 + i)}</span>
                  <span className="flex-1">{opt}</span>
                  {isChosen && isCorrect && <CheckCircle2 size={16} />}
                  {isChosen && isChosenAns && !isCorrect && <XCircle size={16} />}
                </button>
              );
            })}
          </div>

          {feedback !== null && (
            <div className="mt-4 rounded-xl bg-slate-50 p-4">
              <p className="text-sm text-slate-700">{q.explanation}</p>
              <button onClick={next} className="btn-primary mt-3">
                {qIdx + 1 < questions.length ? 'Next question' : 'Finish quiz'} <ArrowRight size={14} />
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ---- Quiz list ----
  return (
    <div>
      <PageHeader icon={<ClipboardList size={20} />} title="Practice Quizzes" subtitle="10+ questions per quiz, with instant feedback and saved scores." />

      {recentAttempts.length > 0 && (
        <div className="card mb-5 p-4">
          <p className="mb-2 text-xs font-semibold text-slate-500">Recent results</p>
          <div className="flex flex-wrap gap-2">
            {recentAttempts.map((a, i) => (
              <span key={i} className={`badge ${Number(a.percentage) >= 80 ? 'bg-leaf-100 text-leaf-700' : 'bg-amber-100 text-amber-700'}`}>
                {a.quiz_title}: {a.score}/{a.total} · {a.percentage}%
              </span>
            ))}
          </div>
        </div>
      )}

      {QUIZZES.length === 0 ? (
        <EmptyState icon={<ClipboardList size={40} />} title="No quizzes available" />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {QUIZZES.map((q) => (
            <button key={q.key} onClick={() => startQuiz(q)} className="card group p-5 text-left transition hover:shadow-soft">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50 text-brand-700 group-hover:bg-brand-700 group-hover:text-white transition-colors">
                <ClipboardList size={20} />
              </div>
              <h3 className="mt-3 font-semibold text-slate-900">{q.title}</h3>
              <p className="mt-1 text-sm text-slate-500">{q.description}</p>
              <div className="mt-3 flex items-center gap-2">
                <span className="badge bg-slate-100 text-slate-600">10 questions</span>
                <ArrowRight className="ml-auto text-slate-300 group-hover:text-brand-600" size={16} />
              </div>
            </button>
          ))}
        </div>
      )}
      <p className="mt-4 text-xs text-slate-400">
        {profile?.is_demo ? 'Demo mode: quiz scores are saved to your demo account.' : 'Your scores are saved to your account.'}
      </p>
      {ttsOk && <span className="hidden"><Volume2 size={1} /></span>}
    </div>
  );
}
