import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, BookOpen, Languages, ClipboardList, Flame,
  Award, TrendingUp, ArrowRight, Trophy, Target,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { firstName, levelLabel, formatDate, categoryLabel } from '@/lib/helpers';
import { PageHeader, LoadingState } from '@/components/ui';
import type { LessonCompletion, QuizAttempt, UserAchievement, Achievement, LearningActivity } from '@/types/database';

interface DashboardData {
  completions: LessonCompletion[];
  attempts: QuizAttempt[];
  userAchievements: UserAchievement[];
  achievements: Achievement[];
  activity: LearningActivity[];
  favorites: { id: string }[];
}

export default function DashboardPage() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [completions, attempts, userAchievements, achievements, activity, favorites] = await Promise.all([
        supabase.from('lesson_completions').select('*').eq('user_id', user.id).order('completed_at', { ascending: false }).limit(10),
        supabase.from('quiz_attempts').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(5),
        supabase.from('user_achievements').select('*').eq('user_id', user.id),
        supabase.from('achievements').select('*'),
        supabase.from('learning_activity').select('*').eq('user_id', user.id).order('activity_date', { ascending: false }).limit(14),
        supabase.from('favorite_vocabulary').select('id').eq('user_id', user.id),
      ]);
      setData({
        completions: completions.data ?? [],
        attempts: attempts.data ?? [],
        userAchievements: userAchievements.data ?? [],
        achievements: achievements.data ?? [],
        activity: activity.data ?? [],
        favorites: favorites.data ?? [],
      });
      setLoading(false);
    })();
  }, [user]);

  if (loading || !data || !profile) return <LoadingState label="Loading your dashboard..." />;

  const lessonsCompleted = data.completions.length;
  const wordsLearned = data.favorites.length;
  const bestQuiz = data.attempts.reduce((max, a) => Math.max(max, Number(a.percentage)), 0);
  const todayActivity = data.activity.find((a) => a.activity_date === new Date().toISOString().slice(0, 10));
  const todayGoal = profile.daily_goal;
  const todayDone = (todayActivity?.lessons_completed || 0) + (todayActivity?.quizzes_taken || 0);
  const goalPct = todayGoal > 0 ? Math.min(100, Math.round((todayDone / todayGoal) * 100)) : 0;

  // streak: consecutive days with activity up to today
  let streak = 0;
  const dates = new Set(data.activity.map((a) => a.activity_date));
  for (let i = 0; i < 365; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const iso = d.toISOString().slice(0, 10);
    if (dates.has(iso)) streak++;
    else if (i === 0) continue;
    else break;
  }

  const earnedKeys = new Set(data.userAchievements.map((a) => a.achievement_key));
  const earnedBadges = data.achievements.filter((a) => earnedKeys.has(a.achievement_key));

  const recommended = [
    { kind: 'lesson', item_id: 'grammar-pronouns', label: 'Grammar: Pronouns', to: '/grammar' },
    { kind: 'lesson', item_id: 'alphabet', label: 'Kannada Alphabet', to: '/alphabet' },
    { kind: 'conversation', item_id: 'introducing-yourself', label: 'Introducing Yourself', to: '/conversations' },
  ].find((r) => !data.completions.some((c) => c.kind === r.kind && c.item_id === r.item_id)) || { to: '/grammar', label: 'Grammar Lessons' };

  const stats = [
    { label: 'Lessons completed', value: lessonsCompleted, icon: BookOpen, color: 'text-brand-700 bg-brand-50' },
    { label: 'Words saved', value: wordsLearned, icon: Languages, color: 'text-leaf-700 bg-leaf-50' },
    { label: 'Best quiz score', value: `${bestQuiz}%`, icon: Trophy, color: 'text-amber-700 bg-amber-50' },
    { label: 'Day streak', value: streak, icon: Flame, color: 'text-orange-700 bg-orange-50' },
  ];

  return (
    <div>
      <PageHeader
        icon={<LayoutDashboard size={20} />}
        title={`Hello, ${firstName(profile.full_name)}!`}
        subtitle={profile.is_demo ? 'Demo account — exploring sample data' : `Level: ${levelLabel(profile.level)} · ${profile.preferred_lang === 'hi' ? 'हिंदी' : 'English'}`}
      />

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="card p-4">
            <div className={`mb-2 flex h-9 w-9 items-center justify-center rounded-lg ${s.color}`}>
              <s.icon size={18} />
            </div>
            <p className="text-2xl font-bold text-slate-900">{s.value}</p>
            <p className="text-xs text-slate-500">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Daily goal + continue */}
      <div className="mt-5 grid gap-4 lg:grid-cols-3">
        <div className="card p-5 lg:col-span-2">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-slate-700">Daily learning goal</p>
              <p className="text-xs text-slate-500">{todayDone} of {todayGoal} activities today</p>
            </div>
            <Target className="text-brand-600" size={20} />
          </div>
          <div className="mt-3 h-3 overflow-hidden rounded-full bg-slate-100">
            <div className="h-full rounded-full bg-gradient-to-r from-brand-500 to-leaf-500 transition-all" style={{ width: `${goalPct}%` }} />
          </div>
          <p className="mt-2 text-xs text-slate-500">{goalPct}% of today's goal</p>

          <div className="mt-5 flex flex-wrap gap-2">
            <button onClick={() => navigate('/alphabet')} className="btn-leaf">Continue learning <ArrowRight size={14} /></button>
            <button onClick={() => navigate(recommended.to)} className="btn-outline">Next: {recommended.label}</button>
          </div>
        </div>

        <div className="card p-5">
          <div className="flex items-center gap-2">
            <Award className="text-amber-600" size={18} />
            <p className="text-sm font-semibold text-slate-700">Achievements</p>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            {earnedBadges.length === 0 && <p className="text-xs text-slate-500">No achievements yet. Complete a lesson to earn your first badge!</p>}
            {earnedBadges.map((b) => (
              <span key={b.achievement_key} className="badge bg-amber-50 text-amber-700 border border-amber-100">
                <Trophy size={12} /> {b.title}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Recent + quiz history */}
      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <div className="card p-5">
          <p className="mb-3 text-sm font-semibold text-slate-700">Recently completed</p>
          {data.completions.length === 0 ? (
            <p className="text-xs text-slate-500">No lessons completed yet. Start with the alphabet or grammar.</p>
          ) : (
            <ul className="space-y-2">
              {data.completions.slice(0, 6).map((c) => (
                <li key={c.id} className="flex items-center justify-between rounded-lg border border-slate-100 px-3 py-2">
                  <div className="flex items-center gap-2">
                    <BookOpen className="text-brand-500" size={14} />
                    <span className="text-sm text-slate-700">{c.item_label || c.item_id}</span>
                  </div>
                  <span className="text-xs text-slate-400">{formatDate(c.completed_at)}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="card p-5">
          <p className="mb-3 text-sm font-semibold text-slate-700">Recent quiz results</p>
          {data.attempts.length === 0 ? (
            <p className="text-xs text-slate-500">No quizzes taken yet. Try the beginner quiz!</p>
          ) : (
            <ul className="space-y-2">
              {data.attempts.slice(0, 5).map((a) => (
                <li key={a.id} className="flex items-center justify-between rounded-lg border border-slate-100 px-3 py-2">
                  <div className="flex items-center gap-2">
                    <ClipboardList className="text-leaf-600" size={14} />
                    <span className="text-sm text-slate-700">{a.quiz_title}</span>
                  </div>
                  <span className={`badge ${Number(a.percentage) >= 80 ? 'bg-leaf-100 text-leaf-700' : 'bg-amber-100 text-amber-700'}`}>
                    {a.score}/{a.total} · {a.percentage}%
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Quick links */}
      <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { to: '/alphabet', icon: BookOpen, label: 'Alphabet' },
          { to: '/vocabulary', icon: Languages, label: 'Vocabulary' },
          { to: '/quizzes', icon: ClipboardList, label: 'Quizzes' },
          { to: '/progress', icon: TrendingUp, label: 'Progress' },
        ].map((q) => (
          <button key={q.to} onClick={() => navigate(q.to)} className="card flex items-center gap-3 p-4 text-left transition hover:shadow-soft">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-50 text-brand-700">
              <q.icon size={16} />
            </div>
            <span className="text-sm font-medium text-slate-700">{q.label}</span>
            <ArrowRight className="ml-auto text-slate-300" size={14} />
          </button>
        ))}
      </div>
    </div>
  );
}
