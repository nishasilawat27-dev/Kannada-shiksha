import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookOpen, CheckCircle2, ChevronLeft, Volume2, ArrowRight } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { speakKannada, speechSynthesisSupported } from '@/lib/tts';
import { recordLessonCompletion, maybeGrantAchievements } from '@/lib/progress';
import { PageHeader, LoadingState, EmptyState } from '@/components/ui';
import { levelLabel } from '@/lib/helpers';
import type { Lesson } from '@/types/database';

export default function GrammarPage() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Lesson | null>(null);
  const [completed, setCompleted] = useState<Set<string>>(new Set());
  const [marking, setMarking] = useState(false);
  const ttsOk = speechSynthesisSupported();

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('lessons').select('*').order('order_idx');
      setLessons((data as Lesson[]) ?? []);
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase
        .from('lesson_completions')
        .select('item_id')
        .eq('user_id', user.id)
        .eq('kind', 'lesson');
      setCompleted(new Set((data ?? []).map((d) => d.item_id)));
    })();
  }, [user]);

  if (loading) return <LoadingState label="Loading grammar lessons..." />;

  const lang = profile?.preferred_lang ?? 'en';

  const markComplete = async (lesson: Lesson) => {
    if (!user || completed.has(lesson.slug)) return;
    setMarking(true);
    setCompleted((s) => new Set(s).add(lesson.slug));
    await recordLessonCompletion(user.id, 'lesson', lesson.slug, lesson.title);
    await maybeGrantAchievements(user.id);
    setMarking(false);
  };

  if (selected) {
    return (
      <div>
        <button onClick={() => setSelected(null)} className="btn-ghost mb-4">
          <ChevronLeft size={16} /> All lessons
        </button>
        <div className="card p-6 sm:p-8">
          <div className="mb-2 flex items-center gap-2">
            <span className="badge bg-brand-50 text-brand-700">{levelLabel(selected.level)}</span>
            <span className="badge bg-slate-100 text-slate-600 capitalize">{selected.category}</span>
            {completed.has(selected.slug) && <span className="badge bg-leaf-100 text-leaf-700"><CheckCircle2 size={12} /> Completed</span>}
          </div>
          <h1 className="text-2xl font-bold text-slate-900">{selected.title}</h1>
          <p className="mt-1 text-sm text-slate-500">{selected.summary}</p>

          <div className="mt-6 space-y-4">
            {selected.content.explanation_en && (
              <div className="rounded-xl bg-slate-50 p-4">
                <p className="text-sm text-slate-700 leading-relaxed">
                  {lang === 'hi' ? (selected.content.explanation_hi || selected.content.explanation_en) : selected.content.explanation_en}
                </p>
              </div>
            )}

            {selected.content.sections?.map((s, i) => (
              <div key={i} className="rounded-xl border border-slate-100 p-4">
                {s.heading_en && <h3 className="font-semibold text-slate-800">{s.heading_en}</h3>}
                <p className="mt-1 text-sm text-slate-600">
                  {lang === 'hi' ? (s.text_hi || s.text_en) : s.text_en}
                </p>
              </div>
            ))}

            <div>
              <h3 className="mb-2 font-semibold text-slate-800">Examples</h3>
              <div className="space-y-2">
                {selected.examples.map((ex, i) => (
                  <div key={i} className="flex items-start gap-3 rounded-xl border border-slate-100 p-3">
                    <button onClick={() => speakKannada(ex.kannada)} disabled={!ttsOk} className="mt-0.5 rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-brand-600">
                      <Volume2 size={14} />
                    </button>
                    <div className="flex-1">
                      <p className="font-kannada text-lg font-semibold text-slate-900">{ex.kannada}</p>
                      <p className="text-xs text-brand-600">{ex.transliteration}</p>
                      <p className="text-sm text-slate-600">{ex.hindi} · {ex.english}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-6 flex flex-wrap gap-2">
            <button onClick={() => markComplete(selected)} disabled={marking || completed.has(selected.slug)} className={completed.has(selected.slug) ? 'btn-leaf' : 'btn-primary'}>
              <CheckCircle2 size={16} /> {completed.has(selected.slug) ? 'Completed' : 'Mark as completed'}
            </button>
            <button onClick={() => navigate('/quizzes')} className="btn-outline">
              Take a quiz <ArrowRight size={14} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader icon={<BookOpen size={20} />} title="Grammar Lessons" subtitle="15 structured lessons with explanations in Hindi and English." />

      {lessons.length === 0 ? (
        <EmptyState icon={<BookOpen size={40} />} title="No lessons available" />
      ) : (
        <div className="space-y-3">
          {lessons.map((l) => (
            <button
              key={l.id}
              onClick={() => setSelected(l)}
              className="card group flex w-full items-center gap-4 p-4 text-left transition hover:shadow-soft"
            >
              <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ${completed.has(l.slug) ? 'bg-leaf-100 text-leaf-700' : 'bg-brand-50 text-brand-700'}`}>
                {completed.has(l.slug) ? <CheckCircle2 size={22} /> : <BookOpen size={20} />}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-slate-900">{l.title}</h3>
                  <span className="badge bg-slate-100 text-slate-600">{levelLabel(l.level)}</span>
                </div>
                <p className="mt-0.5 text-sm text-slate-500 line-clamp-1">{l.summary}</p>
              </div>
              <ArrowRight className="text-slate-300 group-hover:text-brand-600" size={18} />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
