import { useEffect, useState } from 'react';
import { MessagesSquare, Volume2, ChevronLeft, CheckCircle2, ArrowRight, Play, RotateCcw } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { speakKannada, speechSynthesisSupported } from '@/lib/tts';
import { recordLessonCompletion, maybeGrantAchievements } from '@/lib/progress';
import { PageHeader, LoadingState, EmptyState } from '@/components/ui';
import { categoryLabel, levelLabel } from '@/lib/helpers';
import type { Conversation, QuizItem } from '@/types/database';

export default function ConversationsPage() {
  const { user, profile } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Conversation | null>(null);
  const [completed, setCompleted] = useState<Set<string>>(new Set());
  const [mode, setMode] = useState<'dialog' | 'quiz'>('dialog');
  const [quizIdx, setQuizIdx] = useState(0);
  const [quizAns, setQuizAns] = useState<(number | null)[]>([]);
  const [quizFeedback, setQuizFeedback] = useState<number | null>(null);
  const [quizDone, setQuizDone] = useState(false);
  const [score, setScore] = useState(0);
  const [roleIdx, setRoleIdx] = useState(0);
  const ttsOk = speechSynthesisSupported();

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('conversations').select('*').order('order_idx');
      setConversations((data as Conversation[]) ?? []);
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase.from('lesson_completions').select('item_id').eq('user_id', user.id).eq('kind', 'conversation');
      setCompleted(new Set((data ?? []).map((d) => d.item_id)));
    })();
  }, [user]);

  if (loading) return <LoadingState label="Loading conversations..." />;

  const markComplete = async (c: Conversation) => {
    if (!user) return;
    const id = c.title.toLowerCase().replace(/\s+/g, '-');
    setCompleted((s) => new Set(s).add(id));
    await recordLessonCompletion(user.id, 'conversation', id, c.title);
    await maybeGrantAchievements(user.id);
  };

  const startQuiz = () => {
    setMode('quiz');
    setQuizIdx(0);
    setQuizAns([]);
    setQuizFeedback(null);
    setQuizDone(false);
    setScore(0);
  };

  const answerQuiz = (c: Conversation, optIdx: number) => {
    if (quizFeedback !== null) return;
    const q = c.quiz[quizIdx];
    setQuizAns((a) => { const n = [...a]; n[quizIdx] = optIdx; return n; });
    setQuizFeedback(optIdx);
    if (optIdx === q.correct_index) setScore((s) => s + 1);
  };

  const nextQuiz = (c: Conversation) => {
    if (quizIdx + 1 < c.quiz.length) {
      setQuizIdx((i) => i + 1);
      setQuizFeedback(null);
    } else {
      setQuizDone(true);
      if (user) markComplete(c);
    }
  };

  // ---- Detail view ----
  if (selected) {
    return (
      <div>
        <button onClick={() => { setSelected(null); setMode('dialog'); }} className="btn-ghost mb-4">
          <ChevronLeft size={16} /> All conversations
        </button>

        <div className="card p-6 sm:p-8">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <span className="badge bg-brand-50 text-brand-700">{categoryLabel(selected.category)}</span>
            <span className="badge bg-slate-100 text-slate-600">{levelLabel(selected.level)}</span>
            {completed.has(selected.title.toLowerCase().replace(/\s+/g, '-')) && <span className="badge bg-leaf-100 text-leaf-700"><CheckCircle2 size={12} /> Completed</span>}
          </div>
          <h1 className="text-2xl font-bold text-slate-900">{selected.title}</h1>
          <p className="mt-1 text-sm text-slate-500">{selected.summary}</p>

          <div className="mb-5 mt-5 grid w-full max-w-xs grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
            <button onClick={() => setMode('dialog')} className={`rounded-lg py-2 text-sm font-semibold ${mode === 'dialog' ? 'bg-white text-brand-700 shadow-card' : 'text-slate-500'}`}>
              Dialogue
            </button>
            <button onClick={() => startQuiz()} className={`rounded-lg py-2 text-sm font-semibold ${mode === 'quiz' ? 'bg-white text-brand-700 shadow-card' : 'text-slate-500'}`}>
              Quiz ({selected.quiz.length})
            </button>
          </div>

          {mode === 'dialog' ? (
            <div>
              <div className="space-y-3">
                {selected.dialog.map((line, i) => (
                  <div key={i} className={`rounded-xl border p-4 ${roleIdx === i ? 'border-brand-300 bg-brand-50' : 'border-slate-100'}`}>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <p className="font-kannada text-xl font-semibold text-slate-900">{line.kannada}</p>
                        <p className="text-xs text-brand-600">{line.transliteration}</p>
                        <p className="mt-1 text-sm text-slate-600">{line.hindi} · {line.english}</p>
                      </div>
                      <button onClick={() => speakKannada(line.kannada)} disabled={!ttsOk} className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-brand-600">
                        <Volume2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Role play */}
              <div className="mt-5 rounded-xl bg-slate-50 p-4">
                <div className="flex items-center gap-2">
                  <Play size={14} className="text-leaf-600" />
                  <p className="text-sm font-semibold text-slate-700">Role-play practice</p>
                </div>
                <p className="mt-1 text-xs text-slate-500">Step through the dialogue and say each line aloud.</p>
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-xs text-slate-500">Line {roleIdx + 1} of {selected.dialog.length}</span>
                  <div className="flex gap-2">
                    <button onClick={() => setRoleIdx((i) => Math.max(0, i - 1))} className="btn-ghost px-3 py-1.5 text-xs">Previous</button>
                    {selected.dialog[roleIdx] && (
                      <button onClick={() => speakKannada(selected.dialog[roleIdx].kannada)} disabled={!ttsOk} className="btn-outline px-3 py-1.5 text-xs">
                        <Volume2 size={12} /> Hear
                      </button>
                    )}
                    <button onClick={() => setRoleIdx((i) => Math.min(selected.dialog.length - 1, i + 1))} className="btn-leaf px-3 py-1.5 text-xs">Next</button>
                  </div>
                </div>
              </div>

              <button onClick={() => startQuiz()} className="btn-primary mt-5">
                Take the comprehension quiz <ArrowRight size={14} />
              </button>
            </div>
          ) : (
            <div>
              {!quizDone ? (
                (() => {
                  const q: QuizItem = selected.quiz[quizIdx];
                  return (
                    <div>
                      <div className="mb-3 flex items-center justify-between">
                        <span className="text-xs font-semibold text-slate-500">Question {quizIdx + 1} of {selected.quiz.length}</span>
                        <span className="text-xs text-leaf-600">Score: {score}</span>
                      </div>
                      <p className="text-base font-semibold text-slate-900">{q.question}</p>
                      <div className="mt-4 space-y-2">
                        {q.options.map((opt, i) => {
                          const isChosen = quizFeedback !== null;
                          const isCorrect = i === q.correct_index;
                          const isChosenAns = quizFeedback === i;
                          let cls = 'border-slate-200 hover:border-brand-300 hover:bg-brand-50';
                          if (isChosen && isCorrect) cls = 'border-leaf-500 bg-leaf-50 text-leaf-700';
                          else if (isChosen && isChosenAns && !isCorrect) cls = 'border-red-400 bg-red-50 text-red-700';
                          else if (isChosen) cls = 'border-slate-200 opacity-60';
                          return (
                            <button
                              key={i}
                              onClick={() => answerQuiz(selected, i)}
                              disabled={isChosen}
                              className={`flex w-full items-center gap-3 rounded-xl border px-4 py-3 text-left text-sm transition ${cls}`}
                            >
                              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-slate-100 text-xs font-semibold">{String.fromCharCode(65 + i)}</span>
                              <span className="flex-1">{opt}</span>
                            </button>
                          );
                        })}
                      </div>
                      {quizFeedback !== null && (
                        <div className="mt-4 rounded-xl bg-slate-50 p-4">
                          <p className="text-sm text-slate-700">{q.explanation}</p>
                          <button onClick={() => nextQuiz(selected)} className="btn-primary mt-3">
                            {quizIdx + 1 < selected.quiz.length ? 'Next question' : 'Finish quiz'} <ArrowRight size={14} />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })()
              ) : (
                <div className="text-center py-6">
                  <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-leaf-100 text-leaf-700">
                    <CheckCircle2 size={28} />
                  </div>
                  <p className="text-2xl font-bold text-slate-900">{score} / {selected.quiz.length}</p>
                  <p className="text-sm text-slate-500">{selected.quiz.length > 0 ? Math.round((score / selected.quiz.length) * 100) : 0}% correct</p>
                  <div className="mt-4 flex justify-center gap-2">
                    <button onClick={() => startQuiz()} className="btn-outline"><RotateCcw size={14} /> Retry quiz</button>
                    <button onClick={() => setMode('dialog')} className="btn-ghost">Back to dialogue</button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  // ---- List view ----
  return (
    <div>
      <PageHeader icon={<MessagesSquare size={20} />} title="Daily Conversations" subtitle="Real dialogues with audio, role-play, and quizzes." />

      {conversations.length === 0 ? (
        <EmptyState icon={<MessagesSquare size={40} />} title="No conversations yet" />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {conversations.map((c) => {
            const id = c.title.toLowerCase().replace(/\s+/g, '-');
            return (
              <button key={c.id} onClick={() => setSelected(c)} className="card group p-5 text-left transition hover:shadow-soft">
                <div className="flex items-start justify-between">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
                    <MessagesSquare size={20} />
                  </div>
                  {completed.has(id) && <CheckCircle2 className="text-leaf-600" size={18} />}
                </div>
                <h3 className="mt-3 font-semibold text-slate-900">{c.title}</h3>
                <p className="mt-1 text-sm text-slate-500 line-clamp-2">{c.summary}</p>
                <div className="mt-3 flex items-center gap-2">
                  <span className="badge bg-brand-50 text-brand-700">{categoryLabel(c.category)}</span>
                  <span className="badge bg-slate-100 text-slate-600">{levelLabel(c.level)}</span>
                  <span className="ml-auto text-xs text-slate-400">{c.dialog.length} lines</span>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
