import { Info, GraduationCap, Target, Code, Mail, ShieldCheck, Accessibility } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function AboutPage() {
  const navigate = useNavigate();

  const sections = [
    {
      icon: Target,
      title: 'Problem statement',
      body: '"Kannada in Everyday Life: Develop a technology solution that helps people learn and use Kannada in real-world situations such as travelling, shopping, education, healthcare, transportation, and workplaces." Our focus is education — helping students and beginners learn Kannada through Hindi and English.',
    },
    {
      icon: GraduationCap,
      title: 'Who it is for',
      body: 'School and college students, people who recently moved to Karnataka, Hindi-speaking beginners, English-speaking learners, and anyone who wants to communicate with Kannada-speaking teachers, classmates, and colleagues.',
    },
    {
      icon: Code,
      title: 'Technology stack',
      body: 'React with TypeScript, Tailwind CSS, React Router, Supabase (PostgreSQL) for data and authentication, Recharts for progress charts, and the browser Web Speech API for Kannada text-to-speech and pronunciation recording.',
    },
    {
      icon: ShieldCheck,
      title: 'Security & privacy',
      body: 'Authentication uses Supabase secure password handling. Each learner only sees their own progress and favorites — enforced by Row Level Security on the database. No passwords are ever stored as plain text, and no API keys are exposed in the frontend.',
    },
    {
      icon: Accessibility,
      title: 'Accessibility',
      body: 'Responsive layouts from mobile to desktop, keyboard-accessible navigation, labelled form fields, sufficient text contrast, and graceful fallbacks for audio features when the browser or device does not support Kannada speech.',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-start gap-3">
          <div className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
            <Info size={20} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">About Kannada Shiksha</h1>
            <p className="mt-1 text-sm text-slate-500">A smart Kannada learning platform focused on real-world education.</p>
          </div>
        </div>
      </div>

      <div className="card overflow-hidden">
        <div className="bg-gradient-to-br from-brand-800 to-leaf-700 p-8 text-white">
          <h2 className="text-2xl font-bold">Learn Kannada. Speak Confidently. Connect with Everyone.</h2>
          <p className="mt-3 max-w-2xl text-white/85">
            Kannada Shiksha is an educational web application that makes learning Kannada simple,
            interactive, and practical. It covers the alphabet, vocabulary, grammar, conversations,
            and real-world situations — all explained through Hindi and English.
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            <button onClick={() => navigate('/login')} className="btn bg-white text-brand-800 hover:bg-brand-50">Get started</button>
            <button onClick={() => navigate('/vocabulary')} className="btn bg-white/10 text-white hover:bg-white/20 border border-white/20">Explore vocabulary</button>
          </div>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {sections.map((s) => (
          <div key={s.title} className="card p-5">
            <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
              <s.icon size={20} />
            </div>
            <h3 className="font-semibold text-slate-900">{s.title}</h3>
            <p className="mt-1 text-sm text-slate-600 leading-relaxed">{s.body}</p>
          </div>
        ))}
      </div>

      <div className="card p-5">
        <h3 className="font-semibold text-slate-900">Features at a glance</h3>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {[
            'Interactive Kannada alphabet with audio',
            '120+ verified vocabulary words across 14 categories',
            '15 structured grammar lessons in Hindi and English',
            '20+ real conversation scenarios with role-play',
            '6 real-world modules: education, travel, shopping, healthcare, transport, workplace',
            'Listening practice with TTS and microphone recording',
            '5 quizzes with 10 questions each and instant feedback',
            'AI learning assistant with offline knowledge fallback',
            'Progress tracking with charts and achievements',
            'Secure accounts with private per-user data',
          ].map((f) => (
            <div key={f} className="flex items-start gap-2 text-sm text-slate-600">
              <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-leaf-500" />
              <span>{f}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="card p-5">
        <div className="flex items-center gap-2">
          <Mail size={18} className="text-brand-600" />
          <h3 className="font-semibold text-slate-900">Contact</h3>
        </div>
        <p className="mt-1 text-sm text-slate-600">
          Questions or feedback? Email <a href="mailto:hello@kannadashiksha.in" className="text-brand-700 font-medium hover:underline">hello@kannadashiksha.in</a>.
        </p>
        <p className="mt-3 text-xs text-slate-400">
          Kannada Shiksha is an educational project. Kannada content is curated and verified; for critical
          translations, please confirm with a native speaker.
        </p>
      </div>
    </div>
  );
}
