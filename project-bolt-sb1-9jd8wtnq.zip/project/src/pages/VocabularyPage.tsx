import { useEffect, useMemo, useState } from 'react';
import { Languages, Search, Volume2, Star, Heart, Sparkles, X } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { speakKannada, speechSynthesisSupported } from '@/lib/tts';
import { recordWordsLearned } from '@/lib/progress';
import { PageHeader, LoadingState, EmptyState } from '@/components/ui';
import { categoryLabel } from '@/lib/helpers';
import type { VocabularyWord } from '@/types/database';

const CATEGORIES = ['greetings','family','numbers','colors','food','education','classroom','travel','shopping','healthcare','transportation','workplace','questions','common'];
const LEVELS = ['beginner','intermediate','advanced'];

export default function VocabularyPage() {
  const { user, profile } = useAuth();
  const [words, setWords] = useState<VocabularyWord[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<string>('all');
  const [level, setLevel] = useState<string>('all');
  const [showFavOnly, setShowFavOnly] = useState(false);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [recentlyViewed, setRecentlyViewed] = useState<string[]>([]);
  const [ttsOk] = useState(speechSynthesisSupported());

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('vocabulary').select('*').order('order_idx');
      setWords((data as VocabularyWord[]) ?? []);
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase.from('favorite_vocabulary').select('vocabulary_id').eq('user_id', user.id);
      setFavorites(new Set((data ?? []).map((d) => d.vocabulary_id)));
    })();
  }, [user]);

  const wordOfDay = useMemo(() => words.find((w) => w.is_word_of_day) ?? words[0], [words]);

  const filtered = useMemo(() => {
    return words.filter((w) => {
      if (category !== 'all' && w.category !== category) return false;
      if (level !== 'all' && w.level !== level) return false;
      if (showFavOnly && !favorites.has(w.id)) return false;
      if (query) {
        const q = query.toLowerCase();
        return (
          w.kannada.includes(query) ||
          w.transliteration.toLowerCase().includes(q) ||
          w.hindi.includes(query) ||
          w.english.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [words, category, level, query, showFavOnly, favorites]);

  const toggleFav = async (w: VocabularyWord) => {
    if (!user) return;
    const isFav = favorites.has(w.id);
    setFavorites((s) => {
      const next = new Set(s);
      if (isFav) next.delete(w.id);
      else next.add(w.id);
      return next;
    });
    if (isFav) {
      await supabase.from('favorite_vocabulary').delete().eq('user_id', user.id).eq('vocabulary_id', w.id);
    } else {
      await supabase.from('favorite_vocabulary').insert({ user_id: user.id, vocabulary_id: w.id });
      await recordWordsLearned(user.id, 1);
    }
  };

  const viewWord = (w: VocabularyWord) => {
    setRecentlyViewed((r) => [w.id, ...r.filter((id) => id !== w.id)].slice(0, 10));
  };

  if (loading) return <LoadingState label="Loading vocabulary..." />;

  return (
    <div>
      <PageHeader icon={<Languages size={20} />} title="Vocabulary" subtitle="120+ verified Kannada words with translations, audio, and examples." />

      {/* Word of the day */}
      {wordOfDay && !query && category === 'all' && (
        <div className="card mb-5 overflow-hidden">
          <div className="flex flex-col items-start gap-4 bg-gradient-to-br from-leaf-50 to-brand-50 p-5 sm:flex-row sm:items-center">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-leaf-600 text-white">
              <Sparkles size={22} />
            </div>
            <div className="flex-1">
              <p className="text-xs font-semibold text-leaf-700 uppercase tracking-wide">Word of the day</p>
              <p className="font-kannada text-2xl font-bold text-slate-900">{wordOfDay.kannada}</p>
              <p className="text-sm text-brand-600">{wordOfDay.transliteration} · {wordOfDay.hindi} · {wordOfDay.english}</p>
            </div>
            <div className="flex gap-2">
              <button onClick={() => speakKannada(wordOfDay.kannada)} disabled={!ttsOk} className="btn-outline"><Volume2 size={16} /> Play</button>
              <button onClick={() => toggleFav(wordOfDay)} className={favorites.has(wordOfDay.id) ? 'btn-leaf' : 'btn-outline'}>
                <Heart size={16} /> {favorites.has(wordOfDay.id) ? 'Saved' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Search + filters */}
      <div className="card mb-5 p-4">
        <div className="relative mb-3">
          <Search className="absolute left-3 top-3 text-slate-400" size={16} />
          <input className="input pl-9" placeholder="Search Kannada, Hindi, or English..." value={query} onChange={(e) => setQuery(e.target.value)} />
          {query && (
            <button onClick={() => setQuery('')} className="absolute right-3 top-3 text-slate-400 hover:text-slate-600">
              <X size={16} />
            </button>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <select className="input max-w-[180px]" value={category} onChange={(e) => setCategory(e.target.value)}>
            <option value="all">All categories</option>
            {CATEGORIES.map((c) => <option key={c} value={c}>{categoryLabel(c)}</option>)}
          </select>
          <select className="input max-w-[160px]" value={level} onChange={(e) => setLevel(e.target.value)}>
            <option value="all">All levels</option>
            {LEVELS.map((l) => <option key={l} value={l}>{l.charAt(0).toUpperCase() + l.slice(1)}</option>)}
          </select>
          <button onClick={() => setShowFavOnly((s) => !s)} className={showFavOnly ? 'btn-leaf' : 'btn-outline'}>
            <Star size={16} /> {showFavOnly ? 'Showing favorites' : 'Favorites only'}
          </button>
          <span className="ml-auto text-xs text-slate-500">{filtered.length} words</span>
        </div>
      </div>

      {/* Recently viewed */}
      {recentlyViewed.length > 0 && !query && (
        <div className="mb-5">
          <p className="mb-2 text-xs font-semibold text-slate-500">Recently viewed</p>
          <div className="flex flex-wrap gap-2">
            {recentlyViewed.slice(0, 6).map((id) => {
              const w = words.find((x) => x.id === id);
              if (!w) return null;
              return (
                <span key={id} className="badge bg-slate-100 text-slate-600 font-kannada text-sm" onClick={() => viewWord(w)}>
                  {w.kannada}
                </span>
              );
            })}
          </div>
        </div>
      )}

      {/* Grid */}
      {filtered.length === 0 ? (
        <EmptyState icon={<Languages size={40} />} title="No words found" description="Try a different search or filter." />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((w) => (
            <div key={w.id} className="card p-4 transition hover:shadow-soft" onClick={() => viewWord(w)}>
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-kannada text-xl font-semibold text-slate-900">{w.kannada}</p>
                  <p className="text-xs text-brand-600">{w.transliteration}</p>
                </div>
                <div className="flex gap-1">
                  <button onClick={(e) => { e.stopPropagation(); speakKannada(w.kannada); }} disabled={!ttsOk} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-brand-600" aria-label="Play">
                    <Volume2 size={15} />
                  </button>
                  <button onClick={(e) => { e.stopPropagation(); toggleFav(w); }} className={`rounded-lg p-1.5 hover:bg-slate-100 ${favorites.has(w.id) ? 'text-amber-500' : 'text-slate-400'}`} aria-label="Favorite">
                    <Star size={15} fill={favorites.has(w.id) ? 'currentColor' : 'none'} />
                  </button>
                </div>
              </div>
              <div className="mt-2 space-y-0.5">
                <p className="text-sm text-slate-700"><span className="text-slate-400">Hindi:</span> {w.hindi}</p>
                <p className="text-sm text-slate-700"><span className="text-slate-400">English:</span> {w.english}</p>
              </div>
              {w.example_kannada && (
                <div className="mt-3 rounded-lg bg-slate-50 px-3 py-2">
                  <p className="font-kannada text-sm text-slate-800">{w.example_kannada}</p>
                  <p className="text-xs text-slate-500">{w.example_transliteration} — {w.example_meaning}</p>
                </div>
              )}
              <div className="mt-3 flex items-center gap-2">
                <span className="badge bg-brand-50 text-brand-700">{categoryLabel(w.category)}</span>
                <span className="badge bg-slate-100 text-slate-600 capitalize">{w.level}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      <p className="mt-4 text-xs text-slate-400">
        {profile?.is_demo ? 'Demo mode: favorites are saved to your demo account.' : 'Favorites and progress are saved to your account.'}
      </p>
    </div>
  );
}
