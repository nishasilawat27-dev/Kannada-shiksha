import { useEffect, useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Save, LogOut, Star, Mail, Calendar } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { PageHeader, LoadingState, EmptyState } from '@/components/ui';
import { formatDate, categoryLabel } from '@/lib/helpers';
import type { LearningLang, LearningLevel, VocabularyWord, FavoriteVocabulary } from '@/types/database';

export default function ProfilePage() {
  const { user, profile, updateProfile, signOut } = useAuth();
  const navigate = useNavigate();
  const [fullName, setFullName] = useState('');
  const [lang, setLang] = useState<LearningLang>('en');
  const [level, setLevel] = useState<LearningLevel>('beginner');
  const [goal, setGoal] = useState(3);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [favWords, setFavWords] = useState<VocabularyWord[]>([]);
  const [favorites, setFavorites] = useState<FavoriteVocabulary[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name);
      setLang(profile.preferred_lang);
      setLevel(profile.level);
      setGoal(profile.daily_goal);
    }
  }, [profile]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data: favs } = await supabase.from('favorite_vocabulary').select('*').eq('user_id', user.id);
      setFavorites((favs ?? []) as FavoriteVocabulary[]);
      if (favs && favs.length > 0) {
        const ids = favs.map((f) => f.vocabulary_id);
        const { data: words } = await supabase.from('vocabulary').select('*').in('id', ids);
        setFavWords((words ?? []) as VocabularyWord[]);
      }
      setLoading(false);
    })();
  }, [user]);

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSaving(true);
    setMsg(null);
    const { error } = await updateProfile({
      full_name: fullName,
      preferred_lang: lang,
      level,
      daily_goal: goal,
    });
    if (error) setMsg(`Could not save: ${error}`);
    else setMsg('Settings saved.');
    setSaving(false);
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  if (!profile || loading) return <LoadingState label="Loading profile..." />;

  return (
    <div>
      <PageHeader icon={<User size={20} />} title="Profile & Settings" subtitle="Manage your account and learning preferences." />

      <div className="grid gap-5 lg:grid-cols-3">
        {/* Account info */}
        <div className="card p-5">
          <p className="mb-3 text-sm font-semibold text-slate-700">Account</p>
          <div className="space-y-3 text-sm">
            <div className="flex items-center gap-2 text-slate-600">
              <Mail size={14} className="text-slate-400" />
              <span>{user?.email}</span>
            </div>
            <div className="flex items-center gap-2 text-slate-600">
              <Calendar size={14} className="text-slate-400" />
              <span>Joined {formatDate(profile.created_at)}</span>
            </div>
            {profile.is_demo && (
              <div className="rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-700">
                Demo account — sample data. Progress resets if the demo is recreated.
              </div>
            )}
            <button onClick={handleSignOut} className="btn-outline w-full text-red-600 hover:bg-red-50 hover:border-red-200">
              <LogOut size={14} /> Sign out
            </button>
          </div>
        </div>

        {/* Settings form */}
        <div className="card p-5 lg:col-span-2">
          <p className="mb-3 text-sm font-semibold text-slate-700">Learning preferences</p>
          <form onSubmit={save} className="space-y-4">
            <div>
              <label className="label" htmlFor="pName">Full name</label>
              <input id="pName" className="input" value={fullName} onChange={(e) => setFullName(e.target.value)} />
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              <div>
                <label className="label" htmlFor="pLang">Learning language</label>
                <select id="pLang" className="input" value={lang} onChange={(e) => setLang(e.target.value as LearningLang)}>
                  <option value="en">English</option>
                  <option value="hi">हिंदी (Hindi)</option>
                </select>
              </div>
              <div>
                <label className="label" htmlFor="pLevel">Level</label>
                <select id="pLevel" className="input" value={level} onChange={(e) => setLevel(e.target.value as LearningLevel)}>
                  <option value="beginner">Beginner</option>
                  <option value="intermediate">Intermediate</option>
                  <option value="advanced">Advanced</option>
                </select>
              </div>
              <div>
                <label className="label" htmlFor="pGoal">Daily goal</label>
                <select id="pGoal" className="input" value={goal} onChange={(e) => setGoal(Number(e.target.value))}>
                  <option value={1}>1 activity</option>
                  <option value={3}>3 activities</option>
                  <option value={5}>5 activities</option>
                  <option value={10}>10 activities</option>
                </select>
              </div>
            </div>

            {msg && (
              <div className={`rounded-xl px-3 py-2.5 text-sm ${msg.includes('Could not') ? 'bg-red-50 text-red-700' : 'bg-leaf-50 text-leaf-700'}`}>
                {msg}
              </div>
            )}

            <button type="submit" disabled={saving} className="btn-primary">
              <Save size={16} /> {saving ? 'Saving...' : 'Save changes'}
            </button>
          </form>
        </div>
      </div>

      {/* Saved vocabulary */}
      <div className="card mt-5 p-5">
        <div className="mb-3 flex items-center gap-2">
          <Star className="text-amber-500" size={18} />
          <p className="text-sm font-semibold text-slate-700">Saved vocabulary ({favWords.length})</p>
        </div>
        {favWords.length === 0 ? (
          <EmptyState icon={<Star size={32} />} title="No saved words yet" description="Star words on the Vocabulary page to save them here." />
        ) : (
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {favWords.map((w) => (
              <div key={w.id} className="rounded-xl border border-slate-100 p-3">
                <p className="font-kannada text-lg font-semibold text-slate-900">{w.kannada}</p>
                <p className="text-xs text-brand-600">{w.transliteration}</p>
                <p className="text-sm text-slate-600">{w.hindi} · {w.english}</p>
                <span className="badge bg-slate-100 text-slate-600 mt-2">{categoryLabel(w.category)}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
