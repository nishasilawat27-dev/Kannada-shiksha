import { useEffect, useState } from 'react';
import {
  Globe, GraduationCap, Map, ShoppingCart, Stethoscope, Bus, Briefcase,
  ChevronLeft, Volume2, CheckCircle2, ArrowRight, RotateCcw,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { speakKannada, speechSynthesisSupported } from '@/lib/tts';
import { recordLessonCompletion, maybeGrantAchievements } from '@/lib/progress';
import { PageHeader, LoadingState, EmptyState } from '@/components/ui';
import type { RealWorldModule, RealWorldPhrase, QuizItem } from '@/types/database';

const ICONS: Record<string, LucideIcon> = {
  GraduationCap, Map, ShoppingCart, Stethoscope, Bus, Briefcase,
};

export default function RealWorldPage() {
  const { user, profile } = useAuth();
  const [modules, setModules] = useState<RealWorldModule[]>([]);
  const [phrases, setPhrases] = useState<RealWorldPhrase[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeModule, setActiveModule] = useState<RealWorldModule | null>(null);
  const [quizOpen, setQuizOpen] = useState(false);
  const [quizIdx, setQuizIdx] = useState(0);
  const [quizFeedback, setQuizFeedback] = useState<number | null>(null);
  const [quizDone, setQuizDone] = useState(false);
  const [score, setScore] = useState(0);
  const [completed, setCompleted] = useState<Set<string>>(new Set());
  const ttsOk = speechSynthesisSupported();

  useEffect(() => {
    (async () => {
      const [m, p] = await Promise.all([
        supabase.from('realworld_modules').select('*').order('order_idx'),
        supabase.from('realworld_phrases').select('*').order('order_idx'),
      ]);
      setModules((m.data as RealWorldModule[]) ?? []);
      setPhrases((p.data as RealWorldPhrase[]) ?? []);
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase.from('lesson_completions').select('item_id').eq('user_id', user.id).eq('kind', 'realworld');
      setCompleted(new Set((data ?? []).map((d) => d.item_id)));
    })();
  }, [user]);

  if (loading) return <LoadingState label="Loading real-world modules..." />;

  const modulePhrases = activeModule ? phrases.filter((p) => p.module_key === activeModule.module_key) : [];
  const allQuizItems: QuizItem[] = modulePhrases.flatMap((p) => p.quiz ?? []);

  const startQuiz = () => {
    setQuizOpen(true);
    setQuizIdx(0);
    setQuizFeedback(null);
    setQuizDone(false);
    setScore(0);
  };

  const answerQuiz = (optIdx: number) => {
    if (quizFeedback !== null) return;
    const q = allQuizItems[quizIdx];
    setQuizFeedback(optIdx);
    if (optIdx === q.correct_index) setScore((s) => s + 1);
  };

  const nextQuiz = () => {
    if (quizIdx + 1 < allQuizItems.length) {
      setQuizIdx((i) => i + 1);
      setQuizFeedback(null);
    } else {
      setQuizDone(true);
      if (user && activeModule) {
        setCompleted((s) => new Set(s).add(activeModule.module_key));
        (async () => {
          await recordLessonCompletion(user.id, 'realworld', activeModule.module_key, activeModule.title);
          await maybeGrantAchievements(user.id);
        })();
      }
    }
  };

  // ---- Module detail ----
  if (activeModule) {
    const Icon = ICONS[activeModule.icon] ?? Globe;
    return (
      <div>
        <button onClick={() => { setActiveModule(null); setQuizOpen(false); }} className="btn-ghost mb-4">
          <ChevronLeft size={16} /> All modules
        </button>

        <div className="card p-6 sm:p-8">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
              <Icon size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">{activeModule.title}</h1>
              <p className="text-sm text-slate-500">{activeModule.description}</p>
            </div>
            {completed.has(activeModule.module_key) && <CheckCircle2 className="ml-auto text-leaf-600" size={20} />}
          </div>

          {!quizOpen ? (
            <div className="mt-6 space-y-3">
              {modulePhrases.map((p) => (
                <div key={p.id} className="rounded-xl border border-slate-100 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <p className="font-kannada text-lg font-semibold text-slate-900">{p.kannada}</p>
                      <p className="text-xs text-brand-600">{p.transliteration}</p>
                      <p className="mt-1 text-sm text-slate-600">{p.hindi} · {p.english}</p>
                      <p className="mt-1 text-xs text-slate-400">Context: {p.context}</p>
                    </div>
                    <button onClick={() => speakKannada(p.kannada)} disabled={!ttsOk} className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-brand-600">
                      <Volume2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
              {modulePhrases.length > 0 && (
                <button onClick={startQuiz} className="btn-primary mt-2">
                  Take the {activeModule.title} quiz <ArrowRight size={14} />
                </button>
              )}
            </div>
          ) : (
            <div className="mt-6">
              {!quizDone ? (
                (() => {
                  const q = allQuizItems[quizIdx];
                  return (
                    <div>
                      <div className="mb-3 flex items-center justify-between">
                        <span className="text-xs font-semibold text-slate-500">Question {quizIdx + 1} of {allQuizItems.length}</span>
                        <span className="text-xs text-leaf-600">Score: {score}</span>
                      </div>
                      <p className="text-base font-semibold text-slate-900">{q.question}</p>
                      <div className="mt-4 space-y-2">
                        {q.options.map((opt, i) => {
                          const isChosen = quizFeedback !== null;
                          const isCorrect = i === q.correct_index;
                          const isChosenAns = quizFeedback === i;
                          let cls = 'border-slate-200 hover:border-brand-300 hover:bg-brand-50';
                          if (isChosen && isCorrect) cls = 'border-leaf-500 bg-leaf-50 text-leaf-700';
                          else if (isChosen && isChosenAns && !isCorrect) cls = 'border-red-400 bg-red-50 text-red-700';
                          else if (isChosen) cls = 'border-slate-200 opacity-60';
                          return (
                            <button key={i} onClick={() => answerQuiz(i)} disabled={isChosen} className={`flex w-full items-center gap-3 rounded-xl border px-4 py-3 text-left text-sm transition ${cls}`}>
                              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-slate-100 text-xs font-semibold">{String.fromCharCode(65 + i)}</span>
                              <span className="flex-1">{opt}</span>
                            </button>
                          );
                        })}
                      </div>
                      {quizFeedback !== null && (
                        <div className="mt-4 rounded-xl bg-slate-50 p-4">
                          <p className="text-sm text-slate-700">{q.explanation}</p>
                          <button onClick={nextQuiz} className="btn-primary mt-3">
                            {quizIdx + 1 < allQuizItems.length ? 'Next question' : 'Finish quiz'} <ArrowRight size={14} />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })()
              ) : (
                <div className="py-6 text-center">
                  <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-leaf-100 text-leaf-700">
                    <CheckCircle2 size={28} />
                  </div>
                  <p className="text-2xl font-bold text-slate-900">{score} / {allQuizItems.length}</p>
                  <p className="text-sm text-slate-500">{allQuizItems.length > 0 ? Math.round((score / allQuizItems.length) * 100) : 0}% correct</p>
                  <div className="mt-4 flex justify-center gap-2">
                    <button onClick={startQuiz} className="btn-outline"><RotateCcw size={14} /> Retry</button>
                    <button onClick={() => setQuizOpen(false)} className="btn-ghost">Back to phrases</button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  // ---- Modules list ----
  return (
    <div>
      <PageHeader icon={<Globe size={20} />} title="Real-World Kannada" subtitle="Practical phrases for everyday life in Karnataka. The Education module is the priority." />

      {modules.length === 0 ? (
        <EmptyState icon={<Globe size={40} />} title="No modules available" />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {modules.map((m) => {
            const Icon = ICONS[m.icon] ?? Globe;
            const isEducation = m.module_key === 'education';
            return (
              <button key={m.id} onClick={() => setActiveModule(m)} className="card group relative p-5 text-left transition hover:shadow-soft">
                {isEducation && <span className="absolute right-3 top-3 badge bg-leaf-100 text-leaf-700">Priority</span>}
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-50 text-brand-700 group-hover:bg-brand-700 group-hover:text-white transition-colors">
                  <Icon size={22} />
                </div>
                <h3 className="mt-3 font-semibold text-slate-900">{m.title}</h3>
                <p className="mt-1 text-sm text-slate-500">{m.description}</p>
                <div className="mt-3 flex items-center gap-2">
                  <span className="text-xs text-slate-400">{phrases.filter((p) => p.module_key === m.module_key).length} phrases</span>
                  {completed.has(m.module_key) && <span className="badge bg-leaf-100 text-leaf-700"><CheckCircle2 size={12} /> Done</span>}
                  <ArrowRight className="ml-auto text-slate-300 group-hover:text-brand-600" size={16} />
                </div>
              </button>
            );
          })}
        </div>
      )}
      <p className="mt-4 text-xs text-slate-400">
        {profile?.is_demo ? 'Demo mode: module completion is saved to your demo account.' : 'Your progress is saved automatically.'}
      </p>
    </div>
  );
}
