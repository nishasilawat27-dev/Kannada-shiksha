import { useEffect, useState } from 'react';
import { Type, ChevronLeft, ChevronRight, Volume2, CheckCircle2, Play } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { speakKannada, speechSynthesisSupported } from '@/lib/tts';
import { recordLessonCompletion } from '@/lib/progress';
import { PageHeader, LoadingState } from '@/components/ui';
import type { AlphabetLetter } from '@/types/database';

export default function AlphabetPage() {
  const { user, profile } = useAuth();
  const [letters, setLetters] = useState<AlphabetLetter[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'vowel' | 'consonant'>('vowel');
  const [index, setIndex] = useState(0);
  const [completed, setCompleted] = useState<Set<string>>(new Set());

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('alphabet').select('*').order('order_idx');
      setLetters((data as AlphabetLetter[]) ?? []);
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase
        .from('lesson_completions')
        .select('item_id')
        .eq('user_id', user.id)
        .eq('kind', 'alphabet');
      setCompleted(new Set((data ?? []).map((d) => d.item_id)));
    })();
  }, [user]);

  if (loading) return <LoadingState label="Loading the Kannada alphabet..." />;

  const filtered = letters.filter((l) => l.type === tab);
  const current = filtered[Math.min(index, filtered.length - 1)];
  const ttsOk = speechSynthesisSupported();

  const markLearned = async (letter: AlphabetLetter) => {
    if (!user || completed.has(letter.letter)) return;
    setCompleted((s) => new Set(s).add(letter.letter));
    await recordLessonCompletion(user.id, 'alphabet', letter.letter, `${letter.letter} (${letter.english})`);
  };

  return (
    <div>
      <PageHeader
        icon={<Type size={20} />}
        title="Kannada Alphabet"
        subtitle="Learn vowels (ಸ್ವರಗಳು) and consonants (ವ್ಯಂಜನಗಳು) with audio and examples."
      />

      <div className="mb-5 grid w-full max-w-sm grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
        <button onClick={() => { setTab('vowel'); setIndex(0); }} className={`rounded-lg py-2 text-sm font-semibold ${tab === 'vowel' ? 'bg-white text-brand-700 shadow-card' : 'text-slate-500'}`}>
          Vowels (ಸ್ವರಗಳು)
        </button>
        <button onClick={() => { setTab('consonant'); setIndex(0); }} className={`rounded-lg py-2 text-sm font-semibold ${tab === 'consonant' ? 'bg-white text-brand-700 shadow-card' : 'text-slate-500'}`}>
          Consonants (ವ್ಯಂಜನ)
        </button>
      </div>

      {current && (
        <div className="card overflow-hidden">
          <div className="grid items-center sm:grid-cols-2">
            <div className="flex flex-col items-center justify-center bg-gradient-to-br from-brand-50 to-leaf-50 p-8 text-center">
              <p className="font-kannada text-7xl font-bold text-slate-900 sm:text-8xl">{current.letter}</p>
              <p className="mt-2 text-lg font-semibold text-brand-700">{current.transliteration}</p>
              <p className="text-sm text-slate-500">{current.hindi} · {current.english}</p>
              <button
                onClick={() => speakKannada(current.letter)}
                disabled={!ttsOk}
                className="btn-outline mt-5"
              >
                <Volume2 size={16} /> {ttsOk ? 'Play sound' : 'Audio not supported'}
              </button>
            </div>
            <div className="p-6 sm:p-8">
              <h3 className="text-sm font-semibold text-slate-500">Example word</h3>
              <div className="mt-2 rounded-xl border border-slate-100 p-4">
                <p className="font-kannada text-3xl font-semibold text-slate-900">{current.example_word}</p>
                <p className="mt-1 text-sm text-brand-600">{current.example_transliteration}</p>
                <p className="text-sm text-slate-600">{current.example_meaning}</p>
                <button onClick={() => speakKannada(current.example_word)} disabled={!ttsOk} className="btn-ghost mt-3 px-2 py-1 text-xs">
                  <Play size={12} /> Play example
                </button>
              </div>

              <div className="mt-5 flex items-center justify-between">
                <div className="text-xs text-slate-500">
                  {index + 1} of {filtered.length}
                  {completed.has(current.letter) && <span className="ml-2 text-leaf-600 font-medium">· Learned</span>}
                </div>
                <button
                  onClick={() => markLearned(current)}
                  className={completed.has(current.letter) ? 'btn-leaf' : 'btn-outline'}
                >
                  <CheckCircle2 size={16} /> {completed.has(current.letter) ? 'Learned' : 'Mark as learned'}
                </button>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between border-t border-slate-100 px-6 py-4">
            <button
              onClick={() => setIndex((i) => Math.max(0, i - 1))}
              disabled={index === 0}
              className="btn-ghost"
            >
              <ChevronLeft size={16} /> Previous
            </button>
            <button
              onClick={() => setIndex((i) => Math.min(filtered.length - 1, i + 1))}
              disabled={index === filtered.length - 1}
              className="btn-ghost"
            >
              Next <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}

      {/* Letter grid */}
      <div className="mt-6">
        <p className="mb-3 text-sm font-semibold text-slate-700">{tab === 'vowel' ? 'All vowels' : 'All consonants'}</p>
        <div className="grid grid-cols-4 gap-2 sm:grid-cols-6 lg:grid-cols-10">
          {filtered.map((l, i) => (
            <button
              key={l.id}
              onClick={() => setIndex(i)}
              className={`relative flex flex-col items-center rounded-xl border p-3 transition hover:shadow-card ${i === index ? 'border-brand-500 bg-brand-50' : 'border-slate-100 bg-white'}`}
            >
              <span className="font-kannada text-2xl font-semibold text-slate-900">{l.letter}</span>
              <span className="text-[10px] text-slate-500">{l.transliteration}</span>
              {completed.has(l.letter) && (
                <CheckCircle2 className="absolute -right-1 -top-1 text-leaf-600 bg-white rounded-full" size={14} />
              )}
            </button>
          ))}
        </div>
      </div>

      <p className="mt-4 text-xs text-slate-400">
        {profile?.is_demo ? 'Demo mode: progress is saved to your demo account.' : 'Your progress is saved automatically.'}
      </p>
    </div>
  );
}
