import { useEffect, useState, useMemo } from 'react';
import { TrendingUp, Award, BookOpen, ClipboardList, Languages, Flame, Trophy } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  LineChart, Line, Legend,
} from 'recharts';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { PageHeader, LoadingState, EmptyState } from '@/components/ui';
import { formatDate } from '@/lib/helpers';
import type { LessonCompletion, QuizAttempt, UserAchievement, Achievement, LearningActivity, FavoriteVocabulary } from '@/types/database';

export default function ProgressPage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [completions, setCompletions] = useState<LessonCompletion[]>([]);
  const [attempts, setAttempts] = useState<QuizAttempt[]>([]);
  const [userAch, setUserAch] = useState<UserAchievement[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [activity, setActivity] = useState<LearningActivity[]>([]);
  const [favorites, setFavorites] = useState<FavoriteVocabulary[]>([]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [c, a, ua, ach, act, fav] = await Promise.all([
        supabase.from('lesson_completions').select('*').eq('user_id', user.id).order('completed_at', { ascending: false }),
        supabase.from('quiz_attempts').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
        supabase.from('user_achievements').select('*').eq('user_id', user.id),
        supabase.from('achievements').select('*'),
        supabase.from('learning_activity').select('*').eq('user_id', user.id).order('activity_date', { ascending: true }),
        supabase.from('favorite_vocabulary').select('*').eq('user_id', user.id),
      ]);
      setCompletions((c.data ?? []) as LessonCompletion[]);
      setAttempts((a.data ?? []) as QuizAttempt[]);
      setUserAch((ua.data ?? []) as UserAchievement[]);
      setAchievements((ach.data ?? []) as Achievement[]);
      setActivity((act.data ?? []) as LearningActivity[]);
      setFavorites((fav.data ?? []) as FavoriteVocabulary[]);
      setLoading(false);
    })();
  }, [user]);

  const bestScore = useMemo(() => attempts.reduce((m, a) => Math.max(m, Number(a.percentage)), 0), [attempts]);

  const chartData = useMemo(() => {
    // last 14 days activity
    const days: { date: string; lessons: number; quizzes: number; words: number }[] = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const iso = d.toISOString().slice(0, 10);
      const row = activity.find((a) => a.activity_date === iso);
      days.push({
        date: d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }),
        lessons: row?.lessons_completed || 0,
        quizzes: row?.quizzes_taken || 0,
        words: row?.words_learned || 0,
      });
    }
    return days;
  }, [activity]);

  const categoryProgress = useMemo(() => {
    const byKind: Record<string, number> = {};
    completions.forEach((c) => { byKind[c.kind] = (byKind[c.kind] || 0) + 1; });
    return Object.entries(byKind).map(([k, v]) => ({ kind: k, count: v }));
  }, [completions]);

  const earnedKeys = new Set(userAch.map((a) => a.achievement_key));

  if (loading) return <LoadingState label="Loading your progress..." />;

  const summary = [
    { label: 'Lessons completed', value: completions.length, icon: BookOpen, color: 'text-brand-700 bg-brand-50' },
    { label: 'Quizzes taken', value: attempts.length, icon: ClipboardList, color: 'text-leaf-700 bg-leaf-50' },
    { label: 'Words saved', value: favorites.length, icon: Languages, color: 'text-amber-700 bg-amber-50' },
    { label: 'Best quiz score', value: `${bestScore}%`, icon: Trophy, color: 'text-purple-700 bg-purple-50' },
  ];

  return (
    <div>
      <PageHeader icon={<TrendingUp size={20} />} title="Progress & Achievements" subtitle="Your real learning activity, updated as you learn." />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {summary.map((s) => (
          <div key={s.label} className="card p-4">
            <div className={`mb-2 flex h-9 w-9 items-center justify-center rounded-lg ${s.color}`}>
              <s.icon size={18} />
            </div>
            <p className="text-2xl font-bold text-slate-900">{s.value}</p>
            <p className="text-xs text-slate-500">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Activity chart */}
      <div className="card mt-5 p-5">
        <p className="mb-3 text-sm font-semibold text-slate-700">Daily activity (last 14 days)</p>
        {activity.length === 0 ? (
          <EmptyState icon={<TrendingUp size={36} />} title="No activity yet" description="Complete a lesson or quiz to see your activity chart." />
        ) : (
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="#94a3b8" />
              <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" allowDecimals={false} />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="lessons" name="Lessons" fill="#1f66f5" radius={[4, 4, 0, 0]} />
              <Bar dataKey="quizzes" name="Quizzes" fill="#22a05c" radius={[4, 4, 0, 0]} />
              <Bar dataKey="words" name="Words" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* Category-wise progress */}
      {categoryProgress.length > 0 && (
        <div className="card mt-5 p-5">
          <p className="mb-3 text-sm font-semibold text-slate-700">Category-wise progress</p>
          <div className="space-y-3">
            {categoryProgress.map((c) => (
              <div key={c.kind}>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-600 capitalize">{c.kind}</span>
                  <span className="text-slate-500">{c.count} completed</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                  <div className="h-full rounded-full bg-brand-500" style={{ width: `${Math.min(100, c.count * 10)}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quiz history */}
      <div className="card mt-5 p-5">
        <p className="mb-3 text-sm font-semibold text-slate-700">Quiz history</p>
        {attempts.length === 0 ? (
          <p className="text-xs text-slate-500">No quizzes taken yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-slate-500 border-b border-slate-100">
                  <th className="pb-2 font-medium">Quiz</th>
                  <th className="pb-2 font-medium">Score</th>
                  <th className="pb-2 font-medium">%</th>
                  <th className="pb-2 font-medium">Date</th>
                </tr>
              </thead>
              <tbody>
                {attempts.map((a) => (
                  <tr key={a.id} className="border-b border-slate-50">
                    <td className="py-2 text-slate-700">{a.quiz_title}</td>
                    <td className="py-2 text-slate-700">{a.score}/{a.total}</td>
                    <td className="py-2">
                      <span className={`badge ${Number(a.percentage) >= 80 ? 'bg-leaf-100 text-leaf-700' : 'bg-amber-100 text-amber-700'}`}>{a.percentage}%</span>
                    </td>
                    <td className="py-2 text-xs text-slate-500">{formatDate(a.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Achievements */}
      <div className="card mt-5 p-5">
        <div className="mb-3 flex items-center gap-2">
          <Award className="text-amber-600" size={18} />
          <p className="text-sm font-semibold text-slate-700">Achievements</p>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {achievements.map((a) => {
            const earned = earnedKeys.has(a.achievement_key);
            return (
              <div key={a.id} className={`flex items-center gap-3 rounded-xl border p-4 ${earned ? 'border-amber-200 bg-amber-50' : 'border-slate-100 opacity-60'}`}>
                <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${earned ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-400'}`}>
                  <Trophy size={18} />
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-800">{a.title}</p>
                  <p className="text-xs text-slate-500">{a.description}</p>
                  <p className="mt-1 text-xs">{earned ? <span className="text-leaf-600">Earned</span> : <span className="text-slate-400">Not earned yet</span>}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
