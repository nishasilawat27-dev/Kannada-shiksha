import { useEffect, useRef, useState } from 'react';
import { Headphones, Volume2, Mic, Square, Play, Repeat, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { speakKannada, speechSynthesisSupported, speechRecognitionSupported, isKannadaVoiceAvailable } from '@/lib/tts';
import { PageHeader, LoadingState, EmptyState } from '@/components/ui';
import type { ListeningItem } from '@/types/database';

export default function ListeningPage() {
  const { user } = useAuth();
  const [items, setItems] = useState<ListeningItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [recording, setRecording] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [micError, setMicError] = useState<string | null>(null);
  const [recogText, setRecogText] = useState<string | null>(null);
  const [recogMatch, setRecogMatch] = useState<boolean | null>(null);
  const mediaRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const recogRef = useRef<unknown>(null);

  const ttsOk = speechSynthesisSupported();
  const recogOk = speechRecognitionSupported();
  const knVoice = isKannadaVoiceAvailable();

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('listening_items').select('*').order('order_idx');
      setItems((data as ListeningItem[]) ?? []);
      setLoading(false);
    })();
  }, []);

  const startRecord = async (item: ListeningItem) => {
    setAudioUrl(null);
    setRecogText(null);
    setRecogMatch(null);
    setMicError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        setAudioUrl(URL.createObjectURL(blob));
        stream.getTracks().forEach((t) => t.stop());
      };
      recorder.start();
      mediaRef.current = recorder;
      setRecording(true);

      // Optional speech recognition
      if (recogOk) {
        try {
          const SR = (window as unknown as { SpeechRecognition?: new () => unknown; webkitSpeechRecognition?: new () => unknown }).SpeechRecognition
            || (window as unknown as { webkitSpeechRecognition?: new () => unknown }).webkitSpeechRecognition;
          if (SR) {
            const rec = new (SR as new () => {
              lang: string; interimResults: boolean; onresult: (e: { results: { 0: { 0: { transcript: string } } } }) => void;
              onerror: () => void; start: () => void; stop: () => void;
            })();
            rec.lang = 'kn-IN';
            rec.interimResults = false;
            rec.onresult = (e) => {
              const text = e.results[0][0].transcript.trim();
              setRecogText(text);
              setRecogMatch(text.replace(/[।.,?!]/g, '').trim() === item.kannada.replace(/[।.,?!]/g, '').trim());
            };
            rec.onerror = () => setRecogText(null);
            rec.start();
            recogRef.current = rec;
          }
        } catch {
          // recognition failed; ignore
        }
      }
    } catch {
      setMicError('Microphone access is unavailable. Please allow microphone permission to use recording.');
    }
  };

  const stopRecord = () => {
    if (mediaRef.current && mediaRef.current.state !== 'inactive') {
      mediaRef.current.stop();
    }
    const rec = recogRef.current as { stop?: () => void } | null;
    rec?.stop?.();
    setRecording(false);
  };

  if (loading) return <LoadingState label="Loading listening items..." />;

  return (
    <div>
      <PageHeader icon={<Headphones size={20} />} title="Listening & Pronunciation" subtitle="Hear Kannada, record yourself, and compare with the target." />

      {!ttsOk && (
        <div className="mb-4 rounded-xl bg-amber-50 border border-amber-100 px-4 py-3 text-sm text-amber-800">
          Your browser does not support Text-to-Speech. You can still see the text and transliteration.
        </div>
      )}
      {ttsOk && !knVoice && (
        <div className="mb-4 rounded-xl bg-slate-50 border border-slate-100 px-4 py-3 text-xs text-slate-600">
          A Kannada TTS voice may not be installed on this device. The browser will attempt the closest available voice.
        </div>
      )}

      {items.length === 0 ? (
        <EmptyState icon={<Headphones size={40} />} title="No listening items yet" />
      ) : (
        <div className="space-y-3">
          {items.map((item) => {
            const open = activeId === item.id;
            return (
              <div key={item.id} className="card overflow-hidden">
                <button onClick={() => setActiveId(open ? null : item.id)} className="flex w-full items-center gap-4 p-4 text-left">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
                    <Volume2 size={18} />
                  </div>
                  <div className="flex-1">
                    <p className="font-kannada text-lg font-semibold text-slate-900">{item.kannada}</p>
                    <p className="text-xs text-brand-600">{item.transliteration} · {item.hindi} · {item.english}</p>
                  </div>
                  <span className="text-xs text-slate-400">{open ? 'Hide' : 'Practice'}</span>
                </button>

                {open && (
                  <div className="border-t border-slate-100 p-4">
                    <div className="flex flex-wrap gap-2">
                      <button onClick={() => speakKannada(item.kannada)} disabled={!ttsOk} className="btn-primary">
                        <Volume2 size={16} /> Play
                      </button>
                      <button onClick={() => speakKannada(item.kannada)} disabled={!ttsOk} className="btn-outline">
                        <Repeat size={14} /> Repeat
                      </button>
                      {!recording ? (
                        <button onClick={() => startRecord(item)} className="btn-outline">
                          <Mic size={14} /> Record
                        </button>
                      ) : (
                        <button onClick={stopRecord} className="btn-leaf">
                          <Square size={14} /> Stop
                        </button>
                      )}
                    </div>

                    {micError && (
                      <p className="mt-3 text-xs text-red-600">{micError}</p>
                    )}

                    {recording && (
                      <div className="mt-3 flex items-center gap-2 text-xs text-red-600">
                        <span className="h-2 w-2 animate-pulse rounded-full bg-red-500" /> Recording...
                      </div>
                    )}

                    {audioUrl && (
                      <div className="mt-3 rounded-xl bg-slate-50 p-3">
                        <p className="mb-2 text-xs font-semibold text-slate-600">Your recording</p>
                        <audio src={audioUrl} controls className="w-full" />
                        <div className="mt-2 flex items-center gap-2 text-xs text-slate-500">
                          <Play size={12} /> Play back and compare with the original.
                        </div>
                      </div>
                    )}

                    {recogText !== null && (
                      <div className="mt-3 rounded-xl bg-slate-50 p-3">
                        <p className="text-xs font-semibold text-slate-600">Speech recognition result</p>
                        <p className="mt-1 text-sm text-slate-700">{recogText || '(no speech detected)'}</p>
                        {recogMatch !== null && (
                          <p className={`mt-1 text-xs ${recogMatch ? 'text-leaf-700' : 'text-amber-600'}`}>
                            {recogMatch ? <><CheckCircle2 size={12} className="inline" /> Matches the target phrase!</> : 'Close — keep practicing!'}
                          </p>
                        )}
                        {!recogOk && (
                          <p className="mt-1 text-xs text-slate-400">Kannada speech recognition is not supported in this browser.</p>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <p className="mt-4 text-xs text-slate-400">
        {user ? 'Listening practice is for learning only — no pronunciation accuracy score is claimed without a real assessment engine.' : ''}
      </p>
    </div>
  );
}
