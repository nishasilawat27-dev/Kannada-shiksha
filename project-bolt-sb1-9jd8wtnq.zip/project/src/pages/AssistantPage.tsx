import { useEffect, useRef, useState } from 'react';
import { Bot, Send, Trash2, Sparkles, BookOpen, Languages } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { PageHeader } from '@/components/ui';
import type { VocabularyWord } from '@/types/database';

interface ChatMsg {
  role: 'user' | 'assistant';
  content: string;
}

const SUGGESTIONS = [
  'Teach me five basic Kannada words.',
  'Explain this Kannada sentence in Hindi: ನನ್ನ ಹೆಸರು ರವಿ.',
  'Help me talk to my college teacher.',
  'Give me a beginner Kannada quiz.',
];

export default function AssistantPage() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState('');
  const [vocab, setVocab] = useState<VocabularyWord[]>([]);
  const [thinking, setThinking] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('vocabulary').select('*').order('order_idx').limit(60);
      setVocab((data as VocabularyWord[]) ?? []);
    })();
    setMessages([{ role: 'assistant', content: 'Namaskara! I am your Kannada learning assistant. Ask me to teach words, explain sentences, or suggest lessons. (Running in offline knowledge mode — no API key configured.)' }]);
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, thinking]);

  const generateReply = (prompt: string): string => {
    const p = prompt.toLowerCase();

    if (p.includes('five basic') || p.includes('5 basic') || (p.includes('teach') && p.includes('word'))) {
      const five = vocab.slice(0, 5);
      if (five.length === 0) return 'Vocabulary is loading. Please try again in a moment.';
      return `Here are 5 basic Kannada words:\n\n${five.map((w) => `• ${w.kannada} (${w.transliteration}) — ${w.hindi} / ${w.english}`).join('\n')}\n\nWant to hear them? Visit the Vocabulary page for audio.`;
    }

    if (p.includes('ನನ್ನ ಹೆಸರು') || p.includes('hesaru')) {
      return 'ನನ್ನ ಹೆಸರು ರವಿ (Nanna hesaru Ravi) means "मेरा नाम रवि है" / "My name is Ravi." Breakdown:\n• ನನ್ನ (nanna) = my\n• ಹೆಸರು (hesaru) = name\n• ರವಿ = Ravi\n\nSuggested lesson: Grammar → Pronouns and Possessive Forms.';
    }

    if (p.includes('teacher') || p.includes('college') || p.includes('class')) {
      return 'To talk to your teacher in Kannada, start with:\n• ಗುರುಗಳೇ, ನಮಸ್ಕಾರ (Gurugale, namaskara) — Teacher, hello\n• ಈ ಪಾಠ ವಿವರಿಸಿ (Ee paaTha vivarisi) — Please explain this lesson\n• ಒಂದು ಪ್ರಶ್ನೆ ಇದೆ (Ondu prashne ide) — I have a question\n\nSuggested module: Real-World Kannada → Education.';
    }

    if (p.includes('quiz') || p.includes('practice question')) {
      return 'Here is a mini quiz question:\n\nQ: What does "ನಮಸ್ಕಾರ" mean?\nA) Goodbye  B) Hello  C) Sorry  D) Thanks\n\nAnswer: B) Hello.\n\nVisit the Quizzes page for full quizzes with 10 questions each.';
    }

    if (p.includes('translate') || p.includes('meaning')) {
      // try to find matching word
      const match = vocab.find((w) => prompt.includes(w.kannada) || p.includes(w.transliteration.toLowerCase()) || p.includes(w.english.toLowerCase()));
      if (match) {
        return `${match.kannada} (${match.transliteration})\nHindi: ${match.hindi}\nEnglish: ${match.english}\nExample: ${match.example_kannada} — ${match.example_meaning}`;
      }
      return 'Tell me the Kannada word or sentence you want translated, and I will do my best using the verified vocabulary database. For new phrases, check the Conversations or Real-World Kannada pages.';
    }

    if (p.includes('grammar') || p.includes('sentence structure')) {
      return 'Kannada uses Subject-Object-Verb order, like Hindi. Example: ನಾನು ಅನ್ನ ತಿನ್ನುತ್ತೇನೆ (Naanu anna tinnuttene) = I + rice + eat. Visit Grammar Lessons for 15 structured lessons.';
    }

    if (p.includes('hello') || p.includes('namaskara') || p.includes('greet')) {
      return 'Common greetings:\n• ನಮಸ್ಕಾರ (Namaskara) — Hello\n• ಶುಭೋದಯ (Shubhodaya) — Good morning\n• ಧನ್ಯವಾದಗಳು (Dhanyavaadagalu) — Thank you';
    }

    return 'I can help with Kannada words, grammar, conversations, and quizzes. Try one of the suggested prompts below, or ask me to translate a short phrase. (Offline knowledge mode — responses come from the verified content database, not a live AI API.)';
  };

  const send = async (text: string) => {
    if (!text.trim() || thinking) return;
    const userMsg: ChatMsg = { role: 'user', content: text };
    setMessages((m) => [...m, userMsg]);
    setInput('');
    setThinking(true);
    // Simulate thinking for UX
    await new Promise((r) => setTimeout(r, 450));
    const reply = generateReply(text);
    setMessages((m) => [...m, { role: 'assistant', content: reply }]);
    setThinking(false);
  };

  return (
    <div>
      <PageHeader icon={<Bot size={20} />} title="AI Kannada Assistant" subtitle="Ask questions, get explanations, and practice. Runs in offline knowledge mode." />

      <div className="card flex flex-col" style={{ height: 'calc(100vh - 220px)', minHeight: '420px' }}>
        <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-50 text-brand-700">
              <Bot size={16} />
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-800">Kannada Assistant</p>
              <p className="text-xs text-slate-500">Offline knowledge mode</p>
            </div>
          </div>
          <button onClick={() => setMessages([{ role: 'assistant', content: 'Conversation cleared. Ask me anything about Kannada!' }])} className="btn-ghost px-2 py-1.5 text-xs">
            <Trash2 size={14} /> Clear
          </button>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm whitespace-pre-line ${m.role === 'user' ? 'bg-brand-700 text-white' : 'bg-slate-100 text-slate-800'}`}>
                {m.content}
              </div>
            </div>
          ))}
          {thinking && (
            <div className="flex justify-start">
              <div className="rounded-2xl bg-slate-100 px-4 py-2.5">
                <div className="flex gap-1">
                  <span className="h-2 w-2 animate-bounce rounded-full bg-slate-400" style={{ animationDelay: '0ms' }} />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-slate-400" style={{ animationDelay: '150ms' }} />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-slate-400" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Suggestions */}
        <div className="border-t border-slate-100 px-4 py-2">
          <div className="mb-2 flex flex-wrap gap-1.5">
            {SUGGESTIONS.map((s) => (
              <button key={s} onClick={() => send(s)} className="rounded-full bg-slate-50 px-2.5 py-1 text-xs text-slate-600 hover:bg-brand-50 hover:text-brand-700 border border-slate-100">
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Input */}
        <div className="border-t border-slate-100 p-3">
          <form
            onSubmit={(e) => { e.preventDefault(); send(input); }}
            className="flex items-center gap-2"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about Kannada words, grammar, or conversations..."
              className="input flex-1"
            />
            <button type="submit" disabled={!input.trim() || thinking} className="btn-primary px-3">
              <Send size={16} />
            </button>
          </form>
        </div>
      </div>

      <div className="mt-3 flex items-start gap-2 rounded-xl bg-amber-50 border border-amber-100 px-4 py-3 text-xs text-amber-800">
        <Sparkles size={14} className="mt-0.5 shrink-0" />
        <p>
          This assistant uses verified Kannada content from the database. To enable a full AI model,
          connect an API key in the backend (environment variable) — the app will keep working without it.
          Translations are from curated content; verify new phrases with a native speaker.
        </p>
      </div>
      <span className="hidden"><BookOpen size={1} /><Languages size={1} /></span>
      {user ? null : null}
    </div>
  );
}
