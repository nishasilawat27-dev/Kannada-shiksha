import { useState, type FormEvent } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { GraduationCap, Mail, Lock, User as UserIcon, Sparkles } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import type { LearningLang, LearningLevel } from '@/types/database';
import { Spinner } from '@/components/ui';

export default function LoginPage() {
  const { signIn, signUp, signInDemo } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [lang, setLang] = useState<LearningLang>('en');
  const [level, setLevel] = useState<LearningLevel>('beginner');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [demoLoading, setDemoLoading] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      setSubmitting(false);
      return;
    }
    if (mode === 'register') {
      if (!fullName.trim()) {
        setError('Please enter your full name.');
        setSubmitting(false);
        return;
      }
      const { error } = await signUp({ email, password, full_name: fullName, preferred_lang: lang, level });
      if (error) setError(error);
      else navigate('/dashboard');
    } else {
      const { error } = await signIn(email, password);
      if (error) setError(error);
      else navigate('/dashboard');
    }
    setSubmitting(false);
  };

  const demo = async () => {
    setError(null);
    setDemoLoading(true);
    const { error } = await signInDemo();
    if (error) setError(error);
    else navigate('/dashboard');
    setDemoLoading(false);
  };

  return (
    <div className="grid min-h-[calc(100vh-0px)] place-items-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 flex items-center justify-center gap-2.5">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-700 text-white shadow-card">
            <GraduationCap size={22} />
          </div>
          <div>
            <p className="font-bold text-slate-900 leading-tight">Kannada Shiksha</p>
            <p className="text-xs text-slate-500">Learn Kannada Easily</p>
          </div>
        </div>

        <div className="card p-6 sm:p-7">
          <div className="mb-5 grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
            <button
              onClick={() => setMode('login')}
              className={`rounded-lg py-2 text-sm font-semibold transition ${mode === 'login' ? 'bg-white text-brand-700 shadow-card' : 'text-slate-500'}`}
            >
              Sign in
            </button>
            <button
              onClick={() => setMode('register')}
              className={`rounded-lg py-2 text-sm font-semibold transition ${mode === 'register' ? 'bg-white text-brand-700 shadow-card' : 'text-slate-500'}`}
            >
              Create account
            </button>
          </div>

          <form onSubmit={submit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className="label" htmlFor="fullName">Full name</label>
                <div className="relative">
                  <UserIcon className="absolute left-3 top-3 text-slate-400" size={16} />
                  <input id="fullName" className="input pl-9" value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Your name" autoComplete="name" />
                </div>
              </div>
            )}
            <div>
              <label className="label" htmlFor="email">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 text-slate-400" size={16} />
                <input id="email" type="email" className="input pl-9" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" required />
              </div>
            </div>
            <div>
              <label className="label" htmlFor="password">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 text-slate-400" size={16} />
                <input id="password" type="password" className="input pl-9" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 6 characters" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required />
              </div>
            </div>

            {mode === 'register' && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label" htmlFor="lang">Learning language</label>
                  <select id="lang" className="input" value={lang} onChange={(e) => setLang(e.target.value as LearningLang)}>
                    <option value="en">English</option>
                    <option value="hi">हिंदी (Hindi)</option>
                  </select>
                </div>
                <div>
                  <label className="label" htmlFor="level">Level</label>
                  <select id="level" className="input" value={level} onChange={(e) => setLevel(e.target.value as LearningLevel)}>
                    <option value="beginner">Beginner</option>
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                  </select>
                </div>
              </div>
            )}

            {error && (
              <div className="rounded-xl bg-red-50 px-3 py-2.5 text-sm text-red-700 border border-red-100">
                {error}
              </div>
            )}

            <button type="submit" disabled={submitting} className="btn-primary w-full">
              {submitting ? <Spinner /> : mode === 'login' ? 'Sign in' : 'Create account'}
            </button>
          </form>

          <div className="my-4 flex items-center gap-3 text-xs text-slate-400">
            <div className="h-px flex-1 bg-slate-200" />
            or
            <div className="h-px flex-1 bg-slate-200" />
          </div>

          <button onClick={demo} disabled={demoLoading} className="btn-outline w-full">
            {demoLoading ? <Spinner /> : <Sparkles size={16} className="text-leaf-600" />}
            Try demo account
          </button>
          <p className="mt-2 text-center text-xs text-slate-400">
            Demo mode loads sample progress so you can explore the platform.
          </p>
        </div>

        <p className="mt-4 text-center text-xs text-slate-500">
          <Link to="/" className="hover:text-brand-700">← Back to home</Link>
        </p>
      </div>
    </div>
  );
}
