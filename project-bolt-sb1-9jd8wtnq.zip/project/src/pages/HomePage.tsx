import { useNavigate } from 'react-router-dom';
import {
  Languages, MessagesSquare, BookOpen, ClipboardList, Bot,
  ArrowRight, GraduationCap, Compass, Stethoscope, Bus, ShoppingCart, Briefcase,
  CheckCircle2,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

const features = [
  { icon: Languages, title: 'Vocabulary', desc: '120+ words across 14 categories with audio.', to: '/vocabulary' },
  { icon: MessagesSquare, title: 'Conversations', desc: 'Real dialogues for everyday situations.', to: '/conversations' },
  { icon: BookOpen, title: 'Grammar', desc: '15 structured beginner-friendly lessons.', to: '/grammar' },
  { icon: ClipboardList, title: 'Quizzes', desc: 'Interactive quizzes with instant feedback.', to: '/quizzes' },
  { icon: Bot, title: 'AI Assistant', desc: 'Ask questions and get Kannada help anytime.', to: '/assistant' },
];

const realWorld = [
  { icon: GraduationCap, label: 'Education', to: '/realworld' },
  { icon: Compass, label: 'Travel', to: '/realworld' },
  { icon: ShoppingCart, label: 'Shopping', to: '/realworld' },
  { icon: Stethoscope, label: 'Healthcare', to: '/realworld' },
  { icon: Bus, label: 'Transport', to: '/realworld' },
  { icon: Briefcase, label: 'Workplace', to: '/realworld' },
];

const steps = [
  { n: 1, title: 'Learn the basics', desc: 'Start with the Kannada alphabet and common words.' },
  { n: 2, title: 'Practice conversations', desc: 'Use real-world dialogues for school, travel and work.' },
  { n: 3, title: 'Test yourself', desc: 'Take quizzes and track your progress over time.' },
];

export default function HomePage() {
  const navigate = useNavigate();
  const { session } = useAuth();

  return (
    <div className="space-y-16">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-800 via-brand-700 to-leaf-700 px-6 py-14 text-white sm:px-12 sm:py-20">
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-2xl" />
        <div className="absolute -bottom-20 -left-10 h-72 w-72 rounded-full bg-leaf-400/20 blur-3xl" />
        <div className="relative max-w-2xl">
          <div className="mb-5 inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-xs font-medium backdrop-blur">
            <GraduationCap size={14} /> Kannada Shiksha — Education focused
          </div>
          <h1 className="text-3xl font-bold leading-tight sm:text-5xl">
            Learn Kannada.<br />Speak Confidently.<br />Connect with Everyone.
          </h1>
          <p className="mt-5 max-w-xl text-base text-white/85 sm:text-lg">
            A simple, interactive way to learn Kannada through Hindi and English — built for students,
            beginners, and anyone new to Karnataka.
          </p>
          <div className="mt-7 flex flex-wrap gap-3">
            <button
              onClick={() => navigate(session ? '/dashboard' : '/login')}
              className="btn bg-white text-brand-800 hover:bg-brand-50"
            >
              Get Started <ArrowRight size={16} />
            </button>
            <button
              onClick={() => navigate('/grammar')}
              className="btn bg-white/10 text-white hover:bg-white/20 border border-white/20"
            >
              Explore Lessons
            </button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section>
        <h2 className="text-xl font-bold text-slate-900 sm:text-2xl">Everything you need to learn Kannada</h2>
        <p className="mt-1 text-sm text-slate-500">Interactive lessons, real conversations, and smart practice tools.</p>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <button
              key={f.title}
              onClick={() => navigate(f.to)}
              className="card group p-5 text-left transition-all hover:-translate-y-0.5 hover:shadow-soft"
            >
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50 text-brand-700 group-hover:bg-brand-700 group-hover:text-white transition-colors">
                <f.icon size={20} />
              </div>
              <h3 className="font-semibold text-slate-900">{f.title}</h3>
              <p className="mt-1 text-sm text-slate-500">{f.desc}</p>
            </button>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="card p-6 sm:p-8">
        <h2 className="text-xl font-bold text-slate-900 sm:text-2xl">How learning works</h2>
        <div className="mt-6 grid gap-6 sm:grid-cols-3">
          {steps.map((s) => (
            <div key={s.n} className="relative">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-leaf-100 text-leaf-700 font-bold">
                {s.n}
              </div>
              <h3 className="mt-3 font-semibold text-slate-900">{s.title}</h3>
              <p className="mt-1 text-sm text-slate-500">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Real-world */}
      <section>
        <h2 className="text-xl font-bold text-slate-900 sm:text-2xl">Kannada for real-world situations</h2>
        <p className="mt-1 text-sm text-slate-500">Practical phrases for everyday life in Karnataka.</p>
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {realWorld.map((r) => (
            <button
              key={r.label}
              onClick={() => navigate(r.to)}
              className="card flex flex-col items-center gap-2 p-4 text-center transition-all hover:-translate-y-0.5 hover:shadow-soft"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-leaf-50 text-leaf-700">
                <r.icon size={20} />
              </div>
              <span className="text-sm font-medium text-slate-700">{r.label}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Sample lesson */}
      <section className="card overflow-hidden">
        <div className="grid lg:grid-cols-2">
          <div className="bg-brand-50 p-6 sm:p-8">
            <span className="badge bg-leaf-100 text-leaf-700">Sample lesson</span>
            <h2 className="mt-3 text-xl font-bold text-slate-900">Your first Kannada greeting</h2>
            <p className="mt-2 text-sm text-slate-600">
              See how easy it is to start. Every word comes with transliteration, Hindi and English meanings.
            </p>
            <button onClick={() => navigate(session ? '/alphabet' : '/login')} className="btn-primary mt-5">
              Start learning free <ArrowRight size={16} />
            </button>
          </div>
          <div className="p-6 sm:p-8 space-y-3">
            {[
              { k: 'ನಮಸ್ಕಾರ', t: 'Namaskara', h: 'नमस्ते', e: 'Hello' },
              { k: 'ನಿಮ್ಮ ಹೆಸರು ಏನು?', t: 'Nimma hesaru enu?', h: 'आपका नाम क्या है?', e: 'What is your name?' },
              { k: 'ನನ್ನ ಹೆಸರು ರವಿ', t: 'Nanna hesaru Ravi', h: 'मेरा नाम रवि है', e: 'My name is Ravi' },
            ].map((row) => (
              <div key={row.k} className="flex items-start gap-3 rounded-xl border border-slate-100 p-3">
                <CheckCircle2 className="mt-0.5 shrink-0 text-leaf-600" size={18} />
                <div>
                  <p className="font-kannada text-lg font-semibold text-slate-900">{row.k}</p>
                  <p className="text-xs text-brand-600">{row.t}</p>
                  <p className="text-sm text-slate-600">{row.h} · {row.e}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 pt-8 pb-4 text-sm text-slate-500">
        <div className="flex flex-col gap-6 sm:flex-row sm:justify-between">
          <div className="max-w-xs">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-700 text-white">
                <GraduationCap size={16} />
              </div>
              <span className="font-bold text-slate-900">Kannada Shiksha</span>
            </div>
            <p className="mt-2 text-xs">
              An educational platform helping people learn and use Kannada in everyday life.
            </p>
          </div>
          <div className="flex gap-10">
            <div>
              <p className="font-semibold text-slate-700">Features</p>
              <ul className="mt-2 space-y-1 text-xs">
                <li><button onClick={() => navigate('/vocabulary')} className="hover:text-brand-700">Vocabulary</button></li>
                <li><button onClick={() => navigate('/grammar')} className="hover:text-brand-700">Grammar</button></li>
                <li><button onClick={() => navigate('/quizzes')} className="hover:text-brand-700">Quizzes</button></li>
              </ul>
            </div>
            <div>
              <p className="font-semibold text-slate-700">About</p>
              <ul className="mt-2 space-y-1 text-xs">
                <li><button onClick={() => navigate('/about')} className="hover:text-brand-700">Project</button></li>
                <li><button onClick={() => navigate('/login')} className="hover:text-brand-700">Sign in</button></li>
                <li><a href="mailto:hello@kannadashiksha.in" className="hover:text-brand-700">Contact</a></li>
              </ul>
            </div>
          </div>
        </div>
        <p className="mt-6 text-xs text-slate-400">© 2026 Kannada Shiksha. Built for learners across Karnataka.</p>
      </footer>
    </div>
  );
}
