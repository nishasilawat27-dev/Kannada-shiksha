import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '@/context/AuthContext';
import Layout from '@/components/Layout';
import ProtectedRoute from '@/components/ProtectedRoute';
import HomePage from '@/pages/HomePage';
import LoginPage from '@/pages/LoginPage';
import DashboardPage from '@/pages/DashboardPage';
import AlphabetPage from '@/pages/AlphabetPage';
import VocabularyPage from '@/pages/VocabularyPage';
import GrammarPage from '@/pages/GrammarPage';
import ConversationsPage from '@/pages/ConversationsPage';
import RealWorldPage from '@/pages/RealWorldPage';
import ListeningPage from '@/pages/ListeningPage';
import QuizzesPage from '@/pages/QuizzesPage';
import AssistantPage from '@/pages/AssistantPage';
import ProgressPage from '@/pages/ProgressPage';
import ProfilePage from '@/pages/ProfilePage';
import AboutPage from '@/pages/AboutPage';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Layout>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
            <Route path="/alphabet" element={<ProtectedRoute><AlphabetPage /></ProtectedRoute>} />
            <Route path="/vocabulary" element={<ProtectedRoute><VocabularyPage /></ProtectedRoute>} />
            <Route path="/grammar" element={<ProtectedRoute><GrammarPage /></ProtectedRoute>} />
            <Route path="/conversations" element={<ProtectedRoute><ConversationsPage /></ProtectedRoute>} />
            <Route path="/realworld" element={<ProtectedRoute><RealWorldPage /></ProtectedRoute>} />
            <Route path="/listening" element={<ProtectedRoute><ListeningPage /></ProtectedRoute>} />
            <Route path="/quizzes" element={<ProtectedRoute><QuizzesPage /></ProtectedRoute>} />
            <Route path="/assistant" element={<ProtectedRoute><AssistantPage /></ProtectedRoute>} />
            <Route path="/progress" element={<ProtectedRoute><ProgressPage /></ProtectedRoute>} />
            <Route path="/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="*" element={<HomePage />} />
          </Routes>
        </Layout>
      </BrowserRouter>
    </AuthProvider>
  );
}
